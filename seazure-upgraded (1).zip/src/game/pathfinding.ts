/**
 * Grid A* pathfinding for Seazure bots.
 * Builds a walkable grid from map bounds + colliders, supports dynamic soft-wall changes.
 */

import type { AABB } from "./types";

const CELL = 1.0; // 1m cells — good balance of accuracy vs cost
const AGENT_R = 0.42;

export interface Grid {
  minx: number;
  minz: number;
  w: number;
  h: number;
  /** 0 = blocked, 1 = walkable */
  cells: Uint8Array;
  /** version bumps when soft walls change so paths invalidate */
  version: number;
}

export interface PathNode {
  x: number;
  z: number;
}

function cellIndex(g: Grid, cx: number, cz: number) {
  return cz * g.w + cx;
}

function worldToCell(g: Grid, x: number, z: number) {
  const cx = Math.floor((x - g.minx) / CELL);
  const cz = Math.floor((z - g.minz) / CELL);
  return { cx, cz };
}

function cellToWorld(g: Grid, cx: number, cz: number) {
  return {
    x: g.minx + (cx + 0.5) * CELL,
    z: g.minz + (cz + 0.5) * CELL,
  };
}

function isBlockedByAabb(x: number, z: number, box: AABB, pad = AGENT_R) {
  // Expand AABB by agent radius for clearance
  return (
    x + pad > box.minx &&
    x - pad < box.maxx &&
    z + pad > box.minz &&
    z - pad < box.maxz &&
    box.maxy > 0.4 // only solid ground-level blockers
  );
}

/** Build or rebuild the walkability grid from colliders. */
export function buildGrid(
  bounds: { minx: number; maxx: number; minz: number; maxz: number },
  colliders: AABB[],
): Grid {
  const minx = bounds.minx;
  const minz = bounds.minz;
  const w = Math.ceil((bounds.maxx - bounds.minx) / CELL);
  const h = Math.ceil((bounds.maxz - bounds.minz) / CELL);
  const cells = new Uint8Array(w * h);
  cells.fill(1);

  for (let cz = 0; cz < h; cz++) {
    for (let cx = 0; cx < w; cx++) {
      const { x, z } = cellToWorld({ minx, minz, w, h, cells, version: 0 }, cx, cz);
      for (const box of colliders) {
        if (box.kind === "breach" && (box.hp ?? 1) <= 0) continue; // destroyed soft wall = walkable
        if (isBlockedByAabb(x, z, box)) {
          cells[cellIndex({ minx, minz, w, h, cells, version: 0 }, cx, cz)] = 0;
          break;
        }
      }
    }
  }

  return { minx, minz, w, h, cells, version: 1 };
}

/** Mark a region blocked/unblocked (e.g. after soft wall destroy/reinforce). */
export function markRegion(
  g: Grid,
  box: AABB,
  blocked: boolean,
) {
  const pad = AGENT_R + 0.2;
  const minCx = Math.max(0, Math.floor((box.minx - pad - g.minx) / CELL));
  const maxCx = Math.min(g.w - 1, Math.floor((box.maxx + pad - g.minx) / CELL));
  const minCz = Math.max(0, Math.floor((box.minz - pad - g.minz) / CELL));
  const maxCz = Math.min(g.h - 1, Math.floor((box.maxz + pad - g.minz) / CELL));
  for (let cz = minCz; cz <= maxCz; cz++) {
    for (let cx = minCx; cx <= maxCx; cx++) {
      const { x, z } = cellToWorld(g, cx, cz);
      if (isBlockedByAabb(x, z, box, AGENT_R)) {
        g.cells[cellIndex(g, cx, cz)] = blocked ? 0 : 1;
      }
    }
  }
  g.version++;
}

// --- A* ---

const DIRS = [
  { dx: 1, dz: 0, cost: 1 },
  { dx: -1, dz: 0, cost: 1 },
  { dx: 0, dz: 1, cost: 1 },
  { dx: 0, dz: -1, cost: 1 },
  { dx: 1, dz: 1, cost: 1.414 },
  { dx: 1, dz: -1, cost: 1.414 },
  { dx: -1, dz: 1, cost: 1.414 },
  { dx: -1, dz: -1, cost: 1.414 },
];

function heuristic(cx: number, cz: number, gx: number, gz: number) {
  const dx = Math.abs(cx - gx);
  const dz = Math.abs(cz - gz);
  // Octile distance
  return (dx + dz) + (Math.SQRT2 - 2) * Math.min(dx, dz);
}

/** Simple binary min-heap for open set. */
class MinHeap {
  private data: { f: number; i: number }[] = [];
  get size() {
    return this.data.length;
  }
  push(f: number, i: number) {
    this.data.push({ f, i });
    let n = this.data.length - 1;
    while (n > 0) {
      const p = (n - 1) >> 1;
      if (this.data[p].f <= this.data[n].f) break;
      const t = this.data[p];
      this.data[p] = this.data[n];
      this.data[n] = t;
      n = p;
    }
  }
  pop() {
    const top = this.data[0];
    const last = this.data.pop()!;
    if (this.data.length) {
      this.data[0] = last;
      let n = 0;
      for (;;) {
        let s = n;
        const l = n * 2 + 1;
        const r = l + 1;
        if (l < this.data.length && this.data[l].f < this.data[s].f) s = l;
        if (r < this.data.length && this.data[r].f < this.data[s].f) s = r;
        if (s === n) break;
        const t = this.data[n];
        this.data[n] = this.data[s];
        this.data[s] = t;
        n = s;
      }
    }
    return top;
  }
}

/**
 * Find a path from (sx,sz) to (gx,gz). Returns world-space waypoints (centers of cells),
 * or empty array if unreachable / already there.
 */
export function findPath(
  g: Grid,
  sx: number,
  sz: number,
  gx: number,
  gz: number,
  maxNodes = 1800,
): PathNode[] {
  const start = worldToCell(g, sx, sz);
  const goal = worldToCell(g, gx, gz);
  if (
    start.cx < 0 ||
    start.cx >= g.w ||
    start.cz < 0 ||
    start.cz >= g.h ||
    goal.cx < 0 ||
    goal.cx >= g.w ||
    goal.cz < 0 ||
    goal.cz >= g.h
  ) {
    return [];
  }

  // If start blocked, search nearby free cell
  let scx = start.cx;
  let scz = start.cz;
  if (g.cells[cellIndex(g, scx, scz)] === 0) {
    let found = false;
    for (let r = 1; r <= 3 && !found; r++) {
      for (let dz = -r; dz <= r && !found; dz++) {
        for (let dx = -r; dx <= r && !found; dx++) {
          const nx = scx + dx;
          const nz = scz + dz;
          if (nx >= 0 && nx < g.w && nz >= 0 && nz < g.h && g.cells[cellIndex(g, nx, nz)]) {
            scx = nx;
            scz = nz;
            found = true;
          }
        }
      }
    }
    if (!found) return [];
  }

  // If goal blocked, find nearest free
  let gcx = goal.cx;
  let gcz = goal.cz;
  if (g.cells[cellIndex(g, gcx, gcz)] === 0) {
    let bestD = 1e9;
    let bx = gcx;
    let bz = gcz;
    for (let r = 1; r <= 5; r++) {
      for (let dz = -r; dz <= r; dz++) {
        for (let dx = -r; dx <= r; dx++) {
          const nx = gcx + dx;
          const nz = gcz + dz;
          if (nx >= 0 && nx < g.w && nz >= 0 && nz < g.h && g.cells[cellIndex(g, nx, nz)]) {
            const d = Math.abs(dx) + Math.abs(dz);
            if (d < bestD) {
              bestD = d;
              bx = nx;
              bz = nz;
            }
          }
        }
      }
      if (bestD < 1e9) break;
    }
    gcx = bx;
    gcz = bz;
  }

  if (scx === gcx && scz === gcz) {
    const p = cellToWorld(g, gcx, gcz);
    return [{ x: p.x, z: p.z }];
  }

  const N = g.w * g.h;
  const gScore = new Float32Array(N);
  gScore.fill(Infinity);
  const came = new Int32Array(N);
  came.fill(-1);
  const closed = new Uint8Array(N);

  const open = new MinHeap();
  const si = scz * g.w + scx;
  gScore[si] = 0;
  open.push(heuristic(scx, scz, gcx, gcz), si);

  let expanded = 0;
  while (open.size && expanded < maxNodes) {
    const { i } = open.pop();
    if (closed[i]) continue;
    closed[i] = 1;
    expanded++;

    const cx = i % g.w;
    const cz = (i / g.w) | 0;
    if (cx === gcx && cz === gcz) {
      // reconstruct
      const path: PathNode[] = [];
      let cur = i;
      while (cur !== -1) {
        const px = cur % g.w;
        const pz = (cur / g.w) | 0;
        const w = cellToWorld(g, px, pz);
        path.push({ x: w.x, z: w.z });
        cur = came[cur];
      }
      path.reverse();
      // string-pull / simplify: drop colinear midpoints roughly
      return simplifyPath(path);
    }

    for (const d of DIRS) {
      const nx = cx + d.dx;
      const nz = cz + d.dz;
      if (nx < 0 || nx >= g.w || nz < 0 || nz >= g.h) continue;
      // prevent diagonal corner-cutting
      if (d.dx !== 0 && d.dz !== 0) {
        if (
          g.cells[cellIndex(g, cx + d.dx, cz)] === 0 ||
          g.cells[cellIndex(g, cx, cz + d.dz)] === 0
        ) {
          continue;
        }
      }
      const ni = nz * g.w + nx;
      if (closed[ni] || g.cells[ni] === 0) continue;
      const tent = gScore[i] + d.cost;
      if (tent < gScore[ni]) {
        gScore[ni] = tent;
        came[ni] = i;
        open.push(tent + heuristic(nx, nz, gcx, gcz), ni);
      }
    }
  }
  return []; // no path
}

function simplifyPath(path: PathNode[]): PathNode[] {
  if (path.length <= 2) return path;
  const out: PathNode[] = [path[0]];
  for (let i = 1; i < path.length - 1; i++) {
    const a = out[out.length - 1];
    const b = path[i];
    const c = path[i + 1];
    const abx = b.x - a.x;
    const abz = b.z - a.z;
    const bcx = c.x - b.x;
    const bcz = c.z - b.z;
    // keep if direction changes significantly
    const cross = abx * bcz - abz * bcx;
    const dot = abx * bcx + abz * bcz;
    if (Math.abs(cross) > 0.15 || dot < 0) out.push(b);
  }
  out.push(path[path.length - 1]);
  return out;
}

/** Follow a path: return desired direction (normalized xz) toward next waypoint. */
export function pathSteer(
  path: PathNode[],
  x: number,
  z: number,
  arriveRadius = 0.9,
): { wishX: number; wishZ: number; arrived: boolean; nextIdx: number } {
  if (!path.length) return { wishX: 0, wishZ: 0, arrived: true, nextIdx: 0 };
  let idx = 0;
  // skip already-passed waypoints
  while (idx < path.length - 1) {
    const d = Math.hypot(path[idx].x - x, path[idx].z - z);
    if (d < arriveRadius) idx++;
    else break;
  }
  const target = path[idx];
  const dx = target.x - x;
  const dz = target.z - z;
  const dist = Math.hypot(dx, dz) || 1;
  if (idx >= path.length - 1 && dist < arriveRadius) {
    return { wishX: 0, wishZ: 0, arrived: true, nextIdx: idx };
  }
  return { wishX: dx / dist, wishZ: dz / dist, arrived: false, nextIdx: idx };
}

export type Team = "ATTACK" | "DEFENSE";

export type Phase = "prep" | "action" | "end";

export type ClassId = 0 | 1 | 2 | 3 | 4 | 5;

export type GadgetKind = "burst" | "dash" | "erase" | "puddle" | "reveal" | "charge" | "wall" | "pad" | "hazard" | "paint" | "glue" | "ping";

export interface ClassDef {
  id: ClassId;
  name: string;
  role: string;
  blurb: string;
  team: Team;
  damage: number;
  pellets: number;
  rpm: number;
  mag: number;
  spread: number;
  speed: number;
  gadget: GadgetKind;
  gadgetName: string;
  gadgetCd: number;
  color: number;
}

export interface AABB {
  minx: number;
  miny: number;
  minz: number;
  maxx: number;
  maxy: number;
  maxz: number;
  id?: string;
  kind?: "wall" | "crate" | "breach" | "gadget";
  hp?: number;
}

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export interface LobbyPlayer {
  id: string;
  name: string;
  team: Team;
  classId: ClassId;
  ready: boolean;
  connected: boolean;
}

export interface MatchSettings {
  rounds: number;
  roundTime: number;
  fillBots: boolean;
  /** Map / level id from maps.ts — add new levels there. */
  mapId?: string;
}

export interface HudSnap {
  hp: number;
  ammo: number;
  mag: number;
  reloading: boolean;
  gadgetReady: boolean;
  gadgetName: string;
  timer: number;
  phase: Phase;
  round: number;
  maxRounds: number;
  scoreA: number;
  scoreD: number;
  obj: number;
  team: Team;
  className: string;
  notice: string;
  hit: number;
  hurt: number;
  alive: boolean;
  respawn: number;
  paused: boolean;
  locked: boolean;
  capturing: boolean;
  feed: string[];
  result: null | "match";
  matchWinner: Team | null;
  allies: number;
  enemies: number;
  yaw: number;
  speed: number;
}

export interface NetEvent {
  k: string;
  [key: string]: unknown;
}

export interface FighterState {
  id: string;
  name: string;
  bot: boolean;
  team: Team;
  classId: ClassId;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  hp: number;
  alive: boolean;
  vx: number;
  vz: number;
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      getPos: () => { x: number; y: number; z: number };
      setKeys: (codes: string[]) => void;
      setSteer?: (v: number) => void;
    };
  }
}

/**
 * World / physics helpers + compatibility layer over the data-driven map system.
 * Prefer adding new levels in maps.ts (MAPS array). This file stays the
 * collision / query API the engine uses.
 */

import * as THREE from "three";
import type { AABB } from "./types";
import {
  aabbFrom,
  buildWorldFromMap,
  getMap,
  type SoftWall,
  type WorldBuilt,
} from "./maps";

export { aabbFrom, getMap, listMaps } from "./maps";
export type { SoftWall, WorldBuilt, MapDef } from "./maps";

/** Active map bounds + site (updated when a level is built). */
export let MAP = {
  minx: -18,
  maxx: 18,
  minz: -14,
  maxz: 14,
  site: { x: 0, z: -4, half: 2.6 },
  attackSpawns: getMap().attackSpawns,
  defenseSpawns: getMap().defenseSpawns,
};

const RADIUS = 0.36;
const HEIGHT = 1.68;

export function buildWorld(scene: THREE.Scene, mapId?: string): WorldBuilt {
  const built = buildWorldFromMap(scene, mapId);
  const m = built.map;
  MAP = {
    minx: m.bounds.minx,
    maxx: m.bounds.maxx,
    minz: m.bounds.minz,
    maxz: m.bounds.maxz,
    site: { ...m.site },
    attackSpawns: m.attackSpawns,
    defenseSpawns: m.defenseSpawns,
  };
  return built;
}

export function overlaps(a: AABB, b: AABB) {
  return (
    a.minx < b.maxx &&
    a.maxx > b.minx &&
    a.miny < b.maxy &&
    a.maxy > b.miny &&
    a.minz < b.maxz &&
    a.maxz > b.minz
  );
}

export function playerBox(x: number, y: number, z: number): AABB {
  return {
    minx: x - RADIUS,
    maxx: x + RADIUS,
    miny: y,
    maxy: y + HEIGHT,
    minz: z - RADIUS,
    maxz: z + RADIUS,
  };
}

export function resolveCapsule(
  pos: { x: number; y: number; z: number },
  vy: number,
  dx: number,
  dz: number,
  dy: number,
  walls: AABB[],
): { grounded: boolean; vy: number } {
  pos.x += dx;
  const pbx = playerBox(pos.x, pos.y, pos.z);
  for (const w of walls) {
    if (!overlaps(pbx, w)) continue;
    const penL = pbx.maxx - w.minx;
    const penR = w.maxx - pbx.minx;
    if (penL < penR) pos.x -= penL + 0.001;
    else pos.x += penR + 0.001;
    pbx.minx = pos.x - RADIUS;
    pbx.maxx = pos.x + RADIUS;
  }

  pos.z += dz;
  const pbz = playerBox(pos.x, pos.y, pos.z);
  for (const w of walls) {
    if (!overlaps(pbz, w)) continue;
    const penL = pbz.maxz - w.minz;
    const penR = w.maxz - pbz.minz;
    if (penL < penR) pos.z -= penL + 0.001;
    else pos.z += penR + 0.001;
    pbz.minz = pos.z - RADIUS;
    pbz.maxz = pos.z + RADIUS;
  }

  pos.y += dy;
  let grounded = false;
  let nvy = vy;
  const pby = playerBox(pos.x, pos.y, pos.z);
  for (const w of walls) {
    if (!overlaps(pby, w)) continue;
    const penD = pby.maxy - w.miny;
    const penU = w.maxy - pby.miny;
    if (penU < penD) {
      pos.y += penU + 0.001;
      nvy = Math.max(0, nvy);
      grounded = true;
    } else {
      pos.y -= penD + 0.001;
      nvy = Math.min(0, nvy);
    }
    pby.miny = pos.y;
    pby.maxy = pos.y + HEIGHT;
  }
  if (pos.y <= 0) {
    pos.y = 0;
    nvy = 0;
    grounded = true;
  }
  pos.x = Math.max(MAP.minx + RADIUS, Math.min(MAP.maxx - RADIUS, pos.x));
  pos.z = Math.max(MAP.minz + RADIUS, Math.min(MAP.maxz - RADIUS, pos.z));
  return { grounded, vy: nvy };
}

export function rayAabb(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  b: AABB,
  maxT: number,
): number | null {
  const invx = dx !== 0 ? 1 / dx : 1e12;
  const invy = dy !== 0 ? 1 / dy : 1e12;
  const invz = dz !== 0 ? 1 / dz : 1e12;
  let t1 = (b.minx - ox) * invx;
  let t2 = (b.maxx - ox) * invx;
  let tmin = Math.min(t1, t2);
  let tmax = Math.max(t1, t2);
  t1 = (b.miny - oy) * invy;
  t2 = (b.maxy - oy) * invy;
  tmin = Math.max(tmin, Math.min(t1, t2));
  tmax = Math.min(tmax, Math.max(t1, t2));
  t1 = (b.minz - oz) * invz;
  t2 = (b.maxz - oz) * invz;
  tmin = Math.max(tmin, Math.min(t1, t2));
  tmax = Math.min(tmax, Math.max(t1, t2));
  if (tmax >= Math.max(0, tmin) && tmin < maxT && tmax > 0) return tmin < 0 ? 0 : tmin;
  return null;
}

export function onSite(x: number, z: number) {
  return Math.abs(x - MAP.site.x) <= MAP.site.half && Math.abs(z - MAP.site.z) <= MAP.site.half;
}

export const CAPSULE = { radius: RADIUS, height: HEIGHT };

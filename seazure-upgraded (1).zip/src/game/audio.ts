/**
 * Seazure audio — expanded procedural SFX (Web Audio).
 * More variety, layered shots, spatial-friendly short bursts.
 */

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let sfx: GainNode | null = null;
let muted = false;

export function unlockAudio() {
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC({ latencyHint: "interactive" });
    master = ctx.createGain();
    sfx = ctx.createGain();
    sfx.gain.value = 0.72;
    master.gain.value = muted ? 0 : 0.92;
    sfx.connect(master);
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume();
}

export function setMuted(v: boolean) {
  muted = v;
  if (master && ctx) master.gain.setTargetAtTime(v ? 0 : 0.92, ctx.currentTime, 0.02);
}

export function isMuted() {
  return muted;
}

function env(g: GainNode, t: number, a: number, d: number, peak = 0.2) {
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), t + a);
  g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
}

function tone(freq: number, dur: number, type: OscillatorType, peak = 0.16, slide = 0) {
  if (!ctx || !sfx) return;
  const t = ctx.currentTime;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
  env(g, t, 0.008, dur, peak);
  o.connect(g);
  g.connect(sfx);
  o.start(t);
  o.stop(t + dur + 0.04);
  o.onended = () => {
    o.disconnect();
    g.disconnect();
  };
}

function noise(dur: number, peak = 0.12, hp = 800, lp = 0) {
  if (!ctx || !sfx) return;
  const t = ctx.currentTime;
  const n = Math.floor(ctx.sampleRate * dur);
  const buf = ctx.createBuffer(1, n, ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < n; i++) data[i] = Math.random() * 2 - 1;
  const src = ctx.createBufferSource();
  src.buffer = buf;
  const hpF = ctx.createBiquadFilter();
  hpF.type = "highpass";
  hpF.frequency.value = hp;
  let last: AudioNode = hpF;
  if (lp > 0) {
    const lpF = ctx.createBiquadFilter();
    lpF.type = "lowpass";
    lpF.frequency.value = lp;
    hpF.connect(lpF);
    last = lpF;
  }
  const g = ctx.createGain();
  env(g, t, 0.004, dur, peak);
  src.connect(hpF);
  last.connect(g);
  g.connect(sfx);
  src.start(t);
  src.stop(t + dur + 0.02);
  src.onended = () => {
    src.disconnect();
    hpF.disconnect();
    g.disconnect();
  };
}

function click(peak = 0.08) {
  tone(1200 + Math.random() * 400, 0.03, "square", peak, -400);
  noise(0.02, peak * 0.5, 2000);
}

export const sfxPlay = {
  fire() {
    unlockAudio();
    noise(0.045, 0.14, 1800, 9000);
    tone(520 + Math.random() * 120, 0.055, "square", 0.1, -220);
    tone(180 + Math.random() * 40, 0.08, "sawtooth", 0.06, -60);
  },
  empty() {
    unlockAudio();
    tone(90, 0.06, "square", 0.06);
    click(0.05);
  },
  reload() {
    unlockAudio();
    noise(0.05, 0.07, 400, 2500);
    setTimeout(() => {
      tone(280, 0.04, "triangle", 0.07);
      noise(0.03, 0.05, 800);
    }, 90);
    setTimeout(() => tone(380, 0.05, "triangle", 0.06), 200);
  },
  foot() {
    unlockAudio();
    noise(0.035, 0.035 + Math.random() * 0.015, 200, 1800);
    tone(70 + Math.random() * 30, 0.04, "sine", 0.03);
  },
  sprintFoot() {
    unlockAudio();
    noise(0.04, 0.05 + Math.random() * 0.02, 250, 2200);
    tone(90 + Math.random() * 25, 0.035, "sine", 0.04);
  },
  hurt() {
    unlockAudio();
    tone(140, 0.14, "sawtooth", 0.12, -50);
    noise(0.08, 0.08, 300);
  },
  splat() {
    unlockAudio();
    noise(0.12, 0.16, 150, 4000);
    tone(90, 0.15, "sawtooth", 0.1, -40);
    setTimeout(() => noise(0.08, 0.08, 400), 40);
  },
  gadget() {
    unlockAudio();
    tone(440, 0.08, "triangle", 0.1);
    tone(660, 0.1, "sine", 0.07);
    noise(0.06, 0.06, 600);
  },
  reinforce() {
    unlockAudio();
    tone(220, 0.12, "square", 0.1, -30);
    noise(0.1, 0.1, 200, 3000);
    setTimeout(() => {
      tone(330, 0.08, "triangle", 0.08);
      noise(0.05, 0.06, 500);
    }, 80);
  },
  breach() {
    unlockAudio();
    noise(0.18, 0.18, 100, 5000);
    tone(120, 0.12, "sawtooth", 0.1, -80);
    setTimeout(() => noise(0.1, 0.1, 300), 50);
  },
  capture() {
    unlockAudio();
    tone(520, 0.06, "sine", 0.07);
    setTimeout(() => tone(660, 0.08, "sine", 0.08), 60);
  },
  plant() {
    unlockAudio();
    tone(300, 0.05, "square", 0.08);
    setTimeout(() => tone(300, 0.05, "square", 0.08), 100);
    setTimeout(() => tone(450, 0.1, "triangle", 0.1), 200);
  },
  win() {
    unlockAudio();
    tone(392, 0.14, "triangle", 0.1);
    setTimeout(() => tone(494, 0.16, "triangle", 0.1), 120);
    setTimeout(() => tone(587, 0.28, "triangle", 0.12), 240);
    setTimeout(() => noise(0.08, 0.06, 800), 300);
  },
  lose() {
    unlockAudio();
    tone(330, 0.2, "sawtooth", 0.08, -80);
    setTimeout(() => tone(220, 0.3, "sawtooth", 0.08, -60), 160);
  },
  phase() {
    unlockAudio();
    tone(300, 0.08, "triangle", 0.08);
    setTimeout(() => tone(450, 0.12, "triangle", 0.1), 80);
  },
  jump() {
    unlockAudio();
    tone(180, 0.06, "sine", 0.05, 80);
    noise(0.03, 0.03, 400);
  },
  land() {
    unlockAudio();
    noise(0.05, 0.06, 150, 1200);
    tone(80, 0.05, "sine", 0.04);
  },
  ui() {
    unlockAudio();
    click(0.07);
  },
  ping() {
    unlockAudio();
    tone(880, 0.08, "sine", 0.09);
    setTimeout(() => tone(1100, 0.1, "sine", 0.07), 70);
  },
  dash() {
    unlockAudio();
    noise(0.1, 0.1, 400, 6000);
    tone(200, 0.12, "sawtooth", 0.08, 300);
  },
  hit() {
    unlockAudio();
    tone(900 + Math.random() * 200, 0.04, "square", 0.07, -200);
    noise(0.03, 0.05, 1500);
  },
};

import { createFileRoute } from "@tanstack/react-router";
import { SeazureApp } from "@/game/SeazureApp";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SeazureApp />;
}

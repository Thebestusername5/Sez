# SEAZURE — Tactical crayon siege

5v5-style attack/defend FPS with crayon operators, soft walls, gadgets, bots, and P2P multiplayer.

## Run locally

```bash
npm install
npm run dev
```

Open **http://localhost:8080**

## Production / Render.com

Already configured for Render:

```bash
npm install
npm run build
npm start
```

Or use the included `render.yaml` Blueprint on [render.com](https://render.com).

| Setting | Value |
|--------|--------|
| Build | `npm install && npm run build` |
| Start | `npm start` |

## Controls

| Key | Action |
|-----|--------|
| WASD | Move |
| Mouse | Look (click to lock) |
| Click | Fire |
| Q / F | Gadget |
| R | Reload |
| Shift | Sprint |
| Space | Jump |
| **E** | **Reinforce soft wall** (Defense, prep phase only) |
| Esc | Pause |

## Maps

Pick in the main menu:

1. **Sketchpad** — classic mid site  
2. **Inkwell** — tight corridors  
3. **Crayon Yard** — open mid, four soft walls  

Add more in `src/game/maps.ts` (append a `MapDef` to `MAPS`).

## Operators

Data-driven in `src/game/classes.ts`. AI brain in `src/game/ai.ts`.

## Practice

**Practice vs bots** fills both teams with smarter AI (push, hold, flank, reinforce, gadgets).

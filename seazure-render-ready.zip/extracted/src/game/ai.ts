import { getClass } from "./classes";
import type { ClassId, Team } from "./types";
import { MAP } from "./world";

/** Minimal entity shape the AI needs (keeps engine decoupled). */
export interface AiEnt {
  id: string;
  bot: boolean;
  team: Team;
  classId: ClassId;
  pos: { x: number; y: number; z: number };
  yaw: number;
  pitch: number;
  hp: number;
  alive: boolean;
  fireCd: number;
  gadgetCd: number;
  frozenT: number;
  spawnI: number;
  thinkT: number;
  wishX: number;
  wishZ: number;
  /** AI-only state */
  aiState?: AiState;
  aiTargetId?: string | null;
  aiHoldT?: number;
  aiFlankSide?: number;
}

export type AiState =
  | "spawn"
  | "approach"
  | "hold"
  | "push"
  | "flank"
  | "engage"
  | "retreat"
  | "plant"
  | "reinforce";

export interface AiContext {
  phase: "prep" | "action" | "end";
  site: { x: number; z: number; half: number };
  softWalls: { x: number; z: number; hp: number; reinforced: boolean }[];
  now: number;
}

export interface AiDecision {
  wishX: number;
  wishZ: number;
  yaw: number;
  pitch: number;
  wantFire: boolean;
  wantGadget: boolean;
  state: AiState;
}

function hypot2(ax: number, az: number, bx: number, bz: number) {
  const dx = bx - ax;
  const dz = bz - az;
  return Math.hypot(dx, dz);
}

function dirTo(from: { x: number; z: number }, to: { x: number; z: number }) {
  const dx = to.x - from.x;
  const dz = to.z - from.z;
  const len = Math.hypot(dx, dz) || 1;
  return { x: dx / len, z: dz / len, dist: len };
}

/** Smarter bot brain — team-aware roles + phase-aware tactics. */
export function thinkBot(
  e: AiEnt,
  allies: AiEnt[],
  enemies: AiEnt[],
  canSee: (a: AiEnt, b: AiEnt) => boolean,
  ctx: AiContext,
  dt: number,
): AiDecision {
  const cls = getClass(e.team, e.classId);
  const site = ctx.site;
  const onSite =
    Math.abs(e.pos.x - site.x) <= site.half + 0.8 &&
    Math.abs(e.pos.z - site.z) <= site.half + 0.8;

  // --- pick nearest visible / closest enemy ---
  let nearest: AiEnt | null = null;
  let nearestDist = 1e9;
  let visible: AiEnt | null = null;
  let visibleDist = 1e9;
  for (const o of enemies) {
    if (!o.alive) continue;
    const d = hypot2(e.pos.x, e.pos.z, o.pos.x, o.pos.z);
    if (d < nearestDist) {
      nearestDist = d;
      nearest = o;
    }
    if (d < 22 && canSee(e, o) && d < visibleDist) {
      visibleDist = d;
      visible = o;
    }
  }

  // --- state machine ---
  let state: AiState = e.aiState || "spawn";
  e.aiHoldT = (e.aiHoldT ?? 0) - dt;

  if (ctx.phase === "prep") {
    if (e.team === "DEFENSE") {
      // Defenders spread around site / soft walls and prepare
      state = onSite || nearestDist > 18 ? "hold" : "approach";
      if (e.aiHoldT <= 0) {
        e.aiHoldT = 2 + Math.random() * 3;
        // Prefer soft walls that aren't reinforced yet
        const soft = ctx.softWalls.find((s) => s.hp > 0 && !s.reinforced);
        if (soft && Math.random() < 0.55) {
          state = "reinforce";
          e.aiTargetId = null;
        }
      }
    } else {
      // Attackers stage near soft walls / mid, prepare to push
      state = "approach";
      if (Math.random() < 0.15) state = "flank";
    }
  } else if (ctx.phase === "action") {
    if (e.team === "ATTACK") {
      if (visible && visibleDist < 12) state = "engage";
      else if (e.hp < 35 && nearest && nearestDist < 10) state = "retreat";
      else if (onSite) state = "plant";
      else if (Math.random() < 0.08 || state === "flank") state = "flank";
      else state = "push";
    } else {
      // DEFENSE
      if (visible && visibleDist < 11) state = "engage";
      else if (e.hp < 30 && nearest && nearestDist < 8) state = "retreat";
      else if (onSite || e.aiHoldT > 0) state = "hold";
      else state = "approach";
    }
  } else {
    state = "hold";
  }

  e.aiState = state;

  // --- choose goal position ---
  let tx = site.x;
  let tz = site.z;
  const spawnBias = (e.spawnI - 2) * 1.6;

  switch (state) {
    case "spawn":
    case "approach":
      if (e.team === "ATTACK") {
        tx = site.x + spawnBias * 0.4;
        tz = site.z + 6;
      } else {
        tx = site.x + spawnBias;
        tz = site.z - 1.5;
      }
      break;
    case "push":
    case "plant":
      tx = site.x + (Math.random() - 0.5) * 1.2;
      tz = site.z + (Math.random() - 0.5) * 1.2;
      break;
    case "hold":
      tx = site.x + spawnBias * 0.7;
      tz = site.z + (e.team === "DEFENSE" ? -2.2 : 1.5);
      // micro-strafe while holding
      if (Math.random() < 0.02) {
        e.aiFlankSide = Math.random() < 0.5 ? -1 : 1;
      }
      tx += (e.aiFlankSide || 0) * 1.8;
      break;
    case "flank":
      if (e.aiFlankSide == null) e.aiFlankSide = Math.random() < 0.5 ? -1 : 1;
      tx = site.x + e.aiFlankSide * (9 + Math.random() * 4);
      tz = site.z + (e.team === "ATTACK" ? 3 : -3);
      break;
    case "engage":
      if (visible) {
        const d = dirTo(e.pos, visible.pos);
        // keep optimal range (not too close, not too far)
        const ideal = cls.pellets > 1 ? 6 : 9;
        if (d.dist > ideal + 2) {
          tx = visible.pos.x;
          tz = visible.pos.z;
        } else if (d.dist < ideal - 2) {
          tx = e.pos.x - d.x * 3;
          tz = e.pos.z - d.z * 3;
        } else {
          // strafe
          const side = e.aiFlankSide || 1;
          tx = e.pos.x + -d.z * side * 2.5;
          tz = e.pos.z + d.x * side * 2.5;
        }
      }
      break;
    case "retreat":
      if (e.team === "ATTACK") {
        tx = e.pos.x;
        tz = Math.min(MAP.maxz - 2, e.pos.z + 6);
      } else {
        tx = site.x + spawnBias * 0.5;
        tz = site.z - 3;
      }
      break;
    case "reinforce": {
      const soft = ctx.softWalls.find((s) => s.hp > 0 && !s.reinforced) || ctx.softWalls[0];
      if (soft) {
        tx = soft.x;
        tz = soft.z + (e.team === "DEFENSE" ? -1.2 : 1.2);
      }
      break;
    }
  }

  // if we have a clear enemy and are engaging, bias toward them a bit
  if (state === "engage" && visible) {
    tx = tx * 0.4 + visible.pos.x * 0.6;
    tz = tz * 0.4 + visible.pos.z * 0.6;
  }

  const goal = dirTo(e.pos, { x: tx, z: tz });
  let wishX = goal.x;
  let wishZ = goal.z;

  // stop if very close to hold point
  if ((state === "hold" || state === "plant") && goal.dist < 1.1) {
    wishX = 0;
    wishZ = 0;
  }

  // --- aiming ---
  let yaw = e.yaw;
  let pitch = 0;
  let wantFire = false;
  if (visible) {
    const dx = visible.pos.x - e.pos.x;
    const dz = visible.pos.z - e.pos.z;
    const dy = visible.pos.y + 1.15 - (e.pos.y + 1.55);
    const dist = Math.hypot(dx, dz) || 1;
    yaw = Math.atan2(-dx / dist, -dz / dist);
    pitch = Math.atan2(dy, dist);
    // reaction + accuracy: fire when somewhat aimed and cooldown ready
    if (e.fireCd <= 0 && visibleDist < 16) {
      // slight aim error so they're not laser-perfect
      const aimErr = Math.abs(Math.atan2(Math.sin(yaw - e.yaw), Math.cos(yaw - e.yaw)));
      if (aimErr < 0.35) wantFire = true;
    }
  } else if (nearest && nearestDist < 20) {
    const d = dirTo(e.pos, nearest.pos);
    yaw = Math.atan2(-d.x, -d.z);
  } else {
    yaw = Math.atan2(-goal.x, -goal.z);
  }

  // --- gadget use (smarter, role-aware) ---
  let wantGadget = false;
  if (e.gadgetCd <= 0 && e.frozenT <= 0 && ctx.phase === "action") {
    const g = cls.gadget;
    const roll = Math.random();
    if (e.team === "ATTACK") {
      if (g === "dash" && nearestDist > 6 && nearestDist < 18 && roll < 0.012) wantGadget = true;
      if (g === "burst" && visible && visibleDist < 14 && roll < 0.018) wantGadget = true;
      if (g === "charge" && visible && visibleDist < 12 && roll < 0.01) wantGadget = true;
      if (g === "puddle" && onSite && roll < 0.008) wantGadget = true;
      if (g === "reveal" && nearest && nearestDist < 20 && !visible && roll < 0.015) wantGadget = true;
      if (g === "erase" && roll < 0.006) wantGadget = true;
    } else {
      if ((g === "wall" || g === "pad" || g === "hazard" || g === "paint") && onSite && roll < 0.014)
        wantGadget = true;
      if (g === "glue" && visible && visibleDist < 9 && roll < 0.02) wantGadget = true;
      if (g === "ping" && nearest && nearestDist < 22 && roll < 0.01) wantGadget = true;
      if (g === "hazard" && state === "hold" && roll < 0.01) wantGadget = true;
    }
  }

  // prep: defenders "reinforce" by walking to soft walls (visual only for now, but state is set)
  if (ctx.phase === "prep" && e.team === "DEFENSE" && state === "reinforce" && Math.random() < 0.004) {
    wantGadget = cls.gadget === "wall";
  }

  return {
    wishX,
    wishZ,
    yaw,
    pitch,
    wantFire,
    wantGadget,
    state,
  };
}

export function pickBotClass(team: Team, index: number): ClassId {
  // Prefer role diversity so teams feel like real squads
  if (team === "ATTACK") {
    const order: ClassId[] = [0, 1, 5, 4, 2, 3]; // Entry, Fragger, Hard Breach, Intel, Support, CC
    return order[index % order.length];
  }
  const order: ClassId[] = [0, 1, 5, 2, 3, 4]; // Anchor, Trap, Intel, Roamer, Denial, CC
  return order[index % order.length];
}

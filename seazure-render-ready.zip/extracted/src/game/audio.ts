/** Tiny Web Audio synth. Unlock on the first gesture. */

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let sfx: GainNode | null = null;
let muted = false;

export function unlockAudio() {
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC({ latencyHint: "interactive" });
    master = ctx.createGain();
    sfx = ctx.createGain();
    sfx.gain.value = 0.7;
    master.gain.value = muted ? 0 : 0.9;
    sfx.connect(master);
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume();
}

export function setMuted(v: boolean) {
  muted = v;
  if (master && ctx) master.gain.setTargetAtTime(v ? 0 : 0.9, ctx.currentTime, 0.02);
}

export function isMuted() {
  return muted;
}

function env(g: GainNode, t: number, a: number, d: number, peak = 0.2) {
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(peak, t + a);
  g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
}

function tone(freq: number, dur: number, type: OscillatorType, peak = 0.16, slide = 0) {
  if (!ctx || !sfx) return;
  const t = ctx.currentTime;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
  env(g, t, 0.01, dur, peak);
  o.connect(g);
  g.connect(sfx);
  o.start(t);
  o.stop(t + dur + 0.05);
  o.onended = () => {
    o.disconnect();
    g.disconnect();
  };
}

function noise(dur: number, peak = 0.12, hp = 800) {
  if (!ctx || !sfx) return;
  const t = ctx.currentTime;
  const n = Math.floor(ctx.sampleRate * dur);
  const buf = ctx.createBuffer(1, n, ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < n; i++) data[i] = Math.random() * 2 - 1;
  const src = ctx.createBufferSource();
  src.buffer = buf;
  const filter = ctx.createBiquadFilter();
  filter.type = "highpass";
  filter.frequency.value = hp;
  const g = ctx.createGain();
  env(g, t, 0.005, dur, peak);
  src.connect(filter);
  filter.connect(g);
  g.connect(sfx);
  src.start(t);
  src.stop(t + dur + 0.02);
  src.onended = () => {
    src.disconnect();
    filter.disconnect();
    g.disconnect();
  };
}

export const sfxPlay = {
  fire() {
    unlockAudio();
    noise(0.06, 0.1, 1200);
    tone(420 + Math.random() * 80, 0.07, "square", 0.08, -180);
  },
  empty() {
    unlockAudio();
    tone(140, 0.08, "square", 0.05);
  },
  hit() {
    unlockAudio();
    tone(880, 0.05, "triangle", 0.1);
  },
  splat() {
    unlockAudio();
    noise(0.22, 0.18, 400);
    tone(220, 0.25, "sawtooth", 0.12, -160);
    tone(440, 0.18, "square", 0.06, -200);
  },
  reload() {
    unlockAudio();
    tone(180, 0.05, "square", 0.06);
    setTimeout(() => tone(240, 0.06, "square", 0.05), 90);
    setTimeout(() => tone(300, 0.08, "triangle", 0.05), 180);
  },
  jump() {
    unlockAudio();
    tone(240, 0.1, "sine", 0.06, 180);
  },
  gadget() {
    unlockAudio();
    tone(520, 0.12, "triangle", 0.1, 80);
    tone(780, 0.16, "sine", 0.06);
  },
  capture() {
    unlockAudio();
    tone(520, 0.1, "sine", 0.07);
  },
  win() {
    unlockAudio();
    tone(392, 0.16, "triangle", 0.1);
    setTimeout(() => tone(494, 0.16, "triangle", 0.1), 120);
    setTimeout(() => tone(587, 0.28, "triangle", 0.12), 240);
  },
  lose() {
    unlockAudio();
    tone(330, 0.2, "sawtooth", 0.08, -80);
    setTimeout(() => tone(220, 0.3, "sawtooth", 0.08, -60), 160);
  },
  foot() {
    unlockAudio();
    noise(0.04, 0.04, 300);
  },
  hurt() {
    unlockAudio();
    tone(160, 0.12, "sawtooth", 0.1, -40);
  },
};

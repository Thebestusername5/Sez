/**
 * Data-driven map / level system.
 * To add a new level: append a MapDef to MAPS and give it a unique id.
 * The builder turns the declarative boxes into colliders + meshes.
 */

import * as THREE from "three";
import type { AABB } from "./types";

export interface SpawnPoint {
  x: number;
  z: number;
}

export interface SoftWallDef {
  x: number;
  y: number;
  z: number;
  sx: number;
  sy: number;
  sz: number;
  hp: number;
  id: string;
}

export interface BoxDef {
  x: number;
  y: number;
  z: number;
  sx: number;
  sy: number;
  sz: number;
  kind?: "wall" | "crate" | "breach";
  mat?: "outer" | "inner" | "crate" | "soft";
}

export interface MapDef {
  id: string;
  name: string;
  blurb: string;
  bounds: { minx: number; maxx: number; minz: number; maxz: number };
  site: { x: number; z: number; half: number };
  attackSpawns: SpawnPoint[];
  defenseSpawns: SpawnPoint[];
  boxes: BoxDef[];
  softWalls: SoftWallDef[];
  props?: { type: "crayon"; x: number; z: number; color: number }[];
}

export const MAPS: MapDef[] = [
  {
    id: "sketchpad",
    name: "Sketchpad",
    blurb: "Classic mid-site with soft walls and side flanks.",
    bounds: { minx: -18, maxx: 18, minz: -14, maxz: 14 },
    site: { x: 0, z: -4, half: 2.6 },
    attackSpawns: [
      { x: 0, z: 12.2 },
      { x: -4.2, z: 12 },
      { x: 4.2, z: 12 },
      { x: -8, z: 11.4 },
      { x: 8, z: 11.4 },
    ],
    defenseSpawns: [
      { x: 0, z: -12.2 },
      { x: -4.2, z: -12 },
      { x: 4.2, z: -12 },
      { x: -8, z: -11.4 },
      { x: 8, z: -11.4 },
    ],
    boxes: [
      // Outer walls
      { x: 0, y: 2.1, z: -14.25, sx: 38, sy: 4.2, sz: 0.5, mat: "outer" },
      { x: 0, y: 2.1, z: 14.25, sx: 38, sy: 4.2, sz: 0.5, mat: "outer" },
      { x: -18.25, y: 2.1, z: 0, sx: 0.5, sy: 4.2, sz: 29, mat: "outer" },
      { x: 18.25, y: 2.1, z: 0, sx: 0.5, sy: 4.2, sz: 29, mat: "outer" },
      // Defense rooms / site frame
      { x: -12, y: 2.1, z: -8.4, sx: 12, sy: 4.2, sz: 0.5, mat: "inner" },
      { x: 12, y: 2.1, z: -8.4, sx: 12, sy: 4.2, sz: 0.5, mat: "inner" },
      { x: -8.2, y: 2.1, z: -11.2, sx: 0.5, sy: 4.2, sz: 6, mat: "inner" },
      { x: 8.2, y: 2.1, z: -11.2, sx: 0.5, sy: 4.2, sz: 6, mat: "inner" },
      // Mid split with doorways
      { x: -13.5, y: 2.1, z: 1.2, sx: 9, sy: 4.2, sz: 0.5, mat: "inner" },
      { x: 13.5, y: 2.1, z: 1.2, sx: 9, sy: 4.2, sz: 0.5, mat: "inner" },
      { x: -8.4, y: 2.1, z: -2.6, sx: 0.5, sy: 4.2, sz: 7.6, mat: "inner" },
      { x: 8.4, y: 2.1, z: -2.6, sx: 0.5, sy: 4.2, sz: 7.6, mat: "inner" },
      // Attack-side wings
      { x: -13, y: 2.1, z: 7.6, sx: 8, sy: 4.2, sz: 0.5, mat: "inner" },
      { x: 13, y: 2.1, z: 7.6, sx: 8, sy: 4.2, sz: 0.5, mat: "inner" },
      // Cover crates
      { x: -6.2, y: 0.55, z: 5.4, sx: 1.3, sy: 1.1, sz: 1.3, kind: "crate", mat: "crate" },
      { x: 6.2, y: 0.55, z: 5.4, sx: 1.3, sy: 1.1, sz: 1.3, kind: "crate", mat: "crate" },
      { x: -3.4, y: 0.55, z: -1.2, sx: 1.4, sy: 1.1, sz: 1.4, kind: "crate", mat: "crate" },
      { x: 3.4, y: 0.55, z: -1.2, sx: 1.4, sy: 1.1, sz: 1.4, kind: "crate", mat: "crate" },
      { x: -11.5, y: 0.55, z: 9.2, sx: 1.6, sy: 1.1, sz: 1.2, kind: "crate", mat: "crate" },
      { x: 11.5, y: 0.55, z: 9.2, sx: 1.6, sy: 1.1, sz: 1.2, kind: "crate", mat: "crate" },
      { x: 0, y: 0.55, z: 8.2, sx: 2.2, sy: 1.1, sz: 1.1, kind: "crate", mat: "crate" },
      { x: -5.5, y: 0.55, z: -10.4, sx: 1.4, sy: 1.1, sz: 1.4, kind: "crate", mat: "crate" },
      { x: 5.5, y: 0.55, z: -10.4, sx: 1.4, sy: 1.1, sz: 1.4, kind: "crate", mat: "crate" },
      { x: -14.6, y: 0.55, z: -2, sx: 1.2, sy: 1.1, sz: 2.2, kind: "crate", mat: "crate" },
      { x: 14.6, y: 0.55, z: -2, sx: 1.2, sy: 1.1, sz: 2.2, kind: "crate", mat: "crate" },
    ],
    softWalls: [
      { x: 0, y: 2.05, z: 1.2, sx: 8.2, sy: 4.1, sz: 0.38, hp: 160, id: "soft-0" },
      { x: -8.4, y: 2.05, z: -6.0, sx: 0.38, sy: 4.1, sz: 3.2, hp: 120, id: "soft-1" },
      { x: 8.4, y: 2.05, z: -6.0, sx: 0.38, sy: 4.1, sz: 3.2, hp: 120, id: "soft-2" },
    ],
    props: [
      { type: "crayon", x: -8, z: 4.8, color: 0xff5a3c },
      { type: "crayon", x: -4, z: 4.8, color: 0x4f63ff },
      { type: "crayon", x: 0, z: 4.8, color: 0xffd24a },
      { type: "crayon", x: 4, z: 4.8, color: 0x3dffb0 },
      { type: "crayon", x: 8, z: 4.8, color: 0xff8ad4 },
    ],
  },
  // --- Example second level (easy to add more) ---
  {
    id: "inkwell",
    name: "Inkwell",
    blurb: "Tight corridors, two soft entries, strong defender anchors.",
    bounds: { minx: -16, maxx: 16, minz: -13, maxz: 13 },
    site: { x: 0, z: -3.5, half: 2.2 },
    attackSpawns: [
      { x: 0, z: 11.5 },
      { x: -5, z: 11 },
      { x: 5, z: 11 },
      { x: -9, z: 10.2 },
      { x: 9, z: 10.2 },
    ],
    defenseSpawns: [
      { x: 0, z: -11.5 },
      { x: -4, z: -11 },
      { x: 4, z: -11 },
      { x: -8, z: -10.4 },
      { x: 8, z: -10.4 },
    ],
    boxes: [
      { x: 0, y: 2.1, z: -13.1, sx: 34, sy: 4.2, sz: 0.5, mat: "outer" },
      { x: 0, y: 2.1, z: 13.1, sx: 34, sy: 4.2, sz: 0.5, mat: "outer" },
      { x: -16.1, y: 2.1, z: 0, sx: 0.5, sy: 4.2, sz: 26.5, mat: "outer" },
      { x: 16.1, y: 2.1, z: 0, sx: 0.5, sy: 4.2, sz: 26.5, mat: "outer" },
      // Site box
      { x: -7, y: 2.1, z: -7.5, sx: 10, sy: 4.2, sz: 0.45, mat: "inner" },
      { x: 7, y: 2.1, z: -7.5, sx: 10, sy: 4.2, sz: 0.45, mat: "inner" },
      { x: -7.2, y: 2.1, z: -10.2, sx: 0.45, sy: 4.2, sz: 5.5, mat: "inner" },
      { x: 7.2, y: 2.1, z: -10.2, sx: 0.45, sy: 4.2, sz: 5.5, mat: "inner" },
      // Mid chokepoints
      { x: -10, y: 2.1, z: 0.5, sx: 8, sy: 4.2, sz: 0.45, mat: "inner" },
      { x: 10, y: 2.1, z: 0.5, sx: 8, sy: 4.2, sz: 0.45, mat: "inner" },
      { x: -6.5, y: 2.1, z: -1.5, sx: 0.45, sy: 4.2, sz: 6, mat: "inner" },
      { x: 6.5, y: 2.1, z: -1.5, sx: 0.45, sy: 4.2, sz: 6, mat: "inner" },
      // Crates
      { x: -4, y: 0.55, z: 4, sx: 1.4, sy: 1.1, sz: 1.4, kind: "crate", mat: "crate" },
      { x: 4, y: 0.55, z: 4, sx: 1.4, sy: 1.1, sz: 1.4, kind: "crate", mat: "crate" },
      { x: 0, y: 0.55, z: 7, sx: 2, sy: 1.1, sz: 1.2, kind: "crate", mat: "crate" },
      { x: -9, y: 0.55, z: -3, sx: 1.3, sy: 1.1, sz: 1.8, kind: "crate", mat: "crate" },
      { x: 9, y: 0.55, z: -3, sx: 1.3, sy: 1.1, sz: 1.8, kind: "crate", mat: "crate" },
      { x: -3, y: 0.55, z: -9.5, sx: 1.3, sy: 1.1, sz: 1.3, kind: "crate", mat: "crate" },
      { x: 3, y: 0.55, z: -9.5, sx: 1.3, sy: 1.1, sz: 1.3, kind: "crate", mat: "crate" },
    ],
    softWalls: [
      { x: 0, y: 2.05, z: 0.5, sx: 6.5, sy: 4.1, sz: 0.36, hp: 150, id: "ink-0" },
      { x: -6.5, y: 2.05, z: -4.5, sx: 0.36, sy: 4.1, sz: 2.8, hp: 110, id: "ink-1" },
      { x: 6.5, y: 2.05, z: -4.5, sx: 0.36, sy: 4.1, sz: 2.8, hp: 110, id: "ink-2" },
    ],
    props: [
      { type: "crayon", x: -6, z: 3.5, color: 0xff5a3c },
      { type: "crayon", x: 0, z: 3.5, color: 0x4f63ff },
      { type: "crayon", x: 6, z: 3.5, color: 0xffd24a },
    ],
  },
  {
    id: "crayon-yard",
    name: "Crayon Yard",
    blurb: "Open mid, long flanks, four soft breaches — pure chaos.",
    bounds: { minx: -20, maxx: 20, minz: -15, maxz: 15 },
    site: { x: 0, z: -5, half: 2.8 },
    attackSpawns: [
      { x: 0, z: 13.5 },
      { x: -5, z: 13 },
      { x: 5, z: 13 },
      { x: -10, z: 12 },
      { x: 10, z: 12 },
    ],
    defenseSpawns: [
      { x: 0, z: -13.5 },
      { x: -5, z: -13 },
      { x: 5, z: -13 },
      { x: -10, z: -12 },
      { x: 10, z: -12 },
    ],
    boxes: [
      { x: 0, y: 2.1, z: -15.2, sx: 42, sy: 4.2, sz: 0.5, mat: "outer" },
      { x: 0, y: 2.1, z: 15.2, sx: 42, sy: 4.2, sz: 0.5, mat: "outer" },
      { x: -20.2, y: 2.1, z: 0, sx: 0.5, sy: 4.2, sz: 31, mat: "outer" },
      { x: 20.2, y: 2.1, z: 0, sx: 0.5, sy: 4.2, sz: 31, mat: "outer" },
      // Site shell
      { x: -10, y: 2.1, z: -9, sx: 14, sy: 4.2, sz: 0.45, mat: "inner" },
      { x: 10, y: 2.1, z: -9, sx: 14, sy: 4.2, sz: 0.45, mat: "inner" },
      { x: -9.5, y: 2.1, z: -12, sx: 0.45, sy: 4.2, sz: 6.5, mat: "inner" },
      { x: 9.5, y: 2.1, z: -12, sx: 0.45, sy: 4.2, sz: 6.5, mat: "inner" },
      // Long flanks
      { x: -14, y: 2.1, z: 2, sx: 8, sy: 4.2, sz: 0.45, mat: "inner" },
      { x: 14, y: 2.1, z: 2, sx: 8, sy: 4.2, sz: 0.45, mat: "inner" },
      { x: -11, y: 2.1, z: -2, sx: 0.45, sy: 4.2, sz: 8, mat: "inner" },
      { x: 11, y: 2.1, z: -2, sx: 0.45, sy: 4.2, sz: 8, mat: "inner" },
      // Mid cover
      { x: -5, y: 0.55, z: 3, sx: 1.5, sy: 1.1, sz: 1.5, kind: "crate", mat: "crate" },
      { x: 5, y: 0.55, z: 3, sx: 1.5, sy: 1.1, sz: 1.5, kind: "crate", mat: "crate" },
      { x: 0, y: 0.55, z: 6, sx: 2.4, sy: 1.1, sz: 1.2, kind: "crate", mat: "crate" },
      { x: -12, y: 0.55, z: 8, sx: 1.4, sy: 1.1, sz: 1.4, kind: "crate", mat: "crate" },
      { x: 12, y: 0.55, z: 8, sx: 1.4, sy: 1.1, sz: 1.4, kind: "crate", mat: "crate" },
      { x: -4, y: 0.55, z: -11, sx: 1.4, sy: 1.1, sz: 1.4, kind: "crate", mat: "crate" },
      { x: 4, y: 0.55, z: -11, sx: 1.4, sy: 1.1, sz: 1.4, kind: "crate", mat: "crate" },
      { x: -16, y: 0.55, z: -4, sx: 1.2, sy: 1.1, sz: 2, kind: "crate", mat: "crate" },
      { x: 16, y: 0.55, z: -4, sx: 1.2, sy: 1.1, sz: 2, kind: "crate", mat: "crate" },
    ],
    softWalls: [
      { x: 0, y: 2.05, z: 2, sx: 9, sy: 4.1, sz: 0.36, hp: 180, id: "cy-0" },
      { x: -11, y: 2.05, z: -5, sx: 0.36, sy: 4.1, sz: 3.5, hp: 130, id: "cy-1" },
      { x: 11, y: 2.05, z: -5, sx: 0.36, sy: 4.1, sz: 3.5, hp: 130, id: "cy-2" },
      { x: 0, y: 2.05, z: -9, sx: 5, sy: 4.1, sz: 0.36, hp: 100, id: "cy-3" },
    ],
    props: [
      { type: "crayon", x: -10, z: 5, color: 0xff5a3c },
      { type: "crayon", x: -5, z: 5, color: 0x4f63ff },
      { type: "crayon", x: 0, z: 5, color: 0xffd24a },
      { type: "crayon", x: 5, z: 5, color: 0x3dffb0 },
      { type: "crayon", x: 10, z: 5, color: 0xff8ad4 },
    ],
  },
];

export function getMap(id?: string): MapDef {
  return MAPS.find((m) => m.id === id) || MAPS[0];
}

export function listMaps() {
  return MAPS.map((m) => ({ id: m.id, name: m.name, blurb: m.blurb }));
}

// ---- builder helpers (shared textures) ----

function paperTex(repeatX: number, repeatY: number) {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const g = c.getContext("2d")!;
  g.fillStyle = "#e8d4a4";
  g.fillRect(0, 0, 256, 256);
  g.strokeStyle = "rgba(70,50,30,0.13)";
  g.lineWidth = 1;
  for (let i = 0; i <= 256; i += 16) {
    g.beginPath();
    g.moveTo(i, 0);
    g.lineTo(i, 256);
    g.stroke();
    g.beginPath();
    g.moveTo(0, i);
    g.lineTo(256, i);
    g.stroke();
  }
  g.fillStyle = "rgba(255,255,255,0.18)";
  g.fillRect(0, 0, 256, 18);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.repeat.set(repeatX, repeatY);
  t.anisotropy = 4;
  return t;
}

function crayonStrokeTex(hex: string) {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 128;
  const g = c.getContext("2d")!;
  g.fillStyle = hex;
  g.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 40; i++) {
    g.strokeStyle = `rgba(0,0,0,${0.04 + Math.random() * 0.07})`;
    g.lineWidth = 1 + Math.random() * 2;
    g.beginPath();
    g.moveTo(Math.random() * 128, Math.random() * 128);
    g.lineTo(Math.random() * 128, Math.random() * 128);
    g.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.repeat.set(2, 2);
  return t;
}

function mat(color: number, rough = 0.86, map?: THREE.Texture) {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: rough,
    metalness: 0.02,
    ...(map ? { map } : {}),
  });
}

export function aabbFrom(
  x: number,
  y: number,
  z: number,
  sx: number,
  sy: number,
  sz: number,
  extra?: Partial<AABB>,
): AABB {
  return {
    minx: x - sx / 2,
    maxx: x + sx / 2,
    miny: y - sy / 2,
    maxy: y + sy / 2,
    minz: z - sz / 2,
    maxz: z + sz / 2,
    kind: "wall",
    ...extra,
  };
}

export interface SoftWall {
  mesh: THREE.Mesh;
  box: AABB;
  hp: number;
  maxHp: number;
  reinforced: boolean;
}

export interface WorldBuilt {
  colliders: AABB[];
  meshes: THREE.Object3D[];
  softWalls: SoftWall[];
  siteMesh: THREE.Mesh;
  map: MapDef;
}

export function buildWorldFromMap(scene: THREE.Scene, mapId?: string): WorldBuilt {
  const map = getMap(mapId);
  const colliders: AABB[] = [];
  const meshes: THREE.Object3D[] = [];
  const softWalls: SoftWall[] = [];

  const wallMat = mat(0xcbb48a, 0.9, crayonStrokeTex("#d7b077"));
  const innerMat = mat(0xbba0d8, 0.88, crayonStrokeTex("#bda4d6"));
  const crateMat = mat(0xfff7ea, 0.7);
  const softBase = new THREE.MeshStandardMaterial({
    color: 0x8cc7f0,
    transparent: true,
    opacity: 0.92,
    roughness: 0.4,
  });

  const bw = map.bounds.maxx - map.bounds.minx;
  const bd = map.bounds.maxz - map.bounds.minz;
  const floor = new THREE.Mesh(
    new THREE.BoxGeometry(bw + 2, 0.5, bd + 2),
    mat(0xf0d29d, 0.95, paperTex(18, 14)),
  );
  floor.position.set((map.bounds.minx + map.bounds.maxx) / 2, -0.25, (map.bounds.minz + map.bounds.maxz) / 2);
  floor.receiveShadow = true;
  scene.add(floor);
  meshes.push(floor);

  const matFor = (m?: string) => {
    if (m === "outer") return wallMat;
    if (m === "inner") return innerMat;
    if (m === "crate") return crateMat;
    return wallMat;
  };

  for (const b of map.boxes) {
    const material = matFor(b.mat);
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(b.sx, b.sy, b.sz), material);
    mesh.position.set(b.x, b.y, b.z);
    mesh.castShadow = false;
    scene.add(mesh);
    meshes.push(mesh);
    colliders.push(
      aabbFrom(b.x, b.y, b.z, b.sx, b.sy, b.sz, {
        kind: b.kind || "wall",
      }),
    );
  }

  for (const s of map.softWalls) {
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(s.sx, s.sy, s.sz),
      softBase.clone(),
    );
    mesh.position.set(s.x, s.y, s.z);
    scene.add(mesh);
    meshes.push(mesh);
    const box = aabbFrom(s.x, s.y, s.z, s.sx, s.sy, s.sz, {
      kind: "breach",
      id: s.id,
      hp: s.hp,
    });
    colliders.push(box);
    softWalls.push({ mesh, box, hp: s.hp, maxHp: s.hp, reinforced: false });
  }

  // Decorative crayons
  const crayonGeo = new THREE.CylinderGeometry(0.28, 0.28, 2.2, 10);
  const tipGeo = new THREE.ConeGeometry(0.28, 0.7, 10);
  for (const p of map.props || []) {
    if (p.type !== "crayon") continue;
    const g = new THREE.Group();
    const body = new THREE.Mesh(crayonGeo, mat(p.color, 0.45));
    const tip = new THREE.Mesh(tipGeo, mat(0xfff4d8, 0.4));
    tip.position.y = 1.45;
    g.add(body, tip);
    g.position.set(p.x, 1.1, p.z);
    scene.add(g);
    meshes.push(g);
    colliders.push(aabbFrom(p.x, 1.1, p.z, 0.7, 2.2, 0.7, { kind: "crate" }));
  }

  // Site pad
  const siteMat = new THREE.MeshStandardMaterial({
    color: 0xffd24a,
    emissive: 0x88620a,
    emissiveIntensity: 0.35,
    roughness: 0.5,
  });
  const siteMesh = new THREE.Mesh(
    new THREE.BoxGeometry(map.site.half * 2, 0.08, map.site.half * 2),
    siteMat,
  );
  siteMesh.position.set(map.site.x, 0.04, map.site.z);
  scene.add(siteMesh);
  meshes.push(siteMesh);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(map.site.half - 0.2, map.site.half + 0.05, 24),
    new THREE.MeshBasicMaterial({
      color: 0xfff1a8,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.8,
    }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.set(map.site.x, 0.09, map.site.z);
  scene.add(ring);
  meshes.push(ring);

  return { colliders, meshes, softWalls, siteMesh, map };
}

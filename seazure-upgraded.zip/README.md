# SEAZURE — Tactical crayon siege

5v5 attack/defend FPS with crayon operators, soft walls, gadgets, pathfinding bots, and P2P multiplayer.

**Like Rainbow Six Siege:** Attack plants the bomb / Defense defuses. Die once and you're out for the round (spectate). Reinforce soft walls in prep. Smart bots with A* pathfinding.

## Run locally

```bash
npm install
npm run dev
```

Open **http://localhost:8080**

## Production / Render.com

Already configured for Render:

```bash
npm install
npm run build
npm start
```

Or use the included `render.yaml` Blueprint on [render.com](https://render.com).

| Setting | Value |
|--------|--------|
| Build | `npm install && npm run build` |
| Start | `npm start` |

## Controls

| Key | Action |
|-----|--------|
| WASD | Move |
| Mouse | Look (click to lock) |
| Click | Fire |
| Q / F | Gadget |
| R | Reload |
| Shift | Sprint |
| Space | Jump |
| **Hold E** | **Reinforce soft wall** (Defense, prep phase — 2 second channel) |
| Esc | Pause |

## Maps (much larger)

Pick in the main menu:

1. **Paper Fortress** — huge multi-wing compound, four soft breaches, dual flanks  
2. **Ink Yard** — open industrial yard, container mazes, long rotates  
3. **Crayon Citadel** — grand hall + tight side corridors, strong anchors  

Add more in `src/game/maps.ts` (append a `MapDef` to `MAPS`).

## Operators

Data-driven in `src/game/classes.ts`. AI brain in `src/game/ai.ts` with A* pathfinding (`pathfinding.ts`).

## Practice

**Practice vs bots** fills both teams (5v5) with smarter AI that:

- Pathfinds around walls and through breached soft walls  
- Pushes, holds, flanks, engages, retreats  
- Reinforces soft walls in prep  
- Uses gadgets by role  

## Key upgrades in this build

- **A* pathfinding** on a dynamic grid (soft walls open when destroyed)  
- **Permadeath per round** (R6-style — no mid-round respawn)  
- **Hold-to-reinforce** (2s channel) with clearer visual (metallic, tougher, particles)  
- **3 large unique maps** (~2× linear size of the originals)  
- **Better lighting / fog** tuned for big maps  
- **Smarter bot roles** and repathing  

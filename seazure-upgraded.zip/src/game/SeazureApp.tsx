import { useEffect, useRef, useState } from "react";
import {
  Crosshair,
  DoorOpen,
  Gamepad2,
  Pencil,
  Play,
  Shield,
  Swords,
  Users,
  Volume2,
  VolumeX,
} from "lucide-react";
import { useP2PRoom, type PeerInfo } from "@/lib/multiplayer";
import { unlockAudio, setMuted, isMuted } from "./audio";
import { classesFor, getClass } from "./classes";
import { SeazureEngine, type EngineOpts } from "./engine";
import { listMaps } from "./world";
import type { ClassId, HudSnap, LobbyPlayer, MatchSettings, Team } from "./types";

type Screen = "menu" | "join" | "lobby" | "class" | "play";

const NAME_KEY = "seazure-name";

function randName() {
  const a = ["Ink", "Sketch", "Splat", "Doodle", "Wax", "Nib", "Pastel", "Mark"];
  const b = ["Kid", "Blot", "Dash", "Cap", "Bolt", "Pop"];
  return a[Math.floor(Math.random() * a.length)] + b[Math.floor(Math.random() * b.length)];
}

function makeCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 6; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

function fmtTime(t: number) {
  const s = Math.max(0, Math.floor(t));
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}

export function SeazureApp() {
  const [name, setName] = useState("Player");
  const [screen, setScreen] = useState<Screen>("menu");
  const [room, setRoom] = useState<string | null>(null);
  const [joinCode, setJoinCode] = useState("");
  const [isHost, setIsHost] = useState(false);
  const [practice, setPractice] = useState(false);
  const [team, setTeam] = useState<Team>("ATTACK");
  const [classId, setClassId] = useState<ClassId>(0);
  const [fillBots, setFillBots] = useState(true);
  const [mapId, setMapId] = useState("paper-fortress");
  const [settings] = useState<MatchSettings>({ rounds: 5, roundTime: 120, fillBots: true });
  const [muted, setMutedUi] = useState(false);
  const matchSettings: MatchSettings = { ...settings, fillBots, mapId };

  useEffect(() => {
    try {
      const saved = localStorage.getItem(NAME_KEY);
      setName(saved && saved.trim() ? saved : randName());
    } catch {
      setName(randName());
    }
  }, []);

  const persistName = (v: string) => {
    setName(v);
    try {
      localStorage.setItem(NAME_KEY, v);
    } catch {
      /* ignore */
    }
  };

  const startPractice = () => {
    unlockAudio();
    setPractice(true);
    setIsHost(true);
    setRoom(null);
    setScreen("class");
  };

  const createMatch = () => {
    unlockAudio();
    setPractice(false);
    setIsHost(true);
    setRoom(makeCode());
    setScreen("lobby");
  };

  const quickPlay = () => {
    unlockAudio();
    setPractice(false);
    // Shared public buckets — anyone on this server lands in the same open lobbies
    const bucket = `Q${Math.floor(Date.now() / 120000) % 4}`; // rotates every 2 min
    setIsHost(true); // first in can start; others still connect via same room
    setRoom(bucket);
    setScreen("lobby");
  };

  const joinMatch = () => {
    const c = joinCode.trim().toUpperCase();
    if (!c) return;
    unlockAudio();
    setPractice(false);
    setIsHost(false);
    setRoom(c);
    setScreen("lobby");
  };

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-paper text-ink font-sans">
      {screen === "menu" && (
        <Menu
          name={name}
          onName={persistName}
          mapId={mapId}
          onMap={setMapId}
          onPractice={startPractice}
          onCreate={createMatch}
          onQuick={quickPlay}
          onJoin={() => setScreen("join")}
        />
      )}
      {screen === "join" && (
        <Join
          code={joinCode}
          onCode={setJoinCode}
          onJoin={joinMatch}
          onBack={() => setScreen("menu")}
        />
      )}
      {screen === "lobby" && room && (
        <Lobby
          key={room}
          room={room}
          name={name}
          isHost={isHost}
          team={team}
          fillBots={fillBots}
          onFillBots={setFillBots}
          onTeam={setTeam}
          onStart={() => {
            setPractice(false);
            setScreen("class");
          }}
          onLeave={() => {
            setRoom(null);
            setScreen("menu");
          }}
        />
      )}
      {screen === "class" && (
        <ClassSelect
          team={team}
          classId={classId}
          onTeam={setTeam}
          onClass={setClassId}
          onEnter={() => setScreen("play")}
          onBack={() => setScreen(room ? "lobby" : "menu")}
        />
      )}
      {screen === "play" && (
        <PlayView
          name={name}
          team={team}
          classId={classId}
          room={room}
          isHost={isHost}
          practice={practice}
          fillBots={fillBots}
          settings={matchSettings}
          muted={muted}
          onMute={(v) => {
            setMuted(v);
            setMutedUi(v);
          }}
          onExit={() => {
            setScreen("menu");
            setRoom(null);
          }}
        />
      )}
    </div>
  );
}

function PaperBg({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative flex h-full w-full flex-col items-center justify-center px-5 py-8">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(1200px 600px at 50% -10%, color-mix(in oklab, var(--color-sky) 35%, transparent), transparent 70%), repeating-linear-gradient(0deg, transparent, transparent 31px, color-mix(in oklab, var(--color-ink) 6%, transparent) 32px)",
        }}
      />
      <div className="relative z-10 flex w-full max-w-lg flex-col items-center">{children}</div>
    </div>
  );
}

function Menu({
  name,
  onName,
  mapId,
  onMap,
  onPractice,
  onCreate,
  onQuick,
  onJoin,
}: {
  name: string;
  onName: (v: string) => void;
  mapId: string;
  onMap: (id: string) => void;
  onPractice: () => void;
  onCreate: () => void;
  onQuick: () => void;
  onJoin: () => void;
}) {
  const maps = listMaps();
  return (
    <PaperBg>
      <p className="mb-2 text-xs font-semibold tracking-[0.28em] text-muted uppercase">Tactical crayon siege</p>
      <h1 className="font-display text-[clamp(3.2rem,12vw,5.6rem)] font-semibold leading-none tracking-tight text-ink">
        SEAZURE
      </h1>
      <p className="mt-3 max-w-sm text-center text-sm leading-snug text-ink-soft">
        Attack the gold site or hold it. Breach soft walls, plant gadgets, and outsmart the other team — crayon style.
      </p>
      <label className="mt-6 w-full text-xs font-semibold tracking-wide text-muted uppercase">
        Callsign
        <input
          value={name}
          maxLength={16}
          onChange={(e) => onName(e.target.value.slice(0, 16))}
          className="mt-1.5 h-12 w-full rounded-lg border border-line bg-surface px-4 text-base font-semibold text-ink outline-none ring-crayon/0 transition focus:ring-2 focus:ring-crayon"
        />
      </label>
      <label className="mt-4 w-full text-xs font-semibold tracking-wide text-muted uppercase">
        Map
        <select
          value={mapId}
          onChange={(e) => onMap(e.target.value)}
          className="mt-1.5 h-11 w-full rounded-lg border border-line bg-surface px-3 text-sm font-semibold text-ink outline-none focus:ring-2 focus:ring-crayon"
        >
          {maps.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name} — {m.blurb}
            </option>
          ))}
        </select>
      </label>
      <div className="mt-6 flex w-full flex-col gap-3">
        <Btn tone="primary" onClick={onPractice} icon={<Gamepad2 className="size-4" />}>
          Practice vs bots
        </Btn>
        <Btn tone="accent" onClick={onQuick} icon={<Users className="size-4" />}>
          Quick match (auto lobby)
        </Btn>
        <div className="grid grid-cols-2 gap-3">
          <Btn onClick={onCreate} icon={<Swords className="size-4" />}>
            Create code
          </Btn>
          <Btn onClick={onJoin} icon={<DoorOpen className="size-4" />}>
            Join code
          </Btn>
        </div>
      </div>
      <p className="mt-4 max-w-sm text-center text-xs text-muted">
        Quick match puts you in a public lobby with anyone online on this server.
        Or create/join a 6-letter room code with friends.
      </p>
      <p className="mt-3 text-center text-xs text-muted">
        WASD · mouse · fire · Q gadget · R reload · Hold E plant/defuse/reinforce
      </p>
    </PaperBg>
  );
}

function Join({
  code,
  onCode,
  onJoin,
  onBack,
}: {
  code: string;
  onCode: (v: string) => void;
  onJoin: () => void;
  onBack: () => void;
}) {
  return (
    <PaperBg>
      <h2 className="font-display text-3xl font-semibold">Join match</h2>
      <p className="mt-2 text-sm text-ink-soft">Enter the six-letter room code.</p>
      <input
        value={code}
        onChange={(e) => onCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8))}
        placeholder="A7K2MQ"
        className="mt-6 h-14 w-full rounded-lg border border-line bg-surface text-center font-display text-2xl tracking-[0.35em] text-ink outline-none focus:ring-2 focus:ring-crayon"
        autoFocus
      />
      <div className="mt-5 flex w-full flex-col gap-3">
        <Btn tone="primary" onClick={onJoin} disabled={code.length < 4}>
          Drop in
        </Btn>
        <Btn onClick={onBack}>Back</Btn>
      </div>
    </PaperBg>
  );
}

function Lobby({
  room,
  name,
  isHost,
  team,
  fillBots,
  onFillBots,
  onTeam,
  onStart,
  onLeave,
}: {
  room: string;
  name: string;
  isHost: boolean;
  team: Team;
  fillBots: boolean;
  onFillBots: (v: boolean) => void;
  onTeam: (t: Team) => void;
  onStart: () => void;
  onLeave: () => void;
}) {
  const p2p = useP2PRoom({ room: `sz${room}`, name });
  const [roster, setRoster] = useState<LobbyPlayer[]>([]);
  const [ready, setReady] = useState(false);
  const [remoteStart, setRemoteStart] = useState(false);
  const started = useRef(false);

  useEffect(() => {
    const me: LobbyPlayer = {
      id: p2p.selfId,
      name,
      team,
      classId: 0,
      ready,
      connected: true,
    };
    setRoster((prev) => {
      const others = prev.filter((p) => p.id !== me.id && p.id !== "self");
      return [me, ...others];
    });
    p2p.send({ k: "hello", name, team, ready });
  }, [p2p, name, team, ready]);

  useEffect(() => {
    return p2p.onMessage((from, data) => {
      const m = data as { k?: string; name?: string; team?: Team; ready?: boolean };
      if (m.k === "hello") {
        setRoster((prev) => {
          const next = prev.filter((p) => p.id !== from);
          next.push({
            id: from,
            name: m.name || "Player",
            team: m.team === "DEFENSE" ? "DEFENSE" : "ATTACK",
            classId: 0,
            ready: !!m.ready,
            connected: true,
          });
          return next;
        });
      }
      if (m.k === "start" && !started.current) {
        started.current = true;
        setRemoteStart(true);
      }
    });
  }, [p2p]);

  useEffect(() => {
    const live = new Set(p2p.peers.map((p) => p.id));
    setRoster((prev) => prev.filter((p) => p.id === p2p.selfId || live.has(p.id)));
  }, [p2p.peers, p2p.selfId]);

  useEffect(() => {
    if (remoteStart) onStart();
  }, [remoteStart, onStart]);

  const start = () => {
    p2p.send({ k: "start", fillBots });
    onStart();
  };

  return (
    <PaperBg>
      <p className="text-xs font-semibold tracking-[0.24em] text-muted uppercase">Room</p>
      <h2 className="font-display text-4xl tracking-[0.18em]">{room}</h2>
      <p className="mt-1 text-xs text-muted">
        {p2p.joined ? "Linked" : "Connecting…"} ·{" "}
        {room.startsWith("Q") ? "public quick lobby — others may join anytime" : "share this code with friends"}
      </p>
      <div className="mt-6 w-full rounded-xl border border-line bg-surface p-3">
        {roster.length === 0 && <p className="px-2 py-3 text-sm text-muted">Waiting for friends…</p>}
        {roster.map((p) => (
          <div key={p.id} className="flex items-center justify-between gap-3 rounded-md px-2 py-2">
            <span className="font-semibold">{p.name}</span>
            <span className={`text-xs font-bold ${p.team === "ATTACK" ? "text-attack" : "text-defense"}`}>
              {p.team} {p.ready ? "· ready" : ""}
            </span>
          </div>
        ))}
        <PeerHint peers={p2p.peers} />
      </div>
      <div className="mt-4 grid w-full grid-cols-2 gap-3">
        <Btn tone={team === "ATTACK" ? "attack" : "ghost"} onClick={() => onTeam("ATTACK")} icon={<Swords className="size-4" />}>
          Attack
        </Btn>
        <Btn tone={team === "DEFENSE" ? "defense" : "ghost"} onClick={() => onTeam("DEFENSE")} icon={<Shield className="size-4" />}>
          Defense
        </Btn>
      </div>
      <label className="mt-4 flex w-full items-center gap-2 text-sm font-semibold text-ink-soft">
        <input type="checkbox" checked={fillBots} onChange={(e) => onFillBots(e.target.checked)} />
        Fill empty slots with bots
      </label>
      <div className="mt-5 flex w-full flex-col gap-3">
        <Btn tone="ghost" onClick={() => setReady((r) => !r)}>
          {ready ? "Ready" : "Mark ready"}
        </Btn>
        {isHost ? (
          <Btn tone="primary" onClick={start} icon={<Play className="size-4" />}>
            Start match
          </Btn>
        ) : (
          <p className="text-center text-xs text-muted">Host starts the match</p>
        )}
        <Btn onClick={onLeave}>Leave</Btn>
      </div>
    </PaperBg>
  );
}

function PeerHint({ peers }: { peers: PeerInfo[] }) {
  if (!peers.length) return null;
  return (
    <div className="mt-2 border-t border-line pt-2 text-[11px] text-muted">
      {peers.map((p) => (
        <div key={p.id}>
          {p.name || p.id} · {p.connectionState}
          {p.rttMs != null ? ` · ${p.rttMs}ms` : ""}
        </div>
      ))}
    </div>
  );
}

function ClassSelect({
  team,
  classId,
  onTeam,
  onClass,
  onEnter,
  onBack,
}: {
  team: Team;
  classId: ClassId;
  onTeam: (t: Team) => void;
  onClass: (id: ClassId) => void;
  onEnter: () => void;
  onBack: () => void;
}) {
  const list = classesFor(team);
  const selected = list.find((c) => c.id === classId) ?? list[0];
  return (
    <div className="flex h-full w-full flex-col overflow-auto px-4 py-6">
      <div className="mx-auto w-full max-w-4xl">
        <p className="text-xs font-semibold tracking-[0.28em] text-muted uppercase">Operator Select</p>
        <h2 className="font-display text-3xl md:text-4xl">Choose your crayon</h2>
        <p className="mt-1 text-sm text-ink-soft">
          Attack pushes the gold site. Defense holds it. Gadgets decide the round.
        </p>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <Btn tone={team === "ATTACK" ? "attack" : "ghost"} onClick={() => onTeam("ATTACK")}>
            <Swords className="size-4" /> Attack
          </Btn>
          <Btn tone={team === "DEFENSE" ? "defense" : "ghost"} onClick={() => onTeam("DEFENSE")}>
            <Shield className="size-4" /> Defense
          </Btn>
        </div>
        <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((c) => {
            const hex = "#" + c.color.toString(16).padStart(6, "0");
            const active = classId === c.id;
            return (
              <button
                key={c.id}
                onClick={() => onClass(c.id)}
                className={`group relative overflow-hidden rounded-xl border bg-surface p-4 text-left transition ${
                  active ? "border-ink ring-2 ring-crayon shadow-md" : "border-line hover:border-ink/40"
                }`}
              >
                <div
                  className="absolute left-0 top-0 h-full w-1.5"
                  style={{ backgroundColor: hex }}
                />
                <div className="flex items-baseline justify-between gap-2 pl-2">
                  <span className="font-display text-lg">{c.name}</span>
                  <span className="rounded bg-ink/5 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-muted">
                    {c.role}
                  </span>
                </div>
                <p className="mt-1.5 pl-2 text-sm leading-snug text-ink-soft">{c.blurb}</p>
                <div className="mt-3 flex flex-wrap gap-x-3 gap-y-1 pl-2 text-[11px] font-semibold text-muted">
                  <span>{c.damage} dmg</span>
                  <span>{c.rpm} rpm</span>
                  <span className="text-ink">{c.gadgetName}</span>
                </div>
              </button>
            );
          })}
        </div>
        {selected && (
          <div className="mt-5 rounded-xl border border-line bg-surface/80 px-4 py-3">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted">Selected</p>
            <p className="font-display text-xl">
              {selected.name}{" "}
              <span className="text-sm font-sans text-muted">· {selected.gadgetName}</span>
            </p>
          </div>
        )}
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <Btn tone="primary" onClick={onEnter} icon={<Play className="size-4" />}>
            Deploy
          </Btn>
          <Btn onClick={onBack}>Back</Btn>
        </div>
      </div>
    </div>
  );
}

function PlayView({
  name,
  team,
  classId,
  room,
  isHost,
  practice,
  fillBots,
  settings,
  muted,
  onMute,
  onExit,
}: {
  name: string;
  team: Team;
  classId: ClassId;
  room: string | null;
  isHost: boolean;
  practice: boolean;
  fillBots: boolean;
  settings: MatchSettings;
  muted: boolean;
  onMute: (v: boolean) => void;
  onExit: () => void;
}) {
  if (practice || !room) {
    return (
      <MatchCanvas
        name={name}
        team={team}
        classId={classId}
        selfId="local"
        isHost
        practice
        fillBots
        settings={settings}
        muted={muted}
        onMute={onMute}
        onExit={onExit}
      />
    );
  }
  return (
    <OnlineMatch
      name={name}
      team={team}
      classId={classId}
      room={room}
      isHost={isHost}
      fillBots={fillBots}
      settings={settings}
      muted={muted}
      onMute={onMute}
      onExit={onExit}
    />
  );
}

function OnlineMatch(props: {
  name: string;
  team: Team;
  classId: ClassId;
  room: string;
  isHost: boolean;
  fillBots: boolean;
  settings: MatchSettings;
  muted: boolean;
  onMute: (v: boolean) => void;
  onExit: () => void;
}) {
  const p2p = useP2PRoom({ room: `sz${props.room}`, name: props.name });
  return (
    <MatchCanvas
      {...props}
      selfId={p2p.selfId}
      practice={false}
      sendState={p2p.broadcast}
      sendEvent={p2p.send}
      onMessage={p2p.onMessage}
      peers={p2p.peers}
    />
  );
}

function MatchCanvas({
  name,
  team,
  classId,
  selfId,
  isHost,
  practice,
  fillBots,
  settings,
  muted,
  onMute,
  onExit,
  sendState,
  sendEvent,
  onMessage,
  peers,
}: {
  name: string;
  team: Team;
  classId: ClassId;
  selfId: string;
  isHost: boolean;
  practice: boolean;
  fillBots: boolean;
  settings: MatchSettings;
  muted: boolean;
  onMute: (v: boolean) => void;
  onExit: () => void;
  sendState?: (d: unknown) => void;
  sendEvent?: (d: unknown) => void;
  onMessage?: (
    fn: (from: string, data: unknown, channel: "state" | "reliable") => void,
  ) => () => void;
  peers?: PeerInfo[];
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<SeazureEngine | null>(null);
  const [hud, setHud] = useState<HudSnap | null>(null);
  const [needClick, setNeedClick] = useState(true);
  const cls = getClass(team, classId);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    unlockAudio();
    const opts: EngineOpts = {
      canvas,
      team,
      classId,
      name,
      selfId,
      isHost,
      fillBots: practice || fillBots,
      practice,
      settings,
      onHud: setHud,
      sendState,
      sendEvent,
    };
    const eng = new SeazureEngine(opts);
    engineRef.current = eng;
    eng.start();
    return () => {
      eng.stop();
      engineRef.current = null;
    };
    // engine is created once per mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!onMessage) return;
    return onMessage((from, data) => engineRef.current?.handleNet(from, data));
  }, [onMessage]);

  useEffect(() => {
    const live = new Set((peers ?? []).map((p) => p.id));
    // drop handled when engine sees missing remotes via timeout; optional
    void live;
  }, [peers]);

  const onCanvasClick = () => {
    unlockAudio();
    engineRef.current?.requestLock();
    setNeedClick(false);
  };

  return (
    <div className="relative h-full w-full bg-ink">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full touch-none"
        onClick={onCanvasClick}
      />
      {hud && (
        <Hud
          hud={hud}
          className={cls.name}
          needClick={needClick && !hud.locked}
          muted={muted}
          onMute={() => onMute(!muted)}
          onResume={() => {
            setNeedClick(false);
            engineRef.current?.setPaused(false);
            engineRef.current?.requestLock();
          }}
          onExit={onExit}
        />
      )}
      <TouchPad
        onMove={(x, y) => engineRef.current?.setTouchMove(x, y)}
        onLook={(x, y) => engineRef.current?.setTouchLook(x, y)}
        onFire={(v) => engineRef.current?.setFiring(v)}
        onJump={() => engineRef.current?.tapJump()}
        onReload={() => engineRef.current?.tapReload()}
        onGadget={() => engineRef.current?.tapGadget()}
        gadget={cls.gadgetName}
      />
    </div>
  );
}

function Hud({
  hud,
  className,
  needClick,
  muted,
  onMute,
  onResume,
  onExit,
}: {
  hud: HudSnap;
  className: string;
  needClick: boolean;
  muted: boolean;
  onMute: () => void;
  onResume: () => void;
  onExit: () => void;
}) {
  return (
    <div className="pointer-events-none absolute inset-0 z-30 text-ink">
      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-3 pt-[max(12px,env(safe-area-inset-top))]">
        <div className="rounded-lg border border-line bg-surface/90 px-3 py-2 shadow-stamp">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide">
            <span className={hud.team === "ATTACK" ? "text-attack" : "text-defense"}>{hud.team}</span>
            <span className="text-muted">{className}</span>
          </div>
          <div className="mt-1 font-display text-lg tabular-nums">
            {hud.scoreA} <span className="text-muted">-</span> {hud.scoreD}
          </div>
        </div>
        <div className="rounded-lg border border-line bg-surface/90 px-3 py-2 text-center shadow-stamp">
          <div className="text-[10px] font-bold uppercase tracking-widest text-muted">
            {hud.phase} · r{hud.round}/{hud.maxRounds}
          </div>
          <div className="font-display text-2xl tabular-nums leading-none">{fmtTime(hud.timer)}</div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <button
            type="button"
            onClick={onMute}
            className="pointer-events-auto grid size-11 place-items-center rounded-lg border border-line bg-surface/90"
            aria-label={muted ? "Unmute" : "Mute"}
          >
            {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
          </button>
        </div>
      </div>

      <div className="absolute left-3 top-28 w-40">
        <div className="h-2 overflow-hidden rounded-full bg-ink/20">
          <div
            className="h-full rounded-full bg-danger transition-[width] duration-150"
            style={{ width: `${clamp01(hud.hp / 100) * 100}%` }}
          />
        </div>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-ink/20">
          <div className="h-full rounded-full bg-crayon" style={{ width: `${clamp01(hud.obj) * 100}%` }} />
        </div>
        <p className="mt-1 text-[10px] font-bold uppercase tracking-wide text-surface">
          {hud.phase === "action" && hud.obj > 0 && hud.obj < 1
            ? `Bomb ${Math.round(hud.obj * 100)}%`
            : hud.phase === "action" && hud.obj >= 1
              ? "Fuse"
              : `Bomb ${Math.round(hud.obj * 100)}%`}
        </p>
      </div>

      <div className="absolute right-3 top-28 max-w-[46%] text-right text-xs font-semibold text-surface drop-shadow">
        {hud.feed.map((f, i) => (
          <div key={i}>{f}</div>
        ))}
      </div>

      <div
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 font-display text-2xl text-surface"
        style={{ opacity: 0.9 + hud.hit * 0.1, transform: `translate(-50%,-50%) scale(${1 + hud.hit * 0.4})` }}
      >
        <Crosshair className="size-6" strokeWidth={2.4} />
      </div>
      {hud.hit > 0.05 && (
        <div className="absolute left-1/2 top-[48%] -translate-x-1/2 font-display text-lg text-crayon">+</div>
      )}

      {hud.notice && (
        <div className="absolute left-1/2 top-20 -translate-x-1/2 rounded-md bg-surface/90 px-3 py-1.5 text-sm font-semibold shadow-stamp">
          {hud.notice}
        </div>
      )}

      {!hud.alive && (
        <div className="absolute inset-0 grid place-items-center bg-ink/45 pointer-events-none">
          <div className="rounded-xl border border-line bg-surface px-6 py-5 text-center shadow-stamp">
            <p className="font-display text-2xl">Inked</p>
            <p className="mt-1 text-sm text-ink-soft">Spectating — next round you return</p>
            <p className="mt-2 text-xs text-ink-soft">Eliminate the other team or hold the site</p>
          </div>
        </div>
      )}

      <div className="absolute bottom-24 left-1/2 hidden -translate-x-1/2 text-xs font-semibold text-surface drop-shadow md:block">
        WASD · Shift sprint · Click fire · R reload · Q gadget · Hold E reinforce (prep) · Esc pause
      </div>

      <div className="absolute bottom-[max(16px,env(safe-area-inset-bottom))] left-3 right-3 flex items-end justify-between gap-3">
        <div className="rounded-lg border border-line bg-surface/90 px-3 py-2 shadow-stamp">
          <div className="flex items-center gap-2 font-display text-2xl tabular-nums">
            <Pencil className="size-4" />
            {hud.reloading ? "…" : hud.ammo}
            <span className="text-sm text-muted">/{hud.mag}</span>
          </div>
          <div className="text-[10px] font-bold uppercase tracking-wide text-muted">
            {hud.gadgetReady ? hud.gadgetName : "Gadget charging"}
          </div>
        </div>
        <div className="rounded-lg border border-line bg-surface/90 px-3 py-2 text-right text-xs font-semibold shadow-stamp">
          <div>{hud.allies} up</div>
          <div className="text-muted">{hud.enemies} opposed</div>
        </div>
      </div>

      {hud.hurt > 0 && (
        <div
          className="absolute inset-0 bg-danger/25"
          style={{ opacity: hud.hurt * 0.55 }}
        />
      )}

      {needClick && !hud.paused && !hud.result && (
        <div className="pointer-events-auto absolute inset-0 z-40 grid place-items-center bg-ink/35">
          <button
            type="button"
            onClick={onResume}
            className="rounded-xl border border-line bg-surface px-8 py-5 font-display text-xl shadow-stamp"
          >
            Click to play
          </button>
        </div>
      )}

      {(hud.paused || hud.result) && (
        <div className="pointer-events-auto absolute inset-0 z-40 grid place-items-center bg-ink/50 px-4">
          <div className="w-full max-w-sm rounded-xl border border-line bg-surface p-6 text-center shadow-stamp">
            <h2 className="font-display text-3xl">
              {hud.result ? (hud.matchWinner === hud.team ? "Victory" : "Defeat") : "Paused"}
            </h2>
            {hud.result && (
              <p className="mt-2 text-sm text-ink-soft">
                {hud.matchWinner === "ATTACK" ? "Attack inked the pad." : "Defense held the site."}
                {"  "}
                {hud.scoreA} – {hud.scoreD}
              </p>
            )}
            <div className="mt-5 flex flex-col gap-3">
              {!hud.result && (
                <Btn tone="primary" onClick={onResume}>
                  Resume
                </Btn>
              )}
              <Btn onClick={onExit}>Leave match</Btn>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function TouchPad({
  onMove,
  onLook,
  onFire,
  onJump,
  onReload,
  onGadget,
  gadget,
}: {
  onMove: (x: number, y: number) => void;
  onLook: (dx: number, dy: number) => void;
  onFire: (v: boolean) => void;
  onJump: () => void;
  onReload: () => void;
  onGadget: () => void;
  gadget: string;
}) {
  const stick = useRef<{ id: number; x: number; y: number } | null>(null);
  const look = useRef<{ id: number; x: number; y: number } | null>(null);

  const onPointerDown = (e: React.PointerEvent) => {
    const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = e.clientX - r.left;
    if (x < r.width * 0.42) {
      stick.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
    } else {
      look.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
    }
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (stick.current?.id === e.pointerId) {
      const dx = (e.clientX - stick.current.x) / 46;
      const dy = (e.clientY - stick.current.y) / 46;
      const m = Math.hypot(dx, dy) || 1;
      const s = Math.min(1, m);
      onMove((dx / m) * s, (-dy / m) * s);
    }
    if (look.current?.id === e.pointerId) {
      onLook(e.clientX - look.current.x, e.clientY - look.current.y);
      look.current.x = e.clientX;
      look.current.y = e.clientY;
    }
  };
  const end = (e: React.PointerEvent) => {
    if (stick.current?.id === e.pointerId) {
      stick.current = null;
      onMove(0, 0);
    }
    if (look.current?.id === e.pointerId) look.current = null;
  };

  return (
    <div className="pointer-events-none absolute inset-0 z-20 md:pointer-events-none">
      <div
        className="pointer-events-auto absolute inset-x-0 bottom-0 top-28 md:hidden"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={end}
        onPointerCancel={end}
      />
      <div className="pointer-events-auto absolute bottom-[max(88px,env(safe-area-inset-bottom))] right-3 flex flex-col gap-2 md:hidden">
        <TouchBtn onPress={() => onFire(true)} onRelease={() => onFire(false)}>
          Fire
        </TouchBtn>
        <TouchBtn onPress={onGadget}>{gadget}</TouchBtn>
        <div className="grid grid-cols-2 gap-2">
          <TouchBtn onPress={onJump}>Jump</TouchBtn>
          <TouchBtn onPress={onReload}>Reload</TouchBtn>
        </div>
      </div>
    </div>
  );
}

function TouchBtn({
  children,
  onPress,
  onRelease,
}: {
  children: React.ReactNode;
  onPress: () => void;
  onRelease?: () => void;
}) {
  return (
    <button
      type="button"
      className="min-h-11 min-w-20 rounded-lg border border-line bg-surface/90 px-3 py-2 text-xs font-bold uppercase tracking-wide text-ink shadow-stamp"
      onPointerDown={(e) => {
        e.stopPropagation();
        onPress();
      }}
      onPointerUp={(e) => {
        e.stopPropagation();
        onRelease?.();
      }}
      onPointerCancel={() => onRelease?.()}
    >
      {children}
    </button>
  );
}

function Btn({
  children,
  onClick,
  tone = "ghost",
  icon,
  disabled,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  tone?: "ghost" | "primary" | "accent" | "attack" | "defense";
  icon?: React.ReactNode;
  disabled?: boolean;
}) {
  const tones: Record<string, string> = {
    ghost: "bg-surface text-ink border-line",
    primary: "bg-ink text-paper border-ink",
    accent: "bg-crayon text-ink border-ink",
    attack: "bg-attack text-attack-fg border-ink",
    defense: "bg-defense text-defense-fg border-ink",
  };
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={`flex h-12 w-full items-center justify-center gap-2 rounded-lg border px-4 text-sm font-bold tracking-wide transition enabled:active:translate-y-px disabled:opacity-40 ${tones[tone]}`}
    >
      {icon}
      {children}
    </button>
  );
}

function clamp01(v: number) {
  return Math.max(0, Math.min(1, v));
}

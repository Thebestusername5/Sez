/**
 * Data-driven map / level system.
 * To add a new level: append a MapDef to MAPS and give it a unique id.
 * The builder turns the declarative boxes into colliders + meshes.
 */

import * as THREE from "three";
import type { AABB } from "./types";

export interface SpawnPoint {
  x: number;
  z: number;
}

export interface SoftWallDef {
  x: number;
  y: number;
  z: number;
  sx: number;
  sy: number;
  sz: number;
  hp: number;
  id: string;
}

export interface BoxDef {
  x: number;
  y: number;
  z: number;
  sx: number;
  sy: number;
  sz: number;
  kind?: "wall" | "crate" | "breach";
  mat?: "outer" | "inner" | "crate" | "soft";
}

export interface MapDef {
  id: string;
  name: string;
  blurb: string;
  bounds: { minx: number; maxx: number; minz: number; maxz: number };
  site: { x: number; z: number; half: number };
  attackSpawns: SpawnPoint[];
  defenseSpawns: SpawnPoint[];
  boxes: BoxDef[];
  softWalls: SoftWallDef[];
  props?: { type: "crayon"; x: number; z: number; color: number }[];
}

export const MAPS: MapDef[] = [
  // ============================================================
  // 1. PAPER FORTRESS — Clubhouse-inspired multi-wing (BIG)
  // ============================================================
  {
    id: "paper-fortress",
    name: "Paper Fortress",
    blurb: "Huge multi-wing fortress. Garage wing, bar, site hall, four soft breaches.",
    bounds: { minx: -40, maxx: 40, minz: -34, maxz: 34 },
    site: { x: 0, z: -8, half: 3.6 },
    attackSpawns: [
      { x: 0, z: 30 }, { x: -10, z: 29 }, { x: 10, z: 29 },
      { x: -20, z: 28 }, { x: 20, z: 28 },
    ],
    defenseSpawns: [
      { x: 0, z: -30 }, { x: -9, z: -29 }, { x: 9, z: -29 },
      { x: -18, z: -28 }, { x: 18, z: -28 },
    ],
    boxes: [
      // Outer shell
      { x: 0, y: 2.3, z: -34.4, sx: 82, sy: 4.6, sz: 0.7, mat: "outer" },
      { x: 0, y: 2.3, z: 34.4, sx: 82, sy: 4.6, sz: 0.7, mat: "outer" },
      { x: -40.4, y: 2.3, z: 0, sx: 0.7, sy: 4.6, sz: 69, mat: "outer" },
      { x: 40.4, y: 2.3, z: 0, sx: 0.7, sy: 4.6, sz: 69, mat: "outer" },
      // Site hall frame
      { x: -12, y: 2.3, z: -14, sx: 16, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: 12, y: 2.3, z: -14, sx: 16, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: -16, y: 2.3, z: -20, sx: 0.5, sy: 4.6, sz: 12, mat: "inner" },
      { x: 16, y: 2.3, z: -20, sx: 0.5, sy: 4.6, sz: 12, mat: "inner" },
      // Bar / lounge (left of site)
      { x: -22, y: 2.3, z: -10, sx: 0.5, sy: 4.6, sz: 14, mat: "inner" },
      { x: -28, y: 2.3, z: -4, sx: 10, sy: 4.6, sz: 0.5, mat: "inner" },
      // Garage wing (right)
      { x: 22, y: 2.3, z: -10, sx: 0.5, sy: 4.6, sz: 14, mat: "inner" },
      { x: 28, y: 2.3, z: -4, sx: 10, sy: 4.6, sz: 0.5, mat: "inner" },
      // Mid chokepoints
      { x: -10, y: 2.3, z: 4, sx: 12, sy: 4.6, sz: 0.45, mat: "inner" },
      { x: 10, y: 2.3, z: 4, sx: 12, sy: 4.6, sz: 0.45, mat: "inner" },
      { x: -20, y: 2.3, z: 4, sx: 0.45, sy: 4.6, sz: 14, mat: "inner" },
      { x: 20, y: 2.3, z: 4, sx: 0.45, sy: 4.6, sz: 14, mat: "inner" },
      // Attack cover crates
      { x: -8, y: 0.75, z: 18, sx: 3.2, sy: 1.5, sz: 1.4, kind: "crate", mat: "crate" },
      { x: 8, y: 0.75, z: 18, sx: 3.2, sy: 1.5, sz: 1.4, kind: "crate", mat: "crate" },
      { x: 0, y: 0.75, z: 22, sx: 4.5, sy: 1.5, sz: 1.6, kind: "crate", mat: "crate" },
      { x: -16, y: 0.75, z: 12, sx: 2.5, sy: 1.5, sz: 2.5, kind: "crate", mat: "crate" },
      { x: 16, y: 0.75, z: 12, sx: 2.5, sy: 1.5, sz: 2.5, kind: "crate", mat: "crate" },
      // Site cover
      { x: -5, y: 0.7, z: -8, sx: 2.6, sy: 1.4, sz: 1.5, kind: "crate", mat: "crate" },
      { x: 5, y: 0.7, z: -8, sx: 2.6, sy: 1.4, sz: 1.5, kind: "crate", mat: "crate" },
      { x: 0, y: 0.7, z: -11, sx: 3.5, sy: 1.4, sz: 1.3, kind: "crate", mat: "crate" },
      { x: -10, y: 0.7, z: -5, sx: 1.6, sy: 1.4, sz: 2.6, kind: "crate", mat: "crate" },
      { x: 10, y: 0.7, z: -5, sx: 1.6, sy: 1.4, sz: 2.6, kind: "crate", mat: "crate" },
      // Bar furniture
      { x: -26, y: 0.7, z: -10, sx: 4, sy: 1.3, sz: 1.2, kind: "crate", mat: "crate" },
      { x: 26, y: 0.7, z: -10, sx: 4, sy: 1.3, sz: 1.2, kind: "crate", mat: "crate" },
      // Defense rear
      { x: -6, y: 0.7, z: -22, sx: 2.8, sy: 1.4, sz: 1.4, kind: "crate", mat: "crate" },
      { x: 6, y: 0.7, z: -22, sx: 2.8, sy: 1.4, sz: 1.4, kind: "crate", mat: "crate" },
    ],
    softWalls: [
      { x: 0, y: 2.2, z: -14, sx: 8, sy: 4.3, sz: 0.4, hp: 220, id: "pf-main" },
      { x: -16, y: 2.2, z: -10, sx: 0.4, sy: 4.3, sz: 6, hp: 170, id: "pf-l" },
      { x: 16, y: 2.2, z: -10, sx: 0.4, sy: 4.3, sz: 6, hp: 170, id: "pf-r" },
      { x: 0, y: 2.2, z: 4, sx: 7, sy: 4.3, sz: 0.4, hp: 150, id: "pf-mid" },
      { x: -22, y: 2.2, z: -4, sx: 0.4, sy: 4.3, sz: 5, hp: 140, id: "pf-bar" },
      { x: 22, y: 2.2, z: -4, sx: 0.4, sy: 4.3, sz: 5, hp: 140, id: "pf-garage" },
    ],
    props: [
      { type: "crayon", x: -24, z: 20, color: 0xff5a3c },
      { type: "crayon", x: 24, z: 20, color: 0x4f63ff },
      { type: "crayon", x: -12, z: -26, color: 0xffd24a },
      { type: "crayon", x: 12, z: -26, color: 0x3dffb0 },
      { type: "crayon", x: 0, z: 10, color: 0xff8ad4 },
      { type: "crayon", x: -30, z: -8, color: 0xff9a4a },
      { type: "crayon", x: 30, z: -8, color: 0x7a9aff },
    ],
  },

  // ============================================================
  // 2. INK YARD — Border/Yard inspired open + containers (HUGE)
  // ============================================================
  {
    id: "ink-yard",
    name: "Ink Yard",
    blurb: "Massive open yard, shipping-crate labyrinth, long rotates, three soft entries.",
    bounds: { minx: -44, maxx: 44, minz: -36, maxz: 36 },
    site: { x: 0, z: -10, half: 4.0 },
    attackSpawns: [
      { x: 0, z: 32 }, { x: -12, z: 31 }, { x: 12, z: 31 },
      { x: -24, z: 30 }, { x: 24, z: 30 },
    ],
    defenseSpawns: [
      { x: 0, z: -32 }, { x: -11, z: -31 }, { x: 11, z: -31 },
      { x: -22, z: -30 }, { x: 22, z: -30 },
    ],
    boxes: [
      { x: 0, y: 2.3, z: -36.5, sx: 90, sy: 4.6, sz: 0.8, mat: "outer" },
      { x: 0, y: 2.3, z: 36.5, sx: 90, sy: 4.6, sz: 0.8, mat: "outer" },
      { x: -44.5, y: 2.3, z: 0, sx: 0.8, sy: 4.6, sz: 74, mat: "outer" },
      { x: 44.5, y: 2.3, z: 0, sx: 0.8, sy: 4.6, sz: 74, mat: "outer" },
      // Site bunker
      { x: -14, y: 2.3, z: -16, sx: 18, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: 14, y: 2.3, z: -16, sx: 18, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: -18, y: 2.3, z: -22, sx: 0.5, sy: 4.6, sz: 12, mat: "inner" },
      { x: 18, y: 2.3, z: -22, sx: 0.5, sy: 4.6, sz: 12, mat: "inner" },
      // Container rows (mid field)
      { x: -16, y: 1.2, z: 8, sx: 5.5, sy: 2.4, sz: 2.6, kind: "crate", mat: "crate" },
      { x: -9, y: 1.2, z: 8, sx: 5.5, sy: 2.4, sz: 2.6, kind: "crate", mat: "crate" },
      { x: 9, y: 1.2, z: 8, sx: 5.5, sy: 2.4, sz: 2.6, kind: "crate", mat: "crate" },
      { x: 16, y: 1.2, z: 8, sx: 5.5, sy: 2.4, sz: 2.6, kind: "crate", mat: "crate" },
      { x: -12, y: 1.2, z: 14, sx: 5.5, sy: 2.4, sz: 2.6, kind: "crate", mat: "crate" },
      { x: 12, y: 1.2, z: 14, sx: 5.5, sy: 2.4, sz: 2.6, kind: "crate", mat: "crate" },
      { x: 0, y: 1.2, z: 18, sx: 6.5, sy: 2.4, sz: 2.8, kind: "crate", mat: "crate" },
      { x: -6, y: 1.2, z: 22, sx: 4, sy: 2.4, sz: 2.4, kind: "crate", mat: "crate" },
      { x: 6, y: 1.2, z: 22, sx: 4, sy: 2.4, sz: 2.4, kind: "crate", mat: "crate" },
      // Side lanes / rotates
      { x: -32, y: 1.2, z: 2, sx: 3.5, sy: 2.4, sz: 10, kind: "crate", mat: "crate" },
      { x: 32, y: 1.2, z: 2, sx: 3.5, sy: 2.4, sz: 10, kind: "crate", mat: "crate" },
      { x: -32, y: 1.2, z: -14, sx: 3.5, sy: 2.4, sz: 8, kind: "crate", mat: "crate" },
      { x: 32, y: 1.2, z: -14, sx: 3.5, sy: 2.4, sz: 8, kind: "crate", mat: "crate" },
      // Site furniture
      { x: -6, y: 0.75, z: -10, sx: 3, sy: 1.5, sz: 1.6, kind: "crate", mat: "crate" },
      { x: 6, y: 0.75, z: -10, sx: 3, sy: 1.5, sz: 1.6, kind: "crate", mat: "crate" },
      { x: 0, y: 0.75, z: -13, sx: 3.8, sy: 1.5, sz: 1.4, kind: "crate", mat: "crate" },
      { x: -12, y: 0.75, z: -6, sx: 1.8, sy: 1.5, sz: 2.8, kind: "crate", mat: "crate" },
      { x: 12, y: 0.75, z: -6, sx: 1.8, sy: 1.5, sz: 2.8, kind: "crate", mat: "crate" },
    ],
    softWalls: [
      { x: 0, y: 2.2, z: -16, sx: 9, sy: 4.3, sz: 0.4, hp: 240, id: "iy-main" },
      { x: -18, y: 2.2, z: -12, sx: 0.4, sy: 4.3, sz: 6.5, hp: 180, id: "iy-l" },
      { x: 18, y: 2.2, z: -12, sx: 0.4, sy: 4.3, sz: 6.5, hp: 180, id: "iy-r" },
    ],
    props: [
      { type: "crayon", x: -28, z: 24, color: 0xff5a3c },
      { type: "crayon", x: 28, z: 24, color: 0x4f63ff },
      { type: "crayon", x: 0, z: -28, color: 0xffd24a },
      { type: "crayon", x: -36, z: -4, color: 0x3dffb0 },
      { type: "crayon", x: 36, z: -4, color: 0xff8ad4 },
      { type: "crayon", x: -20, z: 4, color: 0xff9a4a },
      { type: "crayon", x: 20, z: 4, color: 0x7a9aff },
    ],
  },

  // ============================================================
  // 3. CRAYON CITADEL — Bank-inspired central hall + corridors
  // ============================================================
  {
    id: "crayon-citadel",
    name: "Crayon Citadel",
    blurb: "Grand central hall, tight side corridors, strong anchors, sneaky rotates.",
    bounds: { minx: -36, maxx: 36, minz: -32, maxz: 32 },
    site: { x: 0, z: -6, half: 3.4 },
    attackSpawns: [
      { x: 0, z: 28 }, { x: -9, z: 27 }, { x: 9, z: 27 },
      { x: -18, z: 26 }, { x: 18, z: 26 },
    ],
    defenseSpawns: [
      { x: 0, z: -28 }, { x: -8, z: -27 }, { x: 8, z: -27 },
      { x: -16, z: -26 }, { x: 16, z: -26 },
    ],
    boxes: [
      { x: 0, y: 2.3, z: -32.4, sx: 74, sy: 4.6, sz: 0.7, mat: "outer" },
      { x: 0, y: 2.3, z: 32.4, sx: 74, sy: 4.6, sz: 0.7, mat: "outer" },
      { x: -36.4, y: 2.3, z: 0, sx: 0.7, sy: 4.6, sz: 65, mat: "outer" },
      { x: 36.4, y: 2.3, z: 0, sx: 0.7, sy: 4.6, sz: 65, mat: "outer" },
      // Grand hall pillars
      { x: -7, y: 2.3, z: -12, sx: 0.7, sy: 4.6, sz: 10, mat: "inner" },
      { x: 7, y: 2.3, z: -12, sx: 0.7, sy: 4.6, sz: 10, mat: "inner" },
      { x: -7, y: 2.3, z: 4, sx: 0.7, sy: 4.6, sz: 10, mat: "inner" },
      { x: 7, y: 2.3, z: 4, sx: 0.7, sy: 4.6, sz: 10, mat: "inner" },
      // Cross walls
      { x: -14, y: 2.3, z: -2, sx: 12, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: 14, y: 2.3, z: -2, sx: 12, sy: 4.6, sz: 0.5, mat: "inner" },
      // Side corridors
      { x: -24, y: 2.3, z: -10, sx: 0.5, sy: 4.6, sz: 20, mat: "inner" },
      { x: 24, y: 2.3, z: -10, sx: 0.5, sy: 4.6, sz: 20, mat: "inner" },
      { x: -24, y: 2.3, z: 10, sx: 10, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: 24, y: 2.3, z: 10, sx: 10, sy: 4.6, sz: 0.5, mat: "inner" },
      // Cover
      { x: 0, y: 0.75, z: -6, sx: 3.2, sy: 1.5, sz: 1.7, kind: "crate", mat: "crate" },
      { x: -5, y: 0.75, z: -10, sx: 2.2, sy: 1.5, sz: 2.2, kind: "crate", mat: "crate" },
      { x: 5, y: 0.75, z: -10, sx: 2.2, sy: 1.5, sz: 2.2, kind: "crate", mat: "crate" },
      { x: -12, y: 0.75, z: 8, sx: 2.6, sy: 1.5, sz: 1.6, kind: "crate", mat: "crate" },
      { x: 12, y: 0.75, z: 8, sx: 2.6, sy: 1.5, sz: 1.6, kind: "crate", mat: "crate" },
      { x: 0, y: 0.75, z: 16, sx: 4.5, sy: 1.5, sz: 1.6, kind: "crate", mat: "crate" },
      { x: -18, y: 0.75, z: -18, sx: 2.2, sy: 1.5, sz: 2.2, kind: "crate", mat: "crate" },
      { x: 18, y: 0.75, z: -18, sx: 2.2, sy: 1.5, sz: 2.2, kind: "crate", mat: "crate" },
      { x: -18, y: 0.75, z: 4, sx: 2, sy: 1.5, sz: 2, kind: "crate", mat: "crate" },
      { x: 18, y: 0.75, z: 4, sx: 2, sy: 1.5, sz: 2, kind: "crate", mat: "crate" },
    ],
    softWalls: [
      { x: 0, y: 2.2, z: -2, sx: 7.5, sy: 4.3, sz: 0.4, hp: 200, id: "cc-mid" },
      { x: -7, y: 2.2, z: -8, sx: 0.4, sy: 4.3, sz: 5, hp: 160, id: "cc-hall-l" },
      { x: 7, y: 2.2, z: -8, sx: 0.4, sy: 4.3, sz: 5, hp: 160, id: "cc-hall-r" },
      { x: -24, y: 2.2, z: 0, sx: 0.4, sy: 4.3, sz: 5.5, hp: 140, id: "cc-side-l" },
      { x: 24, y: 2.2, z: 0, sx: 0.4, sy: 4.3, sz: 5.5, hp: 140, id: "cc-side-r" },
    ],
    props: [
      { type: "crayon", x: -14, z: 22, color: 0xff5a3c },
      { type: "crayon", x: 14, z: 22, color: 0x4f63ff },
      { type: "crayon", x: 0, z: -24, color: 0xffd24a },
      { type: "crayon", x: -30, z: 6, color: 0x3dffb0 },
      { type: "crayon", x: 30, z: 6, color: 0xff8ad4 },
      { type: "crayon", x: -8, z: 0, color: 0xff9a4a },
      { type: "crayon", x: 8, z: 0, color: 0x7a9aff },
    ],
  },
  // ============================================================
  // 4. DOODLE DOCKS — coastal warehouse + pier (NEW)
  // ============================================================
  {
    id: "doodle-docks",
    name: "Doodle Docks",
    blurb: "Warehouse + pier. Long sightlines, water-side rotates, three soft entries.",
    bounds: { minx: -38, maxx: 38, minz: -30, maxz: 30 },
    site: { x: -4, z: -8, half: 3.5 },
    attackSpawns: [
      { x: 0, z: 26 }, { x: -10, z: 25 }, { x: 10, z: 25 },
      { x: -20, z: 24 }, { x: 20, z: 24 },
    ],
    defenseSpawns: [
      { x: -4, z: -26 }, { x: -12, z: -25 }, { x: 4, z: -25 },
      { x: -18, z: -24 }, { x: 10, z: -24 },
    ],
    boxes: [
      { x: 0, y: 2.3, z: -30.4, sx: 78, sy: 4.6, sz: 0.7, mat: "outer" },
      { x: 0, y: 2.3, z: 30.4, sx: 78, sy: 4.6, sz: 0.7, mat: "outer" },
      { x: -38.4, y: 2.3, z: 0, sx: 0.7, sy: 4.6, sz: 61, mat: "outer" },
      { x: 38.4, y: 2.3, z: 0, sx: 0.7, sy: 4.6, sz: 61, mat: "outer" },
      // Warehouse site
      { x: -14, y: 2.3, z: -14, sx: 16, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: 6, y: 2.3, z: -14, sx: 12, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: -18, y: 2.3, z: -20, sx: 0.5, sy: 4.6, sz: 12, mat: "inner" },
      { x: 10, y: 2.3, z: -18, sx: 0.5, sy: 4.6, sz: 8, mat: "inner" },
      // Pier lane
      { x: 22, y: 2.3, z: 0, sx: 0.5, sy: 4.6, sz: 28, mat: "inner" },
      { x: 30, y: 2.3, z: -8, sx: 10, sy: 4.6, sz: 0.5, mat: "inner" },
      // Mid crates
      { x: -8, y: 1.1, z: 6, sx: 4, sy: 2.2, sz: 2.4, kind: "crate", mat: "crate" },
      { x: 4, y: 1.1, z: 8, sx: 4, sy: 2.2, sz: 2.4, kind: "crate", mat: "crate" },
      { x: 16, y: 1.1, z: 4, sx: 3.5, sy: 2.2, sz: 3, kind: "crate", mat: "crate" },
      { x: -16, y: 0.7, z: -8, sx: 2.5, sy: 1.4, sz: 2, kind: "crate", mat: "crate" },
      { x: 0, y: 0.7, z: -10, sx: 3, sy: 1.4, sz: 1.5, kind: "crate", mat: "crate" },
      { x: 26, y: 0.7, z: 10, sx: 2.5, sy: 1.4, sz: 2.5, kind: "crate", mat: "crate" },
    ],
    softWalls: [
      { x: -4, y: 2.2, z: -14, sx: 7, sy: 4.3, sz: 0.4, hp: 200, id: "dd-main" },
      { x: -18, y: 2.2, z: -10, sx: 0.4, sy: 4.3, sz: 5.5, hp: 160, id: "dd-l" },
      { x: 10, y: 2.2, z: -10, sx: 0.4, sy: 4.3, sz: 5, hp: 150, id: "dd-r" },
    ],
    props: [
      { type: "crayon", x: -24, z: 18, color: 0xff5a3c },
      { type: "crayon", x: 24, z: 18, color: 0x4f63ff },
      { type: "crayon", x: -8, z: -22, color: 0xffd24a },
      { type: "crayon", x: 28, z: -4, color: 0x3dffb0 },
    ],
  },
  // ============================================================
  // 5. PASTEL PLAZA — open town square + alleys (NEW)
  // ============================================================
  {
    id: "pastel-plaza",
    name: "Pastel Plaza",
    blurb: "Open plaza with alley flanks. Vertical fountain cover, wide executes.",
    bounds: { minx: -34, maxx: 34, minz: -28, maxz: 28 },
    site: { x: 0, z: -5, half: 3.8 },
    attackSpawns: [
      { x: 0, z: 24 }, { x: -8, z: 23 }, { x: 8, z: 23 },
      { x: -16, z: 22 }, { x: 16, z: 22 },
    ],
    defenseSpawns: [
      { x: 0, z: -24 }, { x: -8, z: -23 }, { x: 8, z: -23 },
      { x: -15, z: -22 }, { x: 15, z: -22 },
    ],
    boxes: [
      { x: 0, y: 2.3, z: -28.4, sx: 70, sy: 4.6, sz: 0.7, mat: "outer" },
      { x: 0, y: 2.3, z: 28.4, sx: 70, sy: 4.6, sz: 0.7, mat: "outer" },
      { x: -34.4, y: 2.3, z: 0, sx: 0.7, sy: 4.6, sz: 57, mat: "outer" },
      { x: 34.4, y: 2.3, z: 0, sx: 0.7, sy: 4.6, sz: 57, mat: "outer" },
      // Plaza buildings
      { x: -16, y: 2.3, z: -12, sx: 10, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: 16, y: 2.3, z: -12, sx: 10, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: -18, y: 2.3, z: -6, sx: 0.5, sy: 4.6, sz: 10, mat: "inner" },
      { x: 18, y: 2.3, z: -6, sx: 0.5, sy: 4.6, sz: 10, mat: "inner" },
      // Fountain / center cover
      { x: 0, y: 0.9, z: 2, sx: 4, sy: 1.8, sz: 4, kind: "crate", mat: "crate" },
      { x: -6, y: 0.7, z: 8, sx: 2.5, sy: 1.4, sz: 2.5, kind: "crate", mat: "crate" },
      { x: 6, y: 0.7, z: 8, sx: 2.5, sy: 1.4, sz: 2.5, kind: "crate", mat: "crate" },
      { x: -10, y: 0.7, z: -6, sx: 2.2, sy: 1.4, sz: 2.2, kind: "crate", mat: "crate" },
      { x: 10, y: 0.7, z: -6, sx: 2.2, sy: 1.4, sz: 2.2, kind: "crate", mat: "crate" },
      { x: 0, y: 0.7, z: -8, sx: 3.2, sy: 1.4, sz: 1.6, kind: "crate", mat: "crate" },
      // Alleys
      { x: -24, y: 2.3, z: 4, sx: 0.5, sy: 4.6, sz: 16, mat: "inner" },
      { x: 24, y: 2.3, z: 4, sx: 0.5, sy: 4.6, sz: 16, mat: "inner" },
    ],
    softWalls: [
      { x: -8, y: 2.2, z: -12, sx: 5.5, sy: 4.3, sz: 0.4, hp: 180, id: "pp-l" },
      { x: 8, y: 2.2, z: -12, sx: 5.5, sy: 4.3, sz: 0.4, hp: 180, id: "pp-r" },
      { x: 0, y: 2.2, z: -12, sx: 4, sy: 4.3, sz: 0.4, hp: 160, id: "pp-mid" },
      { x: -18, y: 2.2, z: -2, sx: 0.4, sy: 4.3, sz: 4.5, hp: 140, id: "pp-alley-l" },
      { x: 18, y: 2.2, z: -2, sx: 0.4, sy: 4.3, sz: 4.5, hp: 140, id: "pp-alley-r" },
    ],
    props: [
      { type: "crayon", x: -20, z: 16, color: 0xff5a3c },
      { type: "crayon", x: 20, z: 16, color: 0x4f63ff },
      { type: "crayon", x: 0, z: -20, color: 0xffd24a },
      { type: "crayon", x: -12, z: 0, color: 0xff8ad4 },
      { type: "crayon", x: 12, z: 0, color: 0x3dffb0 },
    ],
  }

];

export function getMap
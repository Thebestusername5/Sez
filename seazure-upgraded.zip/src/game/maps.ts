/**
 * Data-driven map / level system.
 * To add a new level: append a MapDef to MAPS and give it a unique id.
 * The builder turns the declarative boxes into colliders + meshes.
 */

import * as THREE from "three";
import type { AABB } from "./types";

export interface SpawnPoint {
  x: number;
  z: number;
}

export interface SoftWallDef {
  x: number;
  y: number;
  z: number;
  sx: number;
  sy: number;
  sz: number;
  hp: number;
  id: string;
}

export interface BoxDef {
  x: number;
  y: number;
  z: number;
  sx: number;
  sy: number;
  sz: number;
  kind?: "wall" | "crate" | "breach";
  mat?: "outer" | "inner" | "crate" | "soft";
}

export interface MapDef {
  id: string;
  name: string;
  blurb: string;
  bounds: { minx: number; maxx: number; minz: number; maxz: number };
  site: { x: number; z: number; half: number };
  attackSpawns: SpawnPoint[];
  defenseSpawns: SpawnPoint[];
  boxes: BoxDef[];
  softWalls: SoftWallDef[];
  props?: { type: "crayon"; x: number; z: number; color: number }[];
}

export const MAPS: MapDef[] = [
  // ============================================================
  // 1. PAPER FORTRESS — Clubhouse-inspired multi-wing (BIG)
  // ============================================================
  {
    id: "paper-fortress",
    name: "Paper Fortress",
    blurb: "Huge multi-wing fortress. Garage wing, bar, site hall, four soft breaches.",
    bounds: { minx: -40, maxx: 40, minz: -34, maxz: 34 },
    site: { x: 0, z: -8, half: 3.6 },
    attackSpawns: [
      { x: 0, z: 30 }, { x: -10, z: 29 }, { x: 10, z: 29 },
      { x: -20, z: 28 }, { x: 20, z: 28 },
    ],
    defenseSpawns: [
      { x: 0, z: -30 }, { x: -9, z: -29 }, { x: 9, z: -29 },
      { x: -18, z: -28 }, { x: 18, z: -28 },
    ],
    boxes: [
      // Outer shell
      { x: 0, y: 2.3, z: -34.4, sx: 82, sy: 4.6, sz: 0.7, mat: "outer" },
      { x: 0, y: 2.3, z: 34.4, sx: 82, sy: 4.6, sz: 0.7, mat: "outer" },
      { x: -40.4, y: 2.3, z: 0, sx: 0.7, sy: 4.6, sz: 69, mat: "outer" },
      { x: 40.4, y: 2.3, z: 0, sx: 0.7, sy: 4.6, sz: 69, mat: "outer" },
      // Site hall frame
      { x: -12, y: 2.3, z: -14, sx: 16, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: 12, y: 2.3, z: -14, sx: 16, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: -16, y: 2.3, z: -20, sx: 0.5, sy: 4.6, sz: 12, mat: "inner" },
      { x: 16, y: 2.3, z: -20, sx: 0.5, sy: 4.6, sz: 12, mat: "inner" },
      // Bar / lounge (left of site)
      { x: -22, y: 2.3, z: -10, sx: 0.5, sy: 4.6, sz: 14, mat: "inner" },
      { x: -28, y: 2.3, z: -4, sx: 10, sy: 4.6, sz: 0.5, mat: "inner" },
      // Garage wing (right)
      { x: 22, y: 2.3, z: -10, sx: 0.5, sy: 4.6, sz: 14, mat: "inner" },
      { x: 28, y: 2.3, z: -4, sx: 10, sy: 4.6, sz: 0.5, mat: "inner" },
      // Mid chokepoints
      { x: -10, y: 2.3, z: 4, sx: 12, sy: 4.6, sz: 0.45, mat: "inner" },
      { x: 10, y: 2.3, z: 4, sx: 12, sy: 4.6, sz: 0.45, mat: "inner" },
      { x: -20, y: 2.3, z: 4, sx: 0.45, sy: 4.6, sz: 14, mat: "inner" },
      { x: 20, y: 2.3, z: 4, sx: 0.45, sy: 4.6, sz: 14, mat: "inner" },
      // Attack cover crates
      { x: -8, y: 0.75, z: 18, sx: 3.2, sy: 1.5, sz: 1.4, kind: "crate", mat: "crate" },
      { x: 8, y: 0.75, z: 18, sx: 3.2, sy: 1.5, sz: 1.4, kind: "crate", mat: "crate" },
      { x: 0, y: 0.75, z: 22, sx: 4.5, sy: 1.5, sz: 1.6, kind: "crate", mat: "crate" },
      { x: -16, y: 0.75, z: 12, sx: 2.5, sy: 1.5, sz: 2.5, kind: "crate", mat: "crate" },
      { x: 16, y: 0.75, z: 12, sx: 2.5, sy: 1.5, sz: 2.5, kind: "crate", mat: "crate" },
      // Site cover
      { x: -5, y: 0.7, z: -8, sx: 2.6, sy: 1.4, sz: 1.5, kind: "crate", mat: "crate" },
      { x: 5, y: 0.7, z: -8, sx: 2.6, sy: 1.4, sz: 1.5, kind: "crate", mat: "crate" },
      { x: 0, y: 0.7, z: -11, sx: 3.5, sy: 1.4, sz: 1.3, kind: "crate", mat: "crate" },
      { x: -10, y: 0.7, z: -5, sx: 1.6, sy: 1.4, sz: 2.6, kind: "crate", mat: "crate" },
      { x: 10, y: 0.7, z: -5, sx: 1.6, sy: 1.4, sz: 2.6, kind: "crate", mat: "crate" },
      // Bar furniture
      { x: -26, y: 0.7, z: -10, sx: 4, sy: 1.3, sz: 1.2, kind: "crate", mat: "crate" },
      { x: 26, y: 0.7, z: -10, sx: 4, sy: 1.3, sz: 1.2, kind: "crate", mat: "crate" },
      // Defense rear
      { x: -6, y: 0.7, z: -22, sx: 2.8, sy: 1.4, sz: 1.4, kind: "crate", mat: "crate" },
      { x: 6, y: 0.7, z: -22, sx: 2.8, sy: 1.4, sz: 1.4, kind: "crate", mat: "crate" },
    ],
    softWalls: [
      { x: 0, y: 2.2, z: -14, sx: 8, sy: 4.3, sz: 0.4, hp: 220, id: "pf-main" },
      { x: -16, y: 2.2, z: -10, sx: 0.4, sy: 4.3, sz: 6, hp: 170, id: "pf-l" },
      { x: 16, y: 2.2, z: -10, sx: 0.4, sy: 4.3, sz: 6, hp: 170, id: "pf-r" },
      { x: 0, y: 2.2, z: 4, sx: 7, sy: 4.3, sz: 0.4, hp: 150, id: "pf-mid" },
      { x: -22, y: 2.2, z: -4, sx: 0.4, sy: 4.3, sz: 5, hp: 140, id: "pf-bar" },
      { x: 22, y: 2.2, z: -4, sx: 0.4, sy: 4.3, sz: 5, hp: 140, id: "pf-garage" },
    ],
    props: [
      { type: "crayon", x: -24, z: 20, color: 0xff5a3c },
      { type: "crayon", x: 24, z: 20, color: 0x4f63ff },
      { type: "crayon", x: -12, z: -26, color: 0xffd24a },
      { type: "crayon", x: 12, z: -26, color: 0x3dffb0 },
      { type: "crayon", x: 0, z: 10, color: 0xff8ad4 },
      { type: "crayon", x: -30, z: -8, color: 0xff9a4a },
      { type: "crayon", x: 30, z: -8, color: 0x7a9aff },
    ],
  },

  // ============================================================
  // 2. INK YARD — Border/Yard inspired open + containers (HUGE)
  // ============================================================
  {
    id: "ink-yard",
    name: "Ink Yard",
    blurb: "Massive open yard, shipping-crate labyrinth, long rotates, three soft entries.",
    bounds: { minx: -44, maxx: 44, minz: -36, maxz: 36 },
    site: { x: 0, z: -10, half: 4.0 },
    attackSpawns: [
      { x: 0, z: 32 }, { x: -12, z: 31 }, { x: 12, z: 31 },
      { x: -24, z: 30 }, { x: 24, z: 30 },
    ],
    defenseSpawns: [
      { x: 0, z: -32 }, { x: -11, z: -31 }, { x: 11, z: -31 },
      { x: -22, z: -30 }, { x: 22, z: -30 },
    ],
    boxes: [
      { x: 0, y: 2.3, z: -36.5, sx: 90, sy: 4.6, sz: 0.8, mat: "outer" },
      { x: 0, y: 2.3, z: 36.5, sx: 90, sy: 4.6, sz: 0.8, mat: "outer" },
      { x: -44.5, y: 2.3, z: 0, sx: 0.8, sy: 4.6, sz: 74, mat: "outer" },
      { x: 44.5, y: 2.3, z: 0, sx: 0.8, sy: 4.6, sz: 74, mat: "outer" },
      // Site bunker
      { x: -14, y: 2.3, z: -16, sx: 18, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: 14, y: 2.3, z: -16, sx: 18, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: -18, y: 2.3, z: -22, sx: 0.5, sy: 4.6, sz: 12, mat: "inner" },
      { x: 18, y: 2.3, z: -22, sx: 0.5, sy: 4.6, sz: 12, mat: "inner" },
      // Container rows (mid field)
      { x: -16, y: 1.2, z: 8, sx: 5.5, sy: 2.4, sz: 2.6, kind: "crate", mat: "crate" },
      { x: -9, y: 1.2, z: 8, sx: 5.5, sy: 2.4, sz: 2.6, kind: "crate", mat: "crate" },
      { x: 9, y: 1.2, z: 8, sx: 5.5, sy: 2.4, sz: 2.6, kind: "crate", mat: "crate" },
      { x: 16, y: 1.2, z: 8, sx: 5.5, sy: 2.4, sz: 2.6, kind: "crate", mat: "crate" },
      { x: -12, y: 1.2, z: 14, sx: 5.5, sy: 2.4, sz: 2.6, kind: "crate", mat: "crate" },
      { x: 12, y: 1.2, z: 14, sx: 5.5, sy: 2.4, sz: 2.6, kind: "crate", mat: "crate" },
      { x: 0, y: 1.2, z: 18, sx: 6.5, sy: 2.4, sz: 2.8, kind: "crate", mat: "crate" },
      { x: -6, y: 1.2, z: 22, sx: 4, sy: 2.4, sz: 2.4, kind: "crate", mat: "crate" },
      { x: 6, y: 1.2, z: 22, sx: 4, sy: 2.4, sz: 2.4, kind: "crate", mat: "crate" },
      // Side lanes / rotates
      { x: -32, y: 1.2, z: 2, sx: 3.5, sy: 2.4, sz: 10, kind: "crate", mat: "crate" },
      { x: 32, y: 1.2, z: 2, sx: 3.5, sy: 2.4, sz: 10, kind: "crate", mat: "crate" },
      { x: -32, y: 1.2, z: -14, sx: 3.5, sy: 2.4, sz: 8, kind: "crate", mat: "crate" },
      { x: 32, y: 1.2, z: -14, sx: 3.5, sy: 2.4, sz: 8, kind: "crate", mat: "crate" },
      // Site furniture
      { x: -6, y: 0.75, z: -10, sx: 3, sy: 1.5, sz: 1.6, kind: "crate", mat: "crate" },
      { x: 6, y: 0.75, z: -10, sx: 3, sy: 1.5, sz: 1.6, kind: "crate", mat: "crate" },
      { x: 0, y: 0.75, z: -13, sx: 3.8, sy: 1.5, sz: 1.4, kind: "crate", mat: "crate" },
      { x: -12, y: 0.75, z: -6, sx: 1.8, sy: 1.5, sz: 2.8, kind: "crate", mat: "crate" },
      { x: 12, y: 0.75, z: -6, sx: 1.8, sy: 1.5, sz: 2.8, kind: "crate", mat: "crate" },
    ],
    softWalls: [
      { x: 0, y: 2.2, z: -16, sx: 9, sy: 4.3, sz: 0.4, hp: 240, id: "iy-main" },
      { x: -18, y: 2.2, z: -12, sx: 0.4, sy: 4.3, sz: 6.5, hp: 180, id: "iy-l" },
      { x: 18, y: 2.2, z: -12, sx: 0.4, sy: 4.3, sz: 6.5, hp: 180, id: "iy-r" },
    ],
    props: [
      { type: "crayon", x: -28, z: 24, color: 0xff5a3c },
      { type: "crayon", x: 28, z: 24, color: 0x4f63ff },
      { type: "crayon", x: 0, z: -28, color: 0xffd24a },
      { type: "crayon", x: -36, z: -4, color: 0x3dffb0 },
      { type: "crayon", x: 36, z: -4, color: 0xff8ad4 },
      { type: "crayon", x: -20, z: 4, color: 0xff9a4a },
      { type: "crayon", x: 20, z: 4, color: 0x7a9aff },
    ],
  },

  // ============================================================
  // 3. CRAYON CITADEL — Bank-inspired central hall + corridors
  // ============================================================
  {
    id: "crayon-citadel",
    name: "Crayon Citadel",
    blurb: "Grand central hall, tight side corridors, strong anchors, sneaky rotates.",
    bounds: { minx: -36, maxx: 36, minz: -32, maxz: 32 },
    site: { x: 0, z: -6, half: 3.4 },
    attackSpawns: [
      { x: 0, z: 28 }, { x: -9, z: 27 }, { x: 9, z: 27 },
      { x: -18, z: 26 }, { x: 18, z: 26 },
    ],
    defenseSpawns: [
      { x: 0, z: -28 }, { x: -8, z: -27 }, { x: 8, z: -27 },
      { x: -16, z: -26 }, { x: 16, z: -26 },
    ],
    boxes: [
      { x: 0, y: 2.3, z: -32.4, sx: 74, sy: 4.6, sz: 0.7, mat: "outer" },
      { x: 0, y: 2.3, z: 32.4, sx: 74, sy: 4.6, sz: 0.7, mat: "outer" },
      { x: -36.4, y: 2.3, z: 0, sx: 0.7, sy: 4.6, sz: 65, mat: "outer" },
      { x: 36.4, y: 2.3, z: 0, sx: 0.7, sy: 4.6, sz: 65, mat: "outer" },
      // Grand hall pillars
      { x: -7, y: 2.3, z: -12, sx: 0.7, sy: 4.6, sz: 10, mat: "inner" },
      { x: 7, y: 2.3, z: -12, sx: 0.7, sy: 4.6, sz: 10, mat: "inner" },
      { x: -7, y: 2.3, z: 4, sx: 0.7, sy: 4.6, sz: 10, mat: "inner" },
      { x: 7, y: 2.3, z: 4, sx: 0.7, sy: 4.6, sz: 10, mat: "inner" },
      // Cross walls
      { x: -14, y: 2.3, z: -2, sx: 12, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: 14, y: 2.3, z: -2, sx: 12, sy: 4.6, sz: 0.5, mat: "inner" },
      // Side corridors
      { x: -24, y: 2.3, z: -10, sx: 0.5, sy: 4.6, sz: 20, mat: "inner" },
      { x: 24, y: 2.3, z: -10, sx: 0.5, sy: 4.6, sz: 20, mat: "inner" },
      { x: -24, y: 2.3, z: 10, sx: 10, sy: 4.6, sz: 0.5, mat: "inner" },
      { x: 24, y: 2.3, z: 10, sx: 10, sy: 4.6, sz: 0.5, mat: "inner" },
      // Cover
      { x: 0, y: 0.75, z: -6, sx: 3.2, sy: 1.5, sz: 1.7, kind: "crate", mat: "crate" },
      { x: -5, y: 0.75, z: -10, sx: 2.2, sy: 1.5, sz: 2.2, kind: "crate", mat: "crate" },
      { x: 5, y: 0.75, z: -10, sx: 2.2, sy: 1.5, sz: 2.2, kind: "crate", mat: "crate" },
      { x: -12, y: 0.75, z: 8, sx: 2.6, sy: 1.5, sz: 1.6, kind: "crate", mat: "crate" },
      { x: 12, y: 0.75, z: 8, sx: 2.6, sy: 1.5, sz: 1.6, kind: "crate", mat: "crate" },
      { x: 0, y: 0.75, z: 16, sx: 4.5, sy: 1.5, sz: 1.6, kind: "crate", mat: "crate" },
      { x: -18, y: 0.75, z: -18, sx: 2.2, sy: 1.5, sz: 2.2, kind: "crate", mat: "crate" },
      { x: 18, y: 0.75, z: -18, sx: 2.2, sy: 1.5, sz: 2.2, kind: "crate", mat: "crate" },
      { x: -18, y: 0.75, z: 4, sx: 2, sy: 1.5, sz: 2, kind: "crate", mat: "crate" },
      { x: 18, y: 0.75, z: 4, sx: 2, sy: 1.5, sz: 2, kind: "crate", mat: "crate" },
    ],
    softWalls: [
      { x: 0, y: 2.2, z: -2, sx: 7.5, sy: 4.3, sz: 0.4, hp: 200, id: "cc-mid" },
      { x: -7, y: 2.2, z: -8, sx: 0.4, sy: 4.3, sz: 5, hp: 160, id: "cc-hall-l" },
      { x: 7, y: 2.2, z: -8, sx: 0.4, sy: 4.3, sz: 5, hp: 160, id: "cc-hall-r" },
      { x: -24, y: 2.2, z: 0, sx: 0.4, sy: 4.3, sz: 5.5, hp: 140, id: "cc-side-l" },
      { x: 24, y: 2.2, z: 0, sx: 0.4, sy: 4.3, sz: 5.5, hp: 140, id: "cc-side-r" },
    ],
    props: [
      { type: "crayon", x: -14, z: 22, color: 0xff5a3c },
      { type: "crayon", x: 14, z: 22, color: 0x4f63ff },
      { type: "crayon", x: 0, z: -24, color: 0xffd24a },
      { type: "crayon", x: -30, z: 6, color: 0x3dffb0 },
      { type: "crayon", x: 30, z: 6, color: 0xff8ad4 },
      { type: "crayon", x: -8, z: 0, color: 0xff9a4a },
      { type: "crayon", x: 8, z: 0, color: 0x7a9aff },
    ],
  },
];

export function getMap(id?: string): MapDef {
  return MAPS.find((m) => m.id === id) || MAPS[0];
}

export function listMaps() {
  return MAPS.map((m) => ({ id: m.id, name: m.name, blurb: m.blurb }));
}

// ---- builder helpers (shared textures) ----

function paperTex(repeatX: number, repeatY: number) {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const g = c.getContext("2d")!;
  g.fillStyle = "#e8d4a4";
  g.fillRect(0, 0, 256, 256);
  g.strokeStyle = "rgba(70,50,30,0.13)";
  g.lineWidth = 1;
  for (let i = 0; i <= 256; i += 16) {
    g.beginPath();
    g.moveTo(i, 0);
    g.lineTo(i, 256);
    g.stroke();
    g.beginPath();
    g.moveTo(0, i);
    g.lineTo(256, i);
    g.stroke();
  }
  g.fillStyle = "rgba(255,255,255,0.18)";
  g.fillRect(0, 0, 256, 18);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.repeat.set(repeatX, repeatY);
  t.anisotropy = 4;
  return t;
}

function crayonStrokeTex(hex: string) {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 128;
  const g = c.getContext("2d")!;
  g.fillStyle = hex;
  g.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 40; i++) {
    g.strokeStyle = `rgba(0,0,0,${0.04 + Math.random() * 0.07})`;
    g.lineWidth = 1 + Math.random() * 2;
    g.beginPath();
    g.moveTo(Math.random() * 128, Math.random() * 128);
    g.lineTo(Math.random() * 128, Math.random() * 128);
    g.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.repeat.set(2, 2);
  return t;
}

function mat(color: number, rough = 0.86, map?: THREE.Texture) {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: rough,
    metalness: 0.02,
    ...(map ? { map } : {}),
  });
}

export function aabbFrom(
  x: number,
  y: number,
  z: number,
  sx: number,
  sy: number,
  sz: number,
  extra?: Partial<AABB>,
): AABB {
  return {
    minx: x - sx / 2,
    maxx: x + sx / 2,
    miny: y - sy / 2,
    maxy: y + sy / 2,
    minz: z - sz / 2,
    maxz: z + sz / 2,
    kind: "wall",
    ...extra,
  };
}

export interface SoftWall {
  mesh: THREE.Mesh;
  box: AABB;
  hp: number;
  maxHp: number;
  reinforced: boolean;
}

export interface WorldBuilt {
  colliders: AABB[];
  meshes: THREE.Object3D[];
  softWalls: SoftWall[];
  siteMesh: THREE.Mesh;
  map: MapDef;
}

export function buildWorldFromMap(scene: THREE.Scene, mapId?: string): WorldBuilt {
  const map = getMap(mapId);
  const colliders: AABB[] = [];
  const meshes: THREE.Object3D[] = [];
  const softWalls: SoftWall[] = [];

  const wallMat = mat(0xcbb48a, 0.88, crayonStrokeTex("#d7b077"));
  const innerMat = mat(0xb8a0d0, 0.85, crayonStrokeTex("#bda4d6"));
  // Shipping-crate look
  const crateMat = new THREE.MeshStandardMaterial({
    color: 0xe8d5a8,
    roughness: 0.62,
    metalness: 0.08,
    map: crayonStrokeTex("#e8d5a8"),
  });
  const softBase = new THREE.MeshStandardMaterial({
    color: 0x7ec0ef,
    transparent: true,
    opacity: 0.88,
    roughness: 0.35,
    metalness: 0.05,
    emissive: 0x1a4060,
    emissiveIntensity: 0.12,
  });

  const bw = map.bounds.maxx - map.bounds.minx;
  const bd = map.bounds.maxz - map.bounds.minz;
  const floor = new THREE.Mesh(
    new THREE.BoxGeometry(bw + 2, 0.5, bd + 2),
    mat(0xf0d29d, 0.95, paperTex(18, 14)),
  );
  floor.position.set((map.bounds.minx + map.bounds.maxx) / 2, -0.25, (map.bounds.minz + map.bounds.maxz) / 2);
  floor.receiveShadow = true;
  scene.add(floor);
  meshes.push(floor);

  const matFor = (m?: string) => {
    if (m === "outer") return wallMat;
    if (m === "inner") return innerMat;
    if (m === "crate") return crateMat;
    return wallMat;
  };

  for (const b of map.boxes) {
    const material = matFor(b.mat);
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(b.sx, b.sy, b.sz), material);
    mesh.position.set(b.x, b.y, b.z);
    mesh.castShadow = false;
    scene.add(mesh);
    meshes.push(mesh);
    colliders.push(
      aabbFrom(b.x, b.y, b.z, b.sx, b.sy, b.sz, {
        kind: b.kind || "wall",
      }),
    );
  }

  for (const s of map.softWalls) {
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(s.sx, s.sy, s.sz),
      softBase.clone(),
    );
    mesh.position.set(s.x, s.y, s.z);
    scene.add(mesh);
    meshes.push(mesh);
    const box = aabbFrom(s.x, s.y, s.z, s.sx, s.sy, s.sz, {
      kind: "breach",
      id: s.id,
      hp: s.hp,
    });
    colliders.push(box);
    softWalls.push({ mesh, box, hp: s.hp, maxHp: s.hp, reinforced: false });
  }

  // Decorative crayons (taller, labeled)
  const crayonGeo = new THREE.CylinderGeometry(0.3, 0.3, 2.4, 12);
  const tipGeo = new THREE.ConeGeometry(0.3, 0.75, 12);
  const labelGeo = new THREE.CylinderGeometry(0.32, 0.32, 0.9, 12);
  for (const p of map.props || []) {
    if (p.type !== "crayon") continue;
    const g = new THREE.Group();
    const body = new THREE.Mesh(crayonGeo, mat(p.color, 0.38, undefined));
    const label = new THREE.Mesh(labelGeo, mat(0xfff8ec, 0.7));
    label.position.y = 0.1;
    const tip = new THREE.Mesh(tipGeo, mat(0xfff4d8, 0.35));
    tip.position.y = 1.55;
    g.add(body, label, tip);
    g.position.set(p.x, 1.2, p.z);
    scene.add(g);
    meshes.push(g);
    colliders.push(aabbFrom(p.x, 1.2, p.z, 0.75, 2.5, 0.75, { kind: "crate" }));
  }

  // Site pad — brighter objective
  const siteMat = new THREE.MeshStandardMaterial({
    color: 0xffd24a,
    emissive: 0xaa7a10,
    emissiveIntensity: 0.55,
    roughness: 0.4,
    metalness: 0.15,
  });
  const siteMesh = new THREE.Mesh(
    new THREE.BoxGeometry(map.site.half * 2, 0.1, map.site.half * 2),
    siteMat,
  );
  siteMesh.position.set(map.site.x, 0.05, map.site.z);
  scene.add(siteMesh);
  meshes.push(siteMesh);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(map.site.half - 0.2, map.site.half + 0.05, 24),
    new THREE.MeshBasicMaterial({
      color: 0xfff1a8,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.8,
    }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.set(map.site.x, 0.09, map.site.z);
  scene.add(ring);
  meshes.push(ring);

  return { colliders, meshes, softWalls, siteMesh, map };
}

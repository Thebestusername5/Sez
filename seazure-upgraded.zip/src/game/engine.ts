import * as THREE from "three";
import { pickBotClass, thinkBot, type AiEnt } from "./ai";
import { sfxPlay, unlockAudio } from "./audio";
import { getClass } from "./classes";
import {
  buildGrid,
  findPath,
  markRegion,
  pathSteer,
  type Grid,
} from "./pathfinding";
import type { AABB, ClassId, FighterState, HudSnap, MatchSettings, Phase, Team } from "./types";
import {
  buildWorld,
  CAPSULE,
  MAP,
  onSite,
  rayAabb,
  resolveCapsule,
  type WorldBuilt,
} from "./world";

export interface EngineOpts {
  canvas: HTMLCanvasElement;
  team: Team;
  classId: ClassId;
  name: string;
  selfId: string;
  isHost: boolean;
  fillBots: boolean;
  practice: boolean;
  settings: MatchSettings;
  onHud: (h: HudSnap) => void;
  sendState?: (data: unknown) => void;
  sendEvent?: (data: unknown) => void;
}

interface Ent {
  id: string;
  name: string;
  bot: boolean;
  team: Team;
  classId: ClassId;
  pos: { x: number; y: number; z: number };
  yaw: number;
  pitch: number;
  hp: number;
  alive: boolean;
  vy: number;
  grounded: boolean;
  ammo: number;
  reloadT: number;
  fireCd: number;
  gadgetCd: number;
  frozenT: number;
  dashT: number;
  respawnT: number;
  spawnI: number;
  mesh: THREE.Group | null;
  thinkT: number;
  wishX: number;
  wishZ: number;
  revealT: number;
  /** AI brain state (bots only) */
  aiState?: string;
  aiTargetId?: string | null;
  aiHoldT?: number;
  aiFlankSide?: number;
  aiPath?: { x: number; z: number }[];
  aiPathVersion?: number;
  aiGoalX?: number;
  aiGoalZ?: number;
  aiRepathT?: number;
}

interface Zone {
  kind: "puddle" | "pad" | "hazard" | "paint";
  x: number;
  z: number;
  r: number;
  life: number;
  dps: number;
  slow: number;
  mesh: THREE.Mesh;
}

interface Particle {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  alive: boolean;
}

const STEP = 1 / 60;
const GRAVITY = 24;
const JUMP = 7.4;
const EYE = 1.55;
const BOT_NAMES = ["Sketchy", "Doodle", "Splatkin", "Inkdrop", "Scribble", "Waxcap", "Nib", "Pastel"];

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function pickSpawn(team: Team, i: number) {
  const list = team === "ATTACK" ? MAP.attackSpawns : MAP.defenseSpawns;
  return list[i % list.length];
}

export class SeazureEngine {
  private opts: EngineOpts;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private world: WorldBuilt;
  private viewmodel: THREE.Group;
  private keys = new Set<string>();
  private qaKeys: string[] | null = null;
  private moveX = 0;
  private moveY = 0;
  private lookX = 0;
  private lookY = 0;
  private firing = false;
  private jumping = false;
  private wantReload = false;
  private wantGadget = false;
  private locked = false;
  private pointerDown = false;
  private lastLX = 0;
  private lastLY = 0;
  private yaw = 0;
  private pitch = 0;
  private running = false;
  private raf = 0;
  private acc = 0;
  private lastT = 0;
  private lastSend = 0;
  private lastBotSend = 0;
  private lastHud = 0;
  private footT = 0;
  private bob = 0;
  private recoil = 0;
  private trauma = 0;
  private swayX = 0;
  private swayY = 0;
  private landSquash = 0;
  private wasGrounded = true;
  private fovKick = 0;
  private reloadAnim = 0;
  private hitFlash = 0;
  private hurtFlash = 0;
  private notice = "";
  private noticeT = 0;
  private feed: string[] = [];
  private phase: Phase = "prep";
  private round = 1;
  private timer = 12;
  private scoreA = 0;
  private scoreD = 0;
  private obj = 0;
  private matchOver = false;
  private matchWinner: Team | null = null;
  private paused = false;
  private reduced = false;
  private ents = new Map<string, Ent>();
  private me: Ent;
  private colliders: AABB[];
  private navGrid: Grid | null = null;
  private reinforceProgress = 0;
  private reinforceTarget: string | null = null;
  /** Bomb mode: 0 = not planted, progress 0-1 while planting, 1 = planted */
  private bombPlanted = false;
  private bombPlantProgress = 0;
  private bombDefuseProgress = 0;
  private bombTimer = 0; // seconds until detonation when planted
  private bombMesh: THREE.Object3D | null = null;
  private siteLight: THREE.PointLight | null = null;
  private gadgets: Zone[] = [];
  private gadgetWalls: { mesh: THREE.Object3D; box: AABB; life: number }[] = [];
  private particles: Particle[] = [];
  private particleGeo = new THREE.BoxGeometry(0.08, 0.08, 0.08);
  private tracers: { mesh: THREE.Mesh; life: number }[] = [];
  private decals: THREE.Mesh[] = [];
  private decalI = 0;
  private remoteLerp = new Map<string, { x: number; y: number; z: number; yaw: number }>();
  private cleanup: Array<() => void> = [];
  private hud: HudSnap;
  private muzzle: THREE.PointLight;

  constructor(opts: EngineOpts) {
    this.opts = opts;
    this.reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    this.renderer = new THREE.WebGLRenderer({ canvas: opts.canvas, antialias: true, alpha: false });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.setSize(opts.canvas.clientWidth, opts.canvas.clientHeight, false);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x5aa8d8);
    this.scene.fog = new THREE.Fog(0x5aa8d8, 55, 140);

    this.camera = new THREE.PerspectiveCamera(72, 1, 0.05, 320);
    this.resize();

    // Proper multi-light setup for readable interiors + outdoor feel
    this.scene.add(new THREE.AmbientLight(0xc8d8e8, 0.35));
    this.scene.add(new THREE.HemisphereLight(0xfff4e8, 0x3a4a5a, 0.75));
    const sun = new THREE.DirectionalLight(0xffe8c8, 1.55);
    sun.position.set(28, 48, 18);
    sun.castShadow = false;
    this.scene.add(sun);
    const fill = new THREE.DirectionalLight(0x88b0ff, 0.55);
    fill.position.set(-22, 18, -14);
    this.scene.add(fill);
    const rim = new THREE.DirectionalLight(0xffb090, 0.35);
    rim.position.set(0, 12, -24);
    this.scene.add(rim);
    // Warm bounce from ground
    const bounce = new THREE.DirectionalLight(0xffd8a0, 0.2);
    bounce.position.set(0, -5, 0);
    this.scene.add(bounce);

    this.world = buildWorld(this.scene, this.opts.settings.mapId);
    this.colliders = this.world.colliders.slice();
    this.navGrid = buildGrid(MAP, this.colliders);
    // Site accent light
    this.siteLight = new THREE.PointLight(0xffd24a, 1.2, 18, 2);
    this.siteLight.position.set(MAP.site.x, 3.5, MAP.site.z);
    this.scene.add(this.siteLight);
    this.ensureBombMesh();
    this.viewmodel = this.makeViewmodel();
    this.viewmodel.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (!mesh.isMesh) return;
      mesh.renderOrder = 1000;
      const material = mesh.material as THREE.MeshStandardMaterial;
      material.depthTest = false;
    });
    this.camera.add(this.viewmodel);
    this.scene.add(this.camera);
    this.muzzle = new THREE.PointLight(0xffc14a, 0, 2.4);
    this.muzzle.position.set(0.2, -0.1, -0.45);
    this.camera.add(this.muzzle);

    for (let i = 0; i < 72; i++) {
      const mesh = new THREE.Mesh(
        this.particleGeo,
        new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5 }),
      );
      mesh.visible = false;
      this.scene.add(mesh);
      this.particles.push({ mesh, vx: 0, vy: 0, vz: 0, life: 0, alive: false });
    }
    const decalGeo = new THREE.CircleGeometry(0.18, 10);
    for (let i = 0; i < 40; i++) {
      const m = new THREE.Mesh(
        decalGeo,
        new THREE.MeshBasicMaterial({ color: 0xff4f8b, transparent: true, opacity: 0.85, depthWrite: false }),
      );
      m.visible = false;
      this.scene.add(m);
      this.decals.push(m);
    }

    const spawn = pickSpawn(opts.team, 0);
    this.yaw = opts.team === "ATTACK" ? 0 : Math.PI;
    this.me = this.makeEnt(opts.selfId, opts.name, false, opts.team, opts.classId, spawn.x, spawn.z, 0);
    this.ents.set(this.me.id, this.me);
    this.placeCamera();

    if (opts.practice || (opts.isHost && opts.fillBots)) this.seedBots();

    this.hud = this.buildHud();
    this.bind();
    this.installProbe();
    this.say(
      opts.team === "ATTACK"
        ? "Prep: scout soft walls. Then plant the bomb on the gold site."
        : "Prep: reinforce soft walls. Stop the plant — defuse if needed.",
    );
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.lastT = performance.now();
    const loop = (now: number) => {
      if (!this.running) return;
      const raw = Math.min(0.08, (now - this.lastT) / 1000);
      this.lastT = now;
      if (!this.paused && !this.matchOver) {
        this.acc += raw;
        while (this.acc >= STEP) {
          this.sim(STEP);
          this.acc -= STEP;
        }
      }
      this.draw(raw);
      if (now - this.lastHud > 50) {
        this.lastHud = now;
        this.hud = this.buildHud();
        this.opts.onHud(this.hud);
      }
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  stop() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    for (const fn of this.cleanup) fn();
    this.cleanup = [];
    this.renderer.dispose();
    if (window.__controlsTest) delete window.__controlsTest;
  }

  setPaused(v: boolean) {
    this.paused = v;
    if (v) this.unlockPointer();
  }

  handleNet(from: string, data: unknown) {
    if (!data || typeof data !== "object") return;
    const m = data as Record<string, unknown>;
    const k = m.k;
    if (k === "st" && from !== this.me.id) this.applyRemote(from, m);
    if (k === "fire" && from !== this.me.id) {
      this.tracer(
        Number(m.ox) || 0,
        Number(m.oy) || 1.4,
        Number(m.oz) || 0,
        Number(m.dx) || 0,
        Number(m.dy) || 0,
        Number(m.dz) || -1,
        Number(m.col) || 0xff5b72,
      );
    }
    if (k === "hit" && m.id === this.me.id) this.hurt(Number(m.dmg) || 0, String(m.by || from), false);
    if (k === "splat") this.splat(String(m.id), String(m.by || "someone"), false);
    if (k === "gadget") this.spawnGadgetFromNet(m);
    if (k === "bomb") {
      this.bombPlanted = Boolean(m.planted);
      this.bombTimer = Number(m.t) || this.bombTimer;
      if (this.bombPlanted) this.placeBombVisual();
      else this.clearBombVisual();
    }
    if (k === "reinforce") {
      const id = String(m.id || "");
      const sw = this.world.softWalls.find((s) => s.box.id === id);
      if (sw && !sw.reinforced) {
        sw.reinforced = true;
        sw.hp = Math.floor(sw.maxHp * 2.1);
        sw.maxHp = sw.hp;
        const mat = sw.mesh.material as THREE.MeshStandardMaterial;
        mat.color.setHex(0x3a5cff);
        mat.emissive = new THREE.Color(0x1a2a88);
        mat.emissiveIntensity = 0.35;
        mat.opacity = 1;
        mat.transparent = false;
        mat.metalness = 0.55;
        mat.roughness = 0.35;
        sw.mesh.scale.set(1.08, 1.02, 1.08);
      }
    }
    if (k === "phase" && !this.opts.isHost) {
      this.phase = (m.phase as Phase) || this.phase;
      this.round = Number(m.round) || this.round;
      this.timer = Number(m.t) || this.timer;
      this.scoreA = Number(m.scoreA) || this.scoreA;
      this.scoreD = Number(m.scoreD) || this.scoreD;
      this.obj = Number(m.obj) || this.obj;
      if (m.over) {
        this.matchOver = true;
        this.matchWinner = (m.win as Team) || null;
      }
    }
    if (k === "bots" && !this.opts.isHost && Array.isArray(m.list)) {
      for (const raw of m.list as FighterState[]) this.upsertBot(raw);
    }
  }

  dropPeer(id: string) {
    const e = this.ents.get(id);
    if (!e || e.bot) return;
    if (e.mesh) this.scene.remove(e.mesh);
    this.ents.delete(id);
  }

  private makeEnt(
    id: string,
    name: string,
    bot: boolean,
    team: Team,
    classId: ClassId,
    x: number,
    z: number,
    spawnI: number,
  ): Ent {
    const cls = getClass(team, classId);
    const e: Ent = {
      id,
      name,
      bot,
      team,
      classId,
      pos: { x, y: 0, z },
      yaw: team === "ATTACK" ? 0 : Math.PI,
      pitch: 0,
      hp: 100,
      alive: true,
      vy: 0,
      grounded: true,
      ammo: cls.mag,
      reloadT: 0,
      fireCd: 0,
      gadgetCd: 0,
      frozenT: 0,
      dashT: 0,
      respawnT: 0,
      spawnI,
      mesh: bot || id !== this.opts.selfId ? this.makeBody(team, cls.color) : null,
      thinkT: Math.random() * 0.4,
      wishX: 0,
      wishZ: 0,
      revealT: 0,
    };
    if (e.mesh) {
      e.mesh.position.set(x, 0.9, z);
      this.scene.add(e.mesh);
    }
    return e;
  }

  private makeBody(team: Team, color: number) {
    const g = new THREE.Group();
    const teamColor = team === "ATTACK" ? 0x3a4fd4 : 0xe04e28;
    const accent = team === "ATTACK" ? 0x9ab0ff : 0xffb090;
    const dark = 0x1c1c24;

    const mat = (c: number, rough = 0.5, metal = 0.08) =>
      new THREE.MeshStandardMaterial({ color: c, roughness: rough, metalness: metal });

    // --- Legs ---
    const legGeo = new THREE.CapsuleGeometry(0.11, 0.48, 6, 10);
    const legL = new THREE.Mesh(legGeo, mat(0x252530, 0.72));
    legL.position.set(-0.15, -0.58, 0.02);
    const legR = new THREE.Mesh(legGeo, mat(0x252530, 0.72));
    legR.position.set(0.15, -0.58, 0.02);

    // Kneepads
    const kneeGeo = new THREE.SphereGeometry(0.09, 8, 6);
    const kneeL = new THREE.Mesh(kneeGeo, mat(dark, 0.4, 0.25));
    kneeL.position.set(-0.15, -0.42, 0.08);
    kneeL.scale.set(1, 0.7, 0.9);
    const kneeR = new THREE.Mesh(kneeGeo, mat(dark, 0.4, 0.25));
    kneeR.position.set(0.15, -0.42, 0.08);
    kneeR.scale.set(1, 0.7, 0.9);

    // Boots
    const bootGeo = new THREE.BoxGeometry(0.2, 0.14, 0.32);
    const bootL = new THREE.Mesh(bootGeo, mat(0x14141a, 0.5, 0.2));
    bootL.position.set(-0.15, -0.92, 0.05);
    const bootR = new THREE.Mesh(bootGeo, mat(0x14141a, 0.5, 0.2));
    bootR.position.set(0.15, -0.92, 0.05);

    // --- Torso ---
    const body = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.36, 0.7, 8, 14),
      mat(teamColor, 0.4, 0.1),
    );
    body.position.y = 0.1;

    // Armor plates
    const chest = new THREE.Mesh(
      new THREE.BoxGeometry(0.48, 0.32, 0.2),
      mat(accent, 0.32, 0.28),
    );
    chest.position.set(0, 0.3, 0.24);

    const belt = new THREE.Mesh(
      new THREE.BoxGeometry(0.52, 0.1, 0.28),
      mat(dark, 0.45, 0.2),
    );
    belt.position.set(0, -0.12, 0.05);

    // Backpack / kit
    const pack = new THREE.Mesh(
      new THREE.BoxGeometry(0.34, 0.38, 0.16),
      mat(0x2a2a36, 0.55, 0.12),
    );
    pack.position.set(0, 0.22, -0.28);

    // --- Head ---
    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.25, 16, 14),
      mat(0xffe0bd, 0.48, 0.02),
    );
    head.position.y = 0.84;

    // Helmet rim
    const helm = new THREE.Mesh(
      new THREE.TorusGeometry(0.22, 0.04, 8, 16),
      mat(dark, 0.35, 0.4),
    );
    helm.rotation.x = Math.PI / 2;
    helm.position.set(0, 0.92, 0.02);

    // Visor
    const visor = new THREE.Mesh(
      new THREE.BoxGeometry(0.34, 0.09, 0.14),
      mat(0x0a0a12, 0.2, 0.7),
    );
    visor.position.set(0, 0.88, 0.2);

    // Visor glow strip
    const glow = new THREE.Mesh(
      new THREE.BoxGeometry(0.28, 0.025, 0.02),
      new THREE.MeshStandardMaterial({
        color: team === "ATTACK" ? 0x4f8cff : 0xff6a3c,
        emissive: team === "ATTACK" ? 0x2a5cff : 0xff3a10,
        emissiveIntensity: 0.8,
        roughness: 0.3,
      }),
    );
    glow.position.set(0, 0.88, 0.28);

    // Crayon operator mark (class color) — angled on helmet
    const crayon = new THREE.Mesh(
      new THREE.CylinderGeometry(0.07, 0.07, 0.55, 12),
      mat(color, 0.28, 0.12),
    );
    crayon.rotation.z = 0.55;
    crayon.position.set(0.18, 1.08, 0.02);
    const crayonTip = new THREE.Mesh(
      new THREE.ConeGeometry(0.07, 0.2, 12),
      mat(0xfff6e0, 0.32, 0.05),
    );
    crayonTip.rotation.z = 0.55;
    crayonTip.position.set(0.38, 1.26, 0.02);

    // --- Arms ---
    const armGeo = new THREE.CapsuleGeometry(0.085, 0.4, 6, 10);
    const armL = new THREE.Mesh(armGeo, mat(teamColor, 0.45));
    armL.position.set(-0.44, 0.3, 0.06);
    armL.rotation.z = 0.42;
    const armR = new THREE.Mesh(armGeo, mat(teamColor, 0.45));
    armR.position.set(0.44, 0.3, 0.06);
    armR.rotation.z = -0.42;

    // Shoulder pads
    const padGeo = new THREE.SphereGeometry(0.13, 10, 8);
    const padL = new THREE.Mesh(padGeo, mat(accent, 0.35, 0.22));
    padL.position.set(-0.4, 0.54, 0.04);
    padL.scale.set(1.1, 0.75, 1);
    const padR = new THREE.Mesh(padGeo, mat(accent, 0.35, 0.22));
    padR.position.set(0.4, 0.54, 0.04);
    padR.scale.set(1.1, 0.75, 1);

    // Gloves
    const handGeo = new THREE.SphereGeometry(0.07, 8, 6);
    const handL = new THREE.Mesh(handGeo, mat(dark, 0.5, 0.15));
    handL.position.set(-0.55, 0.05, 0.1);
    const handR = new THREE.Mesh(handGeo, mat(dark, 0.5, 0.15));
    handR.position.set(0.55, 0.05, 0.1);

    g.add(
      legL, legR, kneeL, kneeR, bootL, bootR,
      body, chest, belt, pack,
      head, helm, visor, glow,
      crayon, crayonTip,
      armL, armR, padL, padR, handL, handR,
    );
    g.position.y = 0.18;
    g.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.castShadow = false;
        m.receiveShadow = false;
      }
    });
    return g;
  }

  private makeViewmodel() {
    const g = new THREE.Group();
    const mat = (c: number, rough = 0.4, metal = 0.1) =>
      new THREE.MeshStandardMaterial({ color: c, roughness: rough, metalness: metal });

    // Main crayon body
    const body = new THREE.Mesh(
      new THREE.CylinderGeometry(0.045, 0.048, 0.58, 14),
      mat(0xffd24a, 0.32, 0.08),
    );
    body.rotation.x = Math.PI / 2;

    // Paper label wrap
    const label = new THREE.Mesh(
      new THREE.CylinderGeometry(0.05, 0.05, 0.28, 14),
      mat(0xfff8ec, 0.6, 0.02),
    );
    label.rotation.x = Math.PI / 2;
    label.position.z = 0.06;

    // Colored tip
    const tip = new THREE.Mesh(
      new THREE.ConeGeometry(0.045, 0.18, 14),
      mat(0xff4a2a, 0.28, 0.05),
    );
    tip.rotation.x = -Math.PI / 2;
    tip.position.z = -0.36;

    // Tip highlight
    const tipGlow = new THREE.Mesh(
      new THREE.ConeGeometry(0.03, 0.1, 10),
      new THREE.MeshStandardMaterial({
        color: 0xff8a60,
        emissive: 0xff4020,
        emissiveIntensity: 0.35,
        roughness: 0.3,
      }),
    );
    tipGlow.rotation.x = -Math.PI / 2;
    tipGlow.position.z = -0.42;

    // Grip / stock
    const grip = new THREE.Mesh(
      new THREE.BoxGeometry(0.06, 0.1, 0.16),
      mat(0xb89050, 0.65, 0.05),
    );
    grip.position.set(0, -0.06, 0.14);

    // Side rails (tactical crayon vibes)
    const railL = new THREE.Mesh(
      new THREE.BoxGeometry(0.02, 0.03, 0.35),
      mat(0x3a3a44, 0.4, 0.3),
    );
    railL.position.set(-0.05, 0.02, -0.02);
    const railR = new THREE.Mesh(
      new THREE.BoxGeometry(0.02, 0.03, 0.35),
      mat(0x3a3a44, 0.4, 0.3),
    );
    railR.position.set(0.05, 0.02, -0.02);

    // Front sight
    const sight = new THREE.Mesh(
      new THREE.BoxGeometry(0.02, 0.06, 0.02),
      mat(0x22222a, 0.35, 0.4),
    );
    sight.position.set(0, 0.05, -0.28);

    g.add(body, label, tip, tipGlow, grip, railL, railR, sight);
    g.position.set(0.34, -0.28, -0.58);
    return g;
  }

  private seedBots() {
    const practice = this.opts.practice;
    const myTeam = this.me.team;
    const enemyTeam: Team = myTeam === "ATTACK" ? "DEFENSE" : "ATTACK";
    const enemies = practice ? 4 : 3;
    const allies = practice ? 2 : 2;
    let n = 0;
    for (let i = 0; i < enemies; i++) {
      const sp = pickSpawn(enemyTeam, i);
      const id = `bot-e-${i}`;
      const e = this.makeEnt(
        id,
        BOT_NAMES[n++ % BOT_NAMES.length],
        true,
        enemyTeam,
        pickBotClass(enemyTeam, i),
        sp.x,
        sp.z,
        i,
      );
      this.ents.set(id, e);
    }
    for (let i = 0; i < allies; i++) {
      const sp = pickSpawn(myTeam, i + 1);
      const id = `bot-a-${i}`;
      const e = this.makeEnt(
        id,
        BOT_NAMES[n++ % BOT_NAMES.length],
        true,
        myTeam,
        pickBotClass(myTeam, i + 1),
        sp.x,
        sp.z,
        i + 1,
      );
      this.ents.set(id, e);
    }
  }

  private bind() {
    const c = this.opts.canvas;
    const onKey = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (e.code === "Escape") {
        this.setPaused(!this.paused);
        return;
      }
      this.keys.add(e.code);
      if (["Space", "KeyW", "KeyA", "KeyS", "KeyD", "KeyR", "KeyQ", "KeyE", "ShiftLeft", "ShiftRight", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) {
        e.preventDefault();
      }
      if (e.code === "KeyR") this.wantReload = true;
      if (e.code === "KeyQ" || e.code === "KeyF") this.wantGadget = true;
      if (e.code === "Space") this.jumping = true;
    };
    const onUp = (e: KeyboardEvent) => this.keys.delete(e.code);
    const clear = () => this.keys.clear();
    const onDown = (e: PointerEvent) => {
      if (e.button === 0 && this.locked) this.firing = true;
      if (e.button === 2) {
        e.preventDefault();
        this.wantGadget = true;
      }
      this.pointerDown = true;
      this.lastLX = e.clientX;
      this.lastLY = e.clientY;
      if (!this.locked && e.button === 0 && !this.paused) this.requestLock();
    };
    const onUpP = (e: PointerEvent) => {
      if (e.button === 0) this.firing = false;
      this.pointerDown = false;
    };
    const onMove = (e: MouseEvent) => {
      if (this.paused) return;
      if (document.pointerLockElement === c || document.pointerLockElement === document.body) {
        this.yaw -= e.movementX * 0.0022;
        this.pitch -= e.movementY * 0.0022;
        this.pitch = clamp(this.pitch, -1.45, 1.45);
        this.lookX += e.movementX * 0.08;
        this.lookY += e.movementY * 0.08;
        this.lookX = clamp(this.lookX, -12, 12);
        this.lookY = clamp(this.lookY, -12, 12);
      } else if (this.pointerDown) {
        const dx = e.clientX - this.lastLX;
        const dy = e.clientY - this.lastLY;
        this.yaw -= dx * 0.006;
        this.pitch -= dy * 0.006;
        this.pitch = clamp(this.pitch, -1.45, 1.45);
        this.lookX += dx * 0.12;
        this.lookY += dy * 0.12;
        this.lastLX = e.clientX;
        this.lastLY = e.clientY;
      }
    };
    const onLock = () => {
      this.locked = document.pointerLockElement === c || document.pointerLockElement === document.body;
    };
    const onCtx = (e: Event) => e.preventDefault();
    const onVis = () => {
      if (document.hidden) this.keys.clear();
      unlockAudio();
    };
    const onResize = () => this.resize();
    window.addEventListener("keydown", onKey);
    window.addEventListener("keyup", onUp);
    window.addEventListener("blur", clear);
    window.addEventListener("mousemove", onMove);
    document.addEventListener("pointerlockchange", onLock);
    window.addEventListener("resize", onResize);
    document.addEventListener("visibilitychange", onVis);
    c.addEventListener("pointerdown", onDown);
    window.addEventListener("pointerup", onUpP);
    c.addEventListener("contextmenu", onCtx);
    this.cleanup.push(() => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("keyup", onUp);
      window.removeEventListener("blur", clear);
      window.removeEventListener("mousemove", onMove);
      document.removeEventListener("pointerlockchange", onLock);
      window.removeEventListener("resize", onResize);
      document.removeEventListener("visibilitychange", onVis);
      c.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointerup", onUpP);
      c.removeEventListener("contextmenu", onCtx);
    });
  }

  setTouchMove(x: number, y: number) {
    this.moveX = x;
    this.moveY = y;
  }
  setTouchLook(dx: number, dy: number) {
    this.yaw -= dx * 0.007;
    this.pitch -= dy * 0.007;
    this.pitch = clamp(this.pitch, -1.45, 1.45);
  }
  setFiring(v: boolean) {
    this.firing = v;
  }
  tapJump() {
    this.jumping = true;
  }
  tapReload() {
    this.wantReload = true;
  }
  tapGadget() {
    this.wantGadget = true;
  }

  requestLock() {
    const el = this.opts.canvas;
    const req = el.requestPointerLock as (opts?: { unadjustedMovement?: boolean }) => Promise<void> | void;
    try {
      const p = req.call(el, { unadjustedMovement: true });
      if (p && typeof (p as Promise<void>).catch === "function") {
        (p as Promise<void>).catch(() => {
          try {
            el.requestPointerLock();
          } catch {
            /* iframe may block */
          }
        });
      }
    } catch {
      try {
        el.requestPointerLock();
      } catch {
        /* ignore */
      }
    }
  }

  private unlockPointer() {
    try {
      document.exitPointerLock();
    } catch {
      /* ignore */
    }
    this.locked = false;
  }

  private resize() {
    const c = this.opts.canvas;
    const w = c.clientWidth || window.innerWidth;
    const h = c.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  private held(code: string) {
    if (this.qaKeys) return this.qaKeys.includes(code);
    return this.keys.has(code);
  }

  private sim(dt: number) {
    this.pollGamepad(dt);
    this.tickRound(dt);
    this.tickPlayer(dt);
    if (this.opts.practice || this.opts.isHost) this.tickBots(dt);
    this.tickZones(dt);
    this.tickGadgets(dt);
    if (this.opts.practice || this.opts.isHost) this.tickObjective(dt);
    this.syncMeshes();
    this.lastSend += dt;
    if (this.lastSend > 0.05) {
      this.lastSend = 0;
      this.opts.sendState?.({
        k: "st",
        x: this.me.pos.x,
        y: this.me.pos.y,
        z: this.me.pos.z,
        yaw: this.yaw,
        pitch: this.pitch,
        hp: this.me.hp,
        alive: this.me.alive,
        team: this.me.team,
        classId: this.me.classId,
        name: this.me.name,
      });
    }
    if ((this.opts.practice || this.opts.isHost) && (this.lastBotSend += dt) > 0.1) {
      this.lastBotSend = 0;
      const list: FighterState[] = [];
      for (const e of this.ents.values()) {
        if (!e.bot) continue;
        list.push({
          id: e.id,
          name: e.name,
          bot: true,
          team: e.team,
          classId: e.classId,
          x: e.pos.x,
          y: e.pos.y,
          z: e.pos.z,
          yaw: e.yaw,
          pitch: e.pitch,
          hp: e.hp,
          alive: e.alive,
          vx: 0,
          vz: 0,
        });
      }
      this.opts.sendEvent?.({ k: "bots", list });
    }
  }

  private pollGamepad(dt: number) {
    const pads = navigator.getGamepads?.() ?? [];
    for (const p of pads) {
      if (!p) continue;
      const lx = p.axes[0] ?? 0;
      const ly = p.axes[1] ?? 0;
      const m = Math.hypot(lx, ly);
      const dz = 0.18;
      if (m > dz) {
        const s = ((m - dz) / (1 - dz)) / m;
        this.moveX = lx * s;
        this.moveY = -ly * s;
      }
      const rx = p.axes[2] ?? 0;
      const ry = p.axes[3] ?? 0;
      const rm = Math.hypot(rx, ry);
      if (rm > 0.12) {
        this.yaw -= rx * 2.4 * dt;
        this.pitch -= ry * 2.0 * dt;
        this.pitch = clamp(this.pitch, -1.45, 1.45);
      }
      if (p.buttons[7]?.value > 0.4 || p.buttons[0]?.pressed) this.firing = p.buttons[7]?.value > 0.4;
      if (p.buttons[0]?.pressed) this.jumping = true;
      if (p.buttons[2]?.pressed) this.wantReload = true;
      if (p.buttons[4]?.pressed) this.wantGadget = true;
    }
  }

  private walls(): AABB[] {
    return this.colliders.concat(this.gadgetWalls.map((g) => g.box));
  }

  private tickPlayer(dt: number) {
    const me = this.me;
    if (!me.alive) {
      // Permadeath for the round (R6-style) — spectate until next round
      return;
    }
    me.frozenT = Math.max(0, me.frozenT - dt);
    me.fireCd = Math.max(0, me.fireCd - dt);
    me.gadgetCd = Math.max(0, me.gadgetCd - dt);
    if (me.reloadT > 0) {
      me.reloadT -= dt;
      if (me.reloadT <= 0) {
        me.ammo = getClass(me.team, me.classId).mag;
        sfxPlay.reload();
      }
    }

    let ax = this.moveX;
    let az = this.moveY;
    if (this.held("KeyW") || this.held("ArrowUp")) az += 1;
    if (this.held("KeyS") || this.held("ArrowDown")) az -= 1;
    if (this.held("KeyD") || this.held("ArrowRight")) ax += 1;
    if (this.held("KeyA") || this.held("ArrowLeft")) ax -= 1;
    const len = Math.hypot(ax, az);
    if (len > 1) {
      ax /= len;
      az /= len;
    }
    const sprint = this.held("ShiftLeft") || this.held("ShiftRight");
    const cls = getClass(me.team, me.classId);
    let speed = cls.speed * (sprint ? 1.48 : 1);
    const zone = this.zoneAt(me.pos.x, me.pos.z);
    if (zone) speed *= zone.slow;
    if (me.frozenT > 0) speed = 0;

    const fx = -Math.sin(this.yaw);
    const fz = -Math.cos(this.yaw);
    const rx = Math.cos(this.yaw);
    const rz = -Math.sin(this.yaw);
    let vx = (fx * az + rx * ax) * speed;
    let vz = (fz * az + rz * ax) * speed;
    if (me.dashT > 0) {
      me.dashT -= dt;
      vx += fx * 14;
      vz += fz * 14;
    }

    if ((this.jumping || this.held("Space")) && me.grounded && me.frozenT <= 0) {
      me.vy = JUMP;
      me.grounded = false;
      sfxPlay.jump();
    }
    this.jumping = false;
    me.vy -= GRAVITY * dt;
    const moved = resolveCapsule(me.pos, me.vy, vx * dt, vz * dt, me.vy * dt, this.walls());
    me.grounded = moved.grounded;
    me.vy = moved.vy;
    me.yaw = this.yaw;
    me.pitch = this.pitch;

    const moving = Math.hypot(vx, vz) > 0.4 && me.grounded;
    if (moving) {
      this.bob += dt * (sprint ? 14 : 10);
      this.footT += dt;
      if (this.footT > (sprint ? 0.26 : 0.38)) {
        this.footT = 0;
        if (sprint) sfxPlay.sprintFoot();
        else sfxPlay.foot();
      }
    }

    if (this.wantReload) this.startReload(me);
    this.wantReload = false;
    if (this.wantGadget) this.useGadget(me);
    this.wantGadget = false;
    if (this.firing) this.tryFire(me, true);

    // Action: Hold E to plant (Attack on site) or defuse (Defense on site)
    if (this.phase === "action" && this.held("KeyE")) {
      this.tryPlantOrDefuse(me, dt);
    } else if (this.phase === "action") {
      // decay progress when not holding
      if (!this.bombPlanted) this.bombPlantProgress = Math.max(0, this.bombPlantProgress - dt * 0.45);
      else this.bombDefuseProgress = Math.max(0, this.bombDefuseProgress - dt * 0.55);
      if (me.team === "ATTACK" && !this.bombPlanted && onSite(me.pos.x, me.pos.z)) {
        this.notice = "Hold E to plant the bomb";
        this.noticeT = 0.25;
      } else if (me.team === "DEFENSE" && this.bombPlanted && onSite(me.pos.x, me.pos.z)) {
        this.notice = "Hold E to defuse the bomb";
        this.noticeT = 0.25;
      }
    }

    // Prep: Defense holds E near a soft wall to reinforce it (2s channel)
    if (this.phase === "prep" && me.team === "DEFENSE") {
      const near = this.nearestSoftWall(me.pos.x, me.pos.z, 3.4);
      if (near && !near.reinforced && near.hp > 0 && this.held("KeyE")) {
        if (this.reinforceTarget !== near.box.id) {
          this.reinforceTarget = near.box.id ?? null;
          this.reinforceProgress = 0;
        }
        this.reinforceProgress += dt;
        const pct = Math.min(1, this.reinforceProgress / 2.0);
        this.notice = `Reinforcing… ${Math.floor(pct * 100)}%`;
        this.noticeT = 0.45;
        if (this.reinforceProgress >= 2.0) {
          this.tryReinforce(me);
          this.reinforceProgress = 0;
          this.reinforceTarget = null;
        }
      } else {
        this.reinforceProgress = 0;
        this.reinforceTarget = null;
        if (near && !near.reinforced && near.hp > 0) {
          this.notice = "Hold E (2s) to reinforce soft wall";
          this.noticeT = 0.35;
        }
      }
    } else {
      this.reinforceProgress = 0;
      this.reinforceTarget = null;
    }

    if (zone && zone.dps > 0) this.hurt(zone.dps * dt, "hazard", true);
  }

  private nearestSoftWall(x: number, z: number, maxDist: number) {
    let best: (typeof this.world.softWalls)[0] | null = null;
    let bestD = maxDist;
    for (const sw of this.world.softWalls) {
      if (sw.hp <= 0) continue;
      const cx = (sw.box.minx + sw.box.maxx) / 2;
      const cz = (sw.box.minz + sw.box.maxz) / 2;
      const d = Math.hypot(cx - x, cz - z);
      if (d < bestD) {
        bestD = d;
        best = sw;
      }
    }
    return best;
  }

  private tryReinforce(e: Ent) {
    const sw = this.nearestSoftWall(e.pos.x, e.pos.z, 3.4);
    if (!sw || sw.reinforced || sw.hp <= 0) return;
    sw.reinforced = true;
    sw.hp = Math.floor(sw.maxHp * 2.1);
    sw.maxHp = sw.hp;
    const mat = sw.mesh.material as THREE.MeshStandardMaterial;
    mat.color.setHex(0x3a5cff);
    mat.emissive = new THREE.Color(0x1a2a88);
    mat.emissiveIntensity = 0.35;
    mat.opacity = 1;
    mat.transparent = false;
    mat.metalness = 0.55;
    mat.roughness = 0.35;
    // Slightly thicker visual
    sw.mesh.scale.set(1.08, 1.02, 1.08);
    this.burst(
      (sw.box.minx + sw.box.maxx) / 2,
      (sw.box.miny + sw.box.maxy) / 2,
      (sw.box.minz + sw.box.maxz) / 2,
      0x6a8cff,
      24,
    );
    this.say("Wall reinforced! (much tougher)");
    sfxPlay.reinforce();
    this.opts.sendEvent?.({ k: "reinforce", id: sw.box.id });
  }

  private startReload(e: Ent) {
    const mag = getClass(e.team, e.classId).mag;
    if (e.reloadT > 0 || e.ammo >= mag) return;
    e.reloadT = 1.35;
    if (e.id === this.me.id) this.reloadAnim = 1;
  }

  private tryFire(e: Ent, local: boolean) {
    if (!e.alive || e.fireCd > 0 || e.reloadT > 0) return;
    const cls = getClass(e.team, e.classId);
    if (e.ammo <= 0) {
      if (local) {
        sfxPlay.empty();
        this.startReload(e);
      }
      return;
    }
    e.ammo -= 1;
    e.fireCd = 60 / cls.rpm;
    if (local) {
      sfxPlay.fire();
      this.recoil += 0.055 + cls.damage * 0.0005;
      this.trauma = Math.min(1, this.trauma + 0.1);
      this.fovKick = Math.min(4, this.fovKick + 1.8);
      this.muzzle.intensity = 5.5;
    }
    const origin = local
      ? { x: this.camera.position.x, y: this.camera.position.y, z: this.camera.position.z }
      : { x: e.pos.x, y: e.pos.y + EYE, z: e.pos.z };
    const yaw = local ? this.yaw : e.yaw;
    const pitch = local ? this.pitch : e.pitch;
    const base = new THREE.Vector3(
      -Math.sin(yaw) * Math.cos(pitch),
      Math.sin(pitch),
      -Math.cos(yaw) * Math.cos(pitch),
    ).normalize();
    for (let i = 0; i < cls.pellets; i++) {
      const dir = base.clone();
      const spr = cls.spread * (this.held("ShiftLeft") ? 1.5 : 1);
      dir.x += (Math.random() - 0.5) * spr;
      dir.y += (Math.random() - 0.5) * spr * 0.7;
      dir.z += (Math.random() - 0.5) * spr;
      dir.normalize();
      this.shootRay(e, origin, dir, cls.damage, local, cls.color);
    }
    if (local) {
      this.opts.sendEvent?.({
        k: "fire",
        ox: origin.x,
        oy: origin.y,
        oz: origin.z,
        dx: base.x,
        dy: base.y,
        dz: base.z,
        col: cls.color,
      });
    }
    if (e.ammo <= 0) this.startReload(e);
  }

  private shootRay(
    shooter: Ent,
    origin: { x: number; y: number; z: number },
    dir: THREE.Vector3,
    dmg: number,
    local: boolean,
    color: number,
  ) {
    let bestT = 80;
    let hitEnt: Ent | null = null;
    let hitWall: AABB | null = null;
    for (const w of this.walls()) {
      const t = rayAabb(origin.x, origin.y, origin.z, dir.x, dir.y, dir.z, w, bestT);
      if (t !== null && t < bestT) {
        bestT = t;
        hitWall = w;
        hitEnt = null;
      }
    }
    for (const e of this.ents.values()) {
      if (e.id === shooter.id || !e.alive || e.team === shooter.team) continue;
      const box: AABB = {
        minx: e.pos.x - 0.42,
        maxx: e.pos.x + 0.42,
        miny: e.pos.y,
        maxy: e.pos.y + 1.72,
        minz: e.pos.z - 0.42,
        maxz: e.pos.z + 0.42,
      };
      const t = rayAabb(origin.x, origin.y, origin.z, dir.x, dir.y, dir.z, box, bestT);
      if (t !== null && t < bestT) {
        bestT = t;
        hitEnt = e;
        hitWall = null;
      }
    }
    const hx = origin.x + dir.x * bestT;
    const hy = origin.y + dir.y * bestT;
    const hz = origin.z + dir.z * bestT;
    this.tracer(origin.x, origin.y, origin.z, dir.x, dir.y, dir.z, color, Math.min(bestT, 24));
    this.stain(hx, hy, hz, color);
    if (hitEnt) {
      if (local) {
        this.hitFlash = 1;
        sfxPlay.hit();
        this.opts.sendEvent?.({ k: "hit", id: hitEnt.id, dmg, by: shooter.id });
      }
      this.hurtEnt(hitEnt, dmg, shooter);
    } else if (hitWall?.kind === "breach") {
      this.damageSoftWall(hitWall, dmg);
    }
    this.burst(hx, hy, hz, color, 6);
  }

  private hurtEnt(e: Ent, dmg: number, by: Ent) {
    if (!e.alive) return;
    e.hp -= dmg;
    if (e.id === this.me.id) {
      this.hurtFlash = 1;
      this.trauma = Math.min(1, this.trauma + 0.28);
      sfxPlay.hurt();
    }
    if (e.hp <= 0) this.splat(e.id, by.name, true);
  }

  private hurt(dmg: number, by: string, _silent: boolean) {
    if (!this.me.alive) return;
    this.me.hp -= dmg;
    this.hurtFlash = 1;
    this.trauma = Math.min(1, this.trauma + 0.22);
    if (this.me.hp <= 0) this.splat(this.me.id, by, true);
  }

  private splat(id: string, by: string, emit: boolean) {
    const e = this.ents.get(id);
    if (!e || !e.alive) return;
    e.alive = false;
    e.hp = 0;
    e.respawnT = 9999; // no mid-round respawn — wait for nextRound()
    this.burst(e.pos.x, e.pos.y + 1, e.pos.z, e.team === "ATTACK" ? 0x4f63ff : 0xff6b3d, 36);
    sfxPlay.splat();
    this.pushFeed(`${by} inked ${e.name}`);
    if (e.mesh) e.mesh.visible = false;
    if (id === this.me.id) {
      this.notice = "You are down — spectating until next round";
      this.noticeT = 4;
    }
    if (emit) this.opts.sendEvent?.({ k: "splat", id, by });
  }

  private respawn(e: Ent) {
    const sp = pickSpawn(e.team, e.spawnI);
    e.pos.x = sp.x;
    e.pos.y = 0;
    e.pos.z = sp.z;
    e.hp = 100;
    e.alive = true;
    e.vy = 0;
    const cls = getClass(e.team, e.classId);
    e.ammo = cls.mag;
    e.reloadT = 0;
    if (e.mesh) {
      e.mesh.visible = true;
      e.mesh.position.set(sp.x, 0.9, sp.z);
    }
    if (e.id === this.me.id) {
      this.yaw = e.team === "ATTACK" ? 0 : Math.PI;
      this.pitch = 0;
      this.say("Back in. Go.");
    }
  }

  private useGadget(e: Ent) {
    if (e.gadgetCd > 0 || !e.alive) return;
    const cls = getClass(e.team, e.classId);
    e.gadgetCd = cls.gadgetCd;
    // Ability-specific audio
    const g = cls.gadget;
    if (g === "dash" || g === "boost") sfxPlay.dash();
    else if (g === "burst" || g === "charge") sfxPlay.fire();
    else if (g === "ping" || g === "reveal" || g === "drone") sfxPlay.ping();
    else if (g === "wall" || g === "pad" || g === "shield") sfxPlay.reinforce();
    else if (g === "erase" || g === "hazard" || g === "trap" || g === "smoke") sfxPlay.breach();
    else if (g === "heal") sfxPlay.capture();
    else sfxPlay.gadget();
    if (e.id === this.me.id) this.say(cls.gadgetName);
    const yaw = e.id === this.me.id ? this.yaw : e.yaw;
    const fx = -Math.sin(yaw);
    const fz = -Math.cos(yaw);
    const dropX = e.pos.x + fx * 1.8;
    const dropZ = e.pos.z + fz * 1.8;
    switch (cls.gadget) {
      case "dash":
        e.dashT = 0.2;
        break;
      case "burst":
        e.fireCd = 0;
        for (let i = 0; i < 6; i++) setTimeout(() => this.tryFire(e, true), i * 70);
        break;
      case "erase":
        this.eraseNear(e.pos.x, e.pos.z, 6);
        break;
      case "puddle":
        this.addZone("puddle", dropX, dropZ, 2.2, 10, 0, 0.45, 0xff4f8b);
        break;
      case "reveal":
      case "ping":
        for (const o of this.ents.values()) if (o.team !== e.team) o.revealT = 4.2;
        if (e.id === this.me.id) this.say("Enemies lit up");
        break;
      case "charge": {
        const pitch = e.id === this.me.id ? this.pitch : e.pitch;
        const origin =
          e.id === this.me.id
            ? { x: this.camera.position.x, y: this.camera.position.y, z: this.camera.position.z }
            : { x: e.pos.x, y: e.pos.y + EYE, z: e.pos.z };
        this.shootRay(
          e,
          origin,
          new THREE.Vector3(fx * Math.cos(pitch), Math.sin(pitch), fz * Math.cos(pitch)).normalize(),
          92,
          e.id === this.me.id,
          0xff5a3c,
        );
        break;
      }
      case "wall":
        this.placeWall(dropX, dropZ, yaw);
        break;
      case "pad":
        this.addZone("pad", dropX, dropZ, 2.0, 12, 0, 0.35, 0xff8ad4);
        break;
      case "hazard":
        this.addZone("hazard", dropX, dropZ, 1.8, 10, 22, 0.7, 0x3dffb0);
        break;
      case "paint":
        this.addZone("paint", dropX, dropZ, 2.4, 11, 8, 0.5, 0x4f8cff);
        break;
      case "glue": {
        let best: Ent | null = null;
        let bestD = 14;
        for (const o of this.ents.values()) {
          if (o.team === e.team || !o.alive) continue;
          const d = Math.hypot(o.pos.x - e.pos.x, o.pos.z - e.pos.z);
          if (d < bestD) {
            bestD = d;
            best = o;
          }
        }
        if (best) {
          best.frozenT = 1.7;
          this.pushFeed(`${e.name} glued ${best.name}`);
        }
        break;
      }
      case "smoke":
        this.addZone("paint", dropX, dropZ, 3.4, 9, 0, 0.55, 0x8899aa);
        this.burst(dropX, 1.2, dropZ, 0xaabbcc, 20);
        break;
      case "heal":
        for (const o of this.ents.values()) {
          if (o.team !== e.team || !o.alive) continue;
          if (Math.hypot(o.pos.x - e.pos.x, o.pos.z - e.pos.z) < 5.5) {
            o.hp = Math.min(100, o.hp + 28);
          }
        }
        this.burst(e.pos.x, e.pos.y + 1, e.pos.z, 0x4dff9a, 16);
        break;
      case "boost":
        for (const o of this.ents.values()) {
          if (o.team !== e.team || !o.alive) continue;
          if (Math.hypot(o.pos.x - e.pos.x, o.pos.z - e.pos.z) < 6) {
            o.dashT = Math.max(o.dashT, 2.2);
          }
        }
        this.burst(e.pos.x, e.pos.y + 0.5, e.pos.z, 0xffaa33, 12);
        break;
      case "trap":
        this.addZone("hazard", dropX, dropZ, 1.4, 14, 8, 0.2, 0xcc66ff);
        break;
      case "shield":
        e.hp = Math.min(100, e.hp + 18);
        e.frozenT = 0;
        this.burst(e.pos.x, e.pos.y + 1, e.pos.z, 0xc0c8d8, 10);
        break;
      case "drone":
        for (const o of this.ents.values()) {
          if (o.team === e.team || !o.alive) continue;
          if (Math.hypot(o.pos.x - e.pos.x, o.pos.z - e.pos.z) < 16) o.revealT = 5;
        }
        if (e.id === this.me.id) this.say("Drone scan active");
        break;
    }
    this.opts.sendEvent?.({ k: "gadget", kind: cls.gadget, x: dropX, z: dropZ, yaw, team: e.team });
  }

  private spawnGadgetFromNet(m: Record<string, unknown>) {
    const kind = String(m.kind);
    const x = Number(m.x) || 0;
    const z = Number(m.z) || 0;
    if (kind === "wall") this.placeWall(x, z, Number(m.yaw) || 0);
    if (kind === "puddle") this.addZone("puddle", x, z, 2.2, 10, 0, 0.45, 0xff4f8b);
    if (kind === "pad") this.addZone("pad", x, z, 2.0, 12, 0, 0.35, 0xff8ad4);
    if (kind === "hazard") this.addZone("hazard", x, z, 1.8, 10, 22, 0.7, 0x3dffb0);
    if (kind === "paint") this.addZone("paint", x, z, 2.4, 11, 8, 0.5, 0x4f8cff);
  }

  private addZone(kind: Zone["kind"], x: number, z: number, r: number, life: number, dps: number, slow: number, color: number) {
    const mesh = new THREE.Mesh(
      new THREE.CylinderGeometry(r, r, 0.08, 20),
      new THREE.MeshStandardMaterial({ color, transparent: true, opacity: 0.45, roughness: 0.8 }),
    );
    mesh.position.set(x, 0.05, z);
    this.scene.add(mesh);
    this.gadgets.push({ kind, x, z, r, life, dps, slow, mesh });
  }

  private placeWall(x: number, z: number, yaw: number) {
    const sx = 3.2;
    const sz = 0.4;
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(sx, 2.4, sz),
      new THREE.MeshStandardMaterial({ color: 0xffd24a, roughness: 0.5 }),
    );
    mesh.position.set(x, 1.2, z);
    mesh.rotation.y = yaw;
    this.scene.add(mesh);
    const c = Math.cos(yaw);
    const s = Math.sin(yaw);
    const hw = sx / 2;
    const hd = sz / 2;
    const xs = Math.abs(c) * hw + Math.abs(s) * hd;
    const zs = Math.abs(s) * hw + Math.abs(c) * hd;
    const box: AABB = { minx: x - xs, maxx: x + xs, miny: 0, maxy: 2.4, minz: z - zs, maxz: z + zs, kind: "gadget" };
    this.gadgetWalls.push({ mesh, box, life: 16 });
  }

  private eraseNear(x: number, z: number, r: number) {
    this.gadgets = this.gadgets.filter((g) => {
      if (Math.hypot(g.x - x, g.z - z) < r) {
        this.scene.remove(g.mesh);
        return false;
      }
      return true;
    });
    this.gadgetWalls = this.gadgetWalls.filter((g) => {
      const cx = (g.box.minx + g.box.maxx) / 2;
      const cz = (g.box.minz + g.box.maxz) / 2;
      if (Math.hypot(cx - x, cz - z) < r) {
        this.scene.remove(g.mesh);
        return false;
      }
      return true;
    });
  }

  private zoneAt(x: number, z: number): Zone | null {
    for (const g of this.gadgets) if (Math.hypot(g.x - x, g.z - z) <= g.r) return g;
    return null;
  }

  private tickZones(dt: number) {
    this.gadgets = this.gadgets.filter((g) => {
      g.life -= dt;
      if (g.life <= 0) {
        this.scene.remove(g.mesh);
        return false;
      }
      (g.mesh.material as THREE.MeshStandardMaterial).opacity = 0.25 + 0.2 * Math.sin(performance.now() / 180);
      return true;
    });
  }

  private tickGadgets(dt: number) {
    this.gadgetWalls = this.gadgetWalls.filter((g) => {
      g.life -= dt;
      if (g.life <= 0) {
        this.scene.remove(g.mesh);
        return false;
      }
      return true;
    });
    for (const e of this.ents.values()) e.revealT = Math.max(0, e.revealT - dt);
  }

  private tickBots(dt: number) {
    const all = Array.from(this.ents.values()) as unknown as AiEnt[];
    const softCtx = this.world.softWalls.map((s) => ({
      x: (s.box.minx + s.box.maxx) / 2,
      z: (s.box.minz + s.box.maxz) / 2,
      hp: s.hp,
      reinforced: s.reinforced,
      id: s.box.id,
    }));
    const ctx = {
      phase: this.phase,
      site: { x: MAP.site.x, z: MAP.site.z, half: MAP.site.half },
      softWalls: softCtx,
      now: performance.now(),
      bombPlanted: this.bombPlanted,
    };

    for (const e of this.ents.values()) {
      if (!e.bot) continue;
      if (!e.alive) {
        // Permadeath for the round — no mid-round bot respawn
        continue;
      }
      e.frozenT = Math.max(0, e.frozenT - dt);
      e.fireCd = Math.max(0, e.fireCd - dt);
      e.gadgetCd = Math.max(0, e.gadgetCd - dt);

      const allies = all.filter((o) => o.team === e.team && o.alive && o.id !== e.id);
      const enemies = all.filter((o) => o.team !== e.team && o.alive);
      const decision = thinkBot(
        e as unknown as AiEnt,
        allies,
        enemies,
        (a, b) => this.canSee(a as unknown as Ent, b as unknown as Ent),
        ctx,
        dt,
      );

      // --- pathfinding: repath when AI requests or path is empty/stale ---
      const ai = e as unknown as AiEnt;
      if (this.navGrid && (decision.repath || !ai.aiPath || ai.aiPath.length === 0)) {
        const path = findPath(
          this.navGrid,
          e.pos.x,
          e.pos.z,
          decision.goalX,
          decision.goalZ,
        );
        ai.aiPath = path;
        ai.aiPathVersion = this.navGrid.version;
      }

      // Steer along path if we have one
      let wishX = decision.wishX;
      let wishZ = decision.wishZ;
      if (ai.aiPath && ai.aiPath.length > 0) {
        const steer = pathSteer(ai.aiPath, e.pos.x, e.pos.z, 1.1);
        if (!steer.arrived) {
          wishX = steer.wishX;
          wishZ = steer.wishZ;
        } else {
          // arrived at goal — clear path so AI can pick a new one next think
          ai.aiPath = [];
        }
      }

      e.yaw = decision.yaw;
      e.pitch = decision.pitch;
      e.wishX = wishX;
      e.wishZ = wishZ;

      const cls = getClass(e.team, e.classId);
      let speed = cls.speed * 0.84;
      const zone = this.zoneAt(e.pos.x, e.pos.z);
      if (zone) speed *= zone.slow;
      if (e.frozenT > 0) speed = 0;

      const vx = wishX * speed;
      const vz = wishZ * speed;
      e.vy -= GRAVITY * dt;
      const moved = resolveCapsule(e.pos, e.vy, vx * dt, vz * dt, e.vy * dt, this.walls());
      e.grounded = moved.grounded;
      e.vy = moved.vy;
      if (zone && zone.dps) this.hurtEnt(e, zone.dps * dt, e);

      if (decision.wantFire) this.tryFire(e, false);

      if (decision.wantGadget && e.gadgetCd <= 0) {
        const g = getClass(e.team, e.classId);
        e.gadgetCd = g.gadgetCd;
        const fx = -Math.sin(e.yaw);
        const fz = -Math.cos(e.yaw);
        const x = e.pos.x + fx * 1.6;
        const z = e.pos.z + fz * 1.6;
        if (g.gadget === "wall") this.placeWall(x, z, e.yaw);
        if (g.gadget === "pad") this.addZone("pad", x, z, 2, 10, 0, 0.35, 0xff8ad4);
        if (g.gadget === "hazard") this.addZone("hazard", x, z, 1.8, 10, 18, 0.7, 0x3dffb0);
        if (g.gadget === "paint" || g.gadget === "puddle") this.addZone("paint", x, z, 2.2, 10, 6, 0.5, 0x4f8cff);
        if (
          g.gadget === "burst" ||
          g.gadget === "dash" ||
          g.gadget === "charge" ||
          g.gadget === "reveal" ||
          g.gadget === "erase" ||
          g.gadget === "glue" ||
          g.gadget === "ping"
        ) {
          this.useGadget(e);
        }
      }

      // Defense bots reinforce soft walls during prep (with distance check)
      if (
        this.phase === "prep" &&
        e.team === "DEFENSE" &&
        decision.state === "reinforce"
      ) {
        const near = this.nearestSoftWall(e.pos.x, e.pos.z, 2.8);
        if (near && !near.reinforced && near.hp > 0) {
          this.tryReinforce(e);
        }
      }

      // Bots plant / defuse on site during action
      if (this.phase === "action") {
        const on = onSite(e.pos.x, e.pos.z);
        if (!this.bombPlanted && e.team === "ATTACK" && on && (decision.state === "plant" || decision.state === "push")) {
          // Only one attacker effectively plants — progress is global
          if (Math.random() < 0.4) this.tryPlantOrDefuse(e, dt);
        }
        if (this.bombPlanted && e.team === "DEFENSE" && on) {
          this.tryPlantOrDefuse(e, dt);
        }
      }
    }
  }

  private nearestEnemy(e: Ent): Ent | null {
    let best: Ent | null = null;
    let d = 1e9;
    for (const o of this.ents.values()) {
      if (!o.alive || o.team === e.team) continue;
      const dd = Math.hypot(o.pos.x - e.pos.x, o.pos.z - e.pos.z);
      if (dd < d) {
        d = dd;
        best = o;
      }
    }
    return best;
  }

  private canSee(a: Ent, b: Ent) {
    const ox = a.pos.x;
    const oy = a.pos.y + EYE;
    const oz = a.pos.z;
    const dx = b.pos.x - ox;
    const dy = b.pos.y + 1.1 - oy;
    const dz = b.pos.z - oz;
    const len = Math.hypot(dx, dy, dz) || 1;
    const nx = dx / len;
    const ny = dy / len;
    const nz = dz / len;
    for (const w of this.walls()) {
      const t = rayAabb(ox, oy, oz, nx, ny, nz, w, len - 0.4);
      if (t !== null) return false;
    }
    return true;
  }

  private aliveCount(team: Team) {
    let n = 0;
    for (const e of this.ents.values()) if (e.alive && e.team === team) n++;
    return n;
  }

  private ensureBombMesh() {
    if (this.bombMesh) return;
    const g = new THREE.Group();
    const body = new THREE.Mesh(
      new THREE.BoxGeometry(0.55, 0.28, 0.4),
      new THREE.MeshStandardMaterial({ color: 0x2a2a32, roughness: 0.4, metalness: 0.5 }),
    );
    body.position.y = 0.14;
    const light = new THREE.Mesh(
      new THREE.SphereGeometry(0.08, 10, 8),
      new THREE.MeshStandardMaterial({
        color: 0xff3030,
        emissive: 0xff1010,
        emissiveIntensity: 1.2,
        roughness: 0.3,
      }),
    );
    light.position.set(0.18, 0.28, 0.1);
    g.add(body, light);
    g.visible = false;
    this.scene.add(g);
    this.bombMesh = g;
  }

  private placeBombVisual() {
    this.ensureBombMesh();
    if (!this.bombMesh) return;
    this.bombMesh.visible = true;
    this.bombMesh.position.set(MAP.site.x, 0.02, MAP.site.z);
  }

  private clearBombVisual() {
    if (this.bombMesh) this.bombMesh.visible = false;
  }

  private tickObjective(dt: number) {
    if (this.phase !== "action" || this.matchOver) return;

    // Elimination wins
    const attAlive = this.aliveCount("ATTACK");
    const defAlive = this.aliveCount("DEFENSE");
    if (attAlive === 0) {
      this.endRound("DEFENSE");
      return;
    }
    if (defAlive === 0) {
      this.endRound("ATTACK");
      return;
    }

    // Bomb planted → countdown to detonation
    if (this.bombPlanted) {
      this.bombTimer -= dt;
      this.obj = Math.max(0, this.bombTimer / 45); // HUD shows remaining fuse
      // Beep faster as time runs out
      if (Math.floor(this.bombTimer * (this.bombTimer < 10 ? 4 : 2)) !==
          Math.floor((this.bombTimer + dt) * (this.bombTimer < 10 ? 4 : 2))) {
        sfxPlay.plant();
      }
      if (this.bombMesh) {
        const pulse = 0.6 + 0.4 * Math.sin(performance.now() / (this.bombTimer < 10 ? 80 : 200));
        const m = (this.bombMesh.children[1] as THREE.Mesh)?.material as THREE.MeshStandardMaterial | undefined;
        if (m) m.emissiveIntensity = pulse * 1.5;
      }
      if (this.bombTimer <= 0) {
        this.say("Bomb detonated — Attack wins!");
        sfxPlay.breach();
        this.endRound("ATTACK");
      }
      return;
    }

    // Not planted: obj shows plant progress of local/attacker activity for HUD bar
    this.obj = this.bombPlantProgress;
  }

  private tryPlantOrDefuse(e: Ent, dt: number) {
    if (this.phase !== "action" || !e.alive) return;
    const on = onSite(e.pos.x, e.pos.z);

    if (!this.bombPlanted && e.team === "ATTACK" && on) {
      this.bombPlantProgress = Math.min(1, this.bombPlantProgress + dt / 5.5);
      if (e.id === this.me.id) {
        this.notice = `Planting bomb… ${Math.floor(this.bombPlantProgress * 100)}%`;
        this.noticeT = 0.3;
      }
      if (this.bombPlantProgress >= 1) {
        this.bombPlanted = true;
        this.bombTimer = 45;
        this.bombPlantProgress = 1;
        this.placeBombVisual();
        this.say("Bomb planted! Defense must defuse.");
        sfxPlay.plant();
        this.opts.sendEvent?.({ k: "bomb", planted: true, t: 45 });
      }
      return;
    }

    if (this.bombPlanted && e.team === "DEFENSE" && on) {
      this.bombDefuseProgress = Math.min(1, this.bombDefuseProgress + dt / 7.5);
      if (e.id === this.me.id) {
        this.notice = `Defusing… ${Math.floor(this.bombDefuseProgress * 100)}%`;
        this.noticeT = 0.3;
      }
      if (this.bombDefuseProgress >= 1) {
        this.bombPlanted = false;
        this.bombTimer = 0;
        this.bombDefuseProgress = 0;
        this.clearBombVisual();
        this.say("Bomb defused — Defense wins!");
        sfxPlay.capture();
        this.opts.sendEvent?.({ k: "bomb", planted: false });
        this.endRound("DEFENSE");
      }
      return;
    }

    // Interrupted
    if (e.id === this.me.id) {
      if (!this.bombPlanted) this.bombPlantProgress = Math.max(0, this.bombPlantProgress - dt * 0.5);
      else this.bombDefuseProgress = Math.max(0, this.bombDefuseProgress - dt * 0.6);
    }
  }

  private tickRound(dt: number) {
    if (this.matchOver) return;
    if (!(this.opts.practice || this.opts.isHost)) return;
    this.timer -= dt;
    if (this.phase === "prep" && this.timer <= 0) {
      this.phase = "action";
      this.timer = this.opts.settings.roundTime;
      this.say("Action! Plant the bomb on the gold site — or stop the plant.");
      sfxPlay.phase();
      this.broadcastPhase();
    } else if (this.phase === "action" && this.timer <= 0) {
      // Time up: if bomb planted it already has its own timer; else defense wins
      if (this.bombPlanted) {
        // Give a little extra only if somehow timer and bomb race — bomb handles detonation
      } else {
        this.endRound("DEFENSE");
      }
    } else if (this.phase === "end" && this.timer <= 0) {
      if (this.matchOver) return;
      this.nextRound();
    }
  }

  private endRound(winner: Team) {
    if (this.phase === "end" || this.matchOver) return;
    this.phase = "end";
    this.timer = 5;
    if (winner === "ATTACK") this.scoreA++;
    else this.scoreD++;
    const msg =
      winner === "ATTACK"
        ? this.bombPlanted && this.bombTimer <= 0
          ? "Bomb detonated — Attack wins."
          : "Attack eliminates Defense."
        : this.bombDefuseProgress >= 1
          ? "Bomb defused — Defense wins."
          : "Defense holds the site.";
    this.say(msg);
    if (winner === this.me.team) sfxPlay.win();
    else sfxPlay.lose();
    const need = Math.ceil(this.opts.settings.rounds / 2);
    if (this.scoreA >= need || this.scoreD >= need || this.round >= this.opts.settings.rounds) {
      this.matchOver = true;
      this.matchWinner = this.scoreA > this.scoreD ? "ATTACK" : "DEFENSE";
      this.timer = 8;
    }
    this.broadcastPhase();
  }

  private nextRound() {
    this.round++;
    this.phase = "prep";
    this.timer = 12;
    this.obj = 0;
    this.reinforceProgress = 0;
    this.reinforceTarget = null;
    this.bombPlanted = false;
    this.bombPlantProgress = 0;
    this.bombDefuseProgress = 0;
    this.bombTimer = 0;
    this.clearBombVisual();
    for (const sw of this.world.softWalls) {
      sw.hp = sw.maxHp;
      sw.reinforced = false;
      sw.mesh.visible = true;
      sw.mesh.scale.set(1, 1, 1);
      const mat = sw.mesh.material as THREE.MeshStandardMaterial;
      mat.opacity = 0.92;
      mat.color.setHex(0x8cc7f0);
      mat.emissive = new THREE.Color(0x000000);
      mat.emissiveIntensity = 0;
      mat.metalness = 0;
      mat.roughness = 0.4;
      mat.transparent = true;
      if (!this.colliders.includes(sw.box)) this.colliders.push(sw.box);
    }
    // Rebuild nav grid so destroyed soft walls are blocked again
    this.navGrid = buildGrid(MAP, this.colliders);
    for (const e of this.ents.values()) {
      this.respawn(e);
      // clear AI paths
      (e as Ent).aiPath = [];
    }
    this.say(`Round ${this.round} — reinforce soft walls or stage for the push`);
    this.broadcastPhase();
  }

  private broadcastPhase() {
    this.opts.sendEvent?.({
      k: "phase",
      phase: this.phase,
      round: this.round,
      t: this.timer,
      scoreA: this.scoreA,
      scoreD: this.scoreD,
      obj: this.obj,
      over: this.matchOver,
      win: this.matchWinner,
    });
  }

  private damageSoftWall(wall: AABB, dmg: number) {
    const sw = this.world.softWalls.find((s) => s.box === wall || s.box.id === wall.id);
    if (!sw || sw.hp <= 0) return;
    if (sw.reinforced) dmg = Math.floor(dmg * 0.22); // reinforced is much tougher
    sw.hp -= dmg;
    const m = sw.mesh.material as THREE.MeshStandardMaterial;
    const ratio = Math.max(0, sw.hp / sw.maxHp);
    if (!sw.reinforced) m.opacity = 0.35 + 0.57 * ratio;
    if (sw.hp <= 0) {
      sw.mesh.visible = false;
      this.colliders = this.colliders.filter((c) => c !== sw.box);
      if (this.navGrid) markRegion(this.navGrid, sw.box, false); // open the path
      const cx = (sw.box.minx + sw.box.maxx) / 2;
      const cy = (sw.box.miny + sw.box.maxy) / 2;
      const cz = (sw.box.minz + sw.box.maxz) / 2;
      this.burst(cx, cy, cz, 0x8cc7f0, 48);
      this.say("Soft wall shattered!");
      sfxPlay.breach();
    }
  }

  private applyRemote(id: string, m: Record<string, unknown>) {
    let e = this.ents.get(id);
    const team = (m.team as Team) || "ATTACK";
    const classId = (Number(m.classId) || 0) as ClassId;
    if (!e) {
      e = this.makeEnt(id, String(m.name || "Player"), false, team, classId, Number(m.x) || 0, Number(m.z) || 0, 0);
      this.ents.set(id, e);
    }
    e.pos.x = Number(m.x) || e.pos.x;
    e.pos.y = Number(m.y) || e.pos.y;
    e.pos.z = Number(m.z) || e.pos.z;
    e.yaw = Number(m.yaw) || e.yaw;
    e.pitch = Number(m.pitch) || 0;
    e.hp = Number(m.hp) ?? e.hp;
    e.alive = Boolean(m.alive);
    e.name = String(m.name || e.name);
    if (e.mesh) e.mesh.visible = e.alive;
  }

  private upsertBot(raw: FighterState) {
    let e = this.ents.get(raw.id);
    if (!e) {
      e = this.makeEnt(raw.id, raw.name, true, raw.team, raw.classId, raw.x, raw.z, 0);
      this.ents.set(raw.id, e);
    }
    e.pos.x = raw.x;
    e.pos.y = raw.y;
    e.pos.z = raw.z;
    e.yaw = raw.yaw;
    e.hp = raw.hp;
    e.alive = raw.alive;
    if (e.mesh) e.mesh.visible = e.alive;
  }

  private syncMeshes() {
    const t = performance.now() / 1000;
    for (const e of this.ents.values()) {
      if (!e.mesh) continue;
      // Walk bob for bots / other players
      const moving = e.alive && (Math.abs(e.wishX) + Math.abs(e.wishZ) > 0.15 || e.bot);
      const bob = e.alive && e.grounded ? Math.abs(Math.sin(t * 8 + e.spawnI)) * (moving ? 0.06 : 0.01) : 0;
      e.mesh.position.x = e.pos.x;
      e.mesh.position.y = e.pos.y + 0.9 + bob;
      e.mesh.position.z = e.pos.z;
      e.mesh.rotation.y = e.yaw;
      // Slight lean into move
      e.mesh.rotation.z = e.alive ? e.wishX * 0.08 : 0;
      e.mesh.rotation.x = e.alive ? -e.wishZ * 0.04 : 0;
      // Reveal glow on first mesh with material
      for (const child of e.mesh.children) {
        const mesh = child as THREE.Mesh;
        if (!mesh.isMesh) continue;
        const mat = mesh.material as THREE.MeshStandardMaterial;
        if (!mat || !mat.emissive) continue;
        if (e.revealT > 0) {
          mat.emissive.setHex(0xffef4a);
          mat.emissiveIntensity = 0.85 + Math.sin(t * 10) * 0.15;
        } else if (mat.emissiveIntensity > 0.01 && mat.emissive.getHex() === 0xffef4a) {
          mat.emissiveIntensity = 0;
        }
      }
    }
  }

  private tracer(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, color: number, len = 6) {
    const mesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.03, 0.03, 1, 5),
      new THREE.MeshBasicMaterial({ color }),
    );
    const d = new THREE.Vector3(dx, dy, dz).normalize();
    mesh.position.set(ox + d.x * (len * 0.5), oy + d.y * (len * 0.5), oz + d.z * (len * 0.5));
    mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d);
    mesh.scale.set(1, len, 1);
    this.scene.add(mesh);
    this.tracers.push({ mesh, life: 0.12 });
  }

  private stain(x: number, y: number, z: number, color: number) {
    const m = this.decals[this.decalI++ % this.decals.length];
    m.visible = true;
    m.position.set(x, y, z);
    (m.material as THREE.MeshBasicMaterial).color.setHex(color);
    m.lookAt(x, y + 1, z);
  }

  private burst(x: number, y: number, z: number, color: number, n: number) {
    let used = 0;
    for (const p of this.particles) {
      if (p.alive) continue;
      p.alive = true;
      p.life = 0.45 + Math.random() * 0.55;
      const speed = 4 + Math.random() * 7;
      const ang = Math.random() * Math.PI * 2;
      p.vx = Math.cos(ang) * speed * (0.4 + Math.random());
      p.vy = 1.5 + Math.random() * 6;
      p.vz = Math.sin(ang) * speed * (0.4 + Math.random());
      p.mesh.visible = true;
      p.mesh.position.set(x + (Math.random() - 0.5) * 0.2, y, z + (Math.random() - 0.5) * 0.2);
      p.mesh.scale.setScalar(0.7 + Math.random() * 0.9);
      const mat = p.mesh.material as THREE.MeshStandardMaterial;
      mat.color.setHex(color);
      if (Math.random() > 0.4) mat.color.offsetHSL((Math.random() - 0.5) * 0.15, 0, (Math.random() - 0.5) * 0.1);
      used++;
      if (used >= n) break;
    }
  }

  private placeCamera() {
    const moving = this.me.grounded && this.me.alive && (this.held("KeyW") || this.held("KeyS") || this.held("KeyA") || this.held("KeyD"));
    const sprint = moving && (this.held("ShiftLeft") || this.held("ShiftRight"));
    // Dual-frequency bob (vertical + slight lateral) — less nausea, more natural
    const bobAmp = moving ? (sprint ? 0.048 : 0.032) : 0.008;
    const bobY = this.me.grounded && this.me.alive ? Math.sin(this.bob) * bobAmp : 0;
    const bobX = this.me.grounded && this.me.alive ? Math.sin(this.bob * 0.5) * bobAmp * 0.35 : 0;
    // Landing squash recovery
    const land = this.landSquash * 0.06;
    this.camera.position.set(
      this.me.pos.x + bobX,
      this.me.pos.y + EYE + bobY - land,
      this.me.pos.z,
    );
    this.camera.rotation.order = "YXZ";
    this.camera.rotation.y = this.yaw;
    this.camera.rotation.x = this.pitch;
    // Subtle roll while strafing
    const strafe = (this.held("KeyD") ? 1 : 0) - (this.held("KeyA") ? 1 : 0);
    this.camera.rotation.z = strafe * 0.025 + Math.sin(this.bob) * (moving ? 0.012 : 0.004);
  }

  private draw(dt: number) {
    this.trauma = Math.max(0, this.trauma - dt * 1.8);
    this.hitFlash = Math.max(0, this.hitFlash - dt * 4);
    this.hurtFlash = Math.max(0, this.hurtFlash - dt * 2.2);
    // Spring-damper recoil return
    this.recoil = Math.max(0, this.recoil - dt * 4.5);
    this.landSquash = Math.max(0, this.landSquash - dt * 5);
    this.fovKick = Math.max(0, this.fovKick - dt * 8);
    this.reloadAnim = Math.max(0, this.reloadAnim - dt * 1.4);
    this.muzzle.intensity = Math.max(0, this.muzzle.intensity - dt * 32);
    if (this.noticeT > 0) this.noticeT -= dt;
    else this.notice = this.notice && this.phase === "action" ? "" : this.notice;

    // Landing detection → squash + dust
    if (this.me.grounded && !this.wasGrounded && this.me.alive) {
      this.landSquash = 1;
      this.trauma = Math.min(1, this.trauma + 0.08);
      this.burst(this.me.pos.x, 0.1, this.me.pos.z, 0xd4c4a0, 8);
      sfxPlay.land();
    }
    this.wasGrounded = this.me.grounded;

    // Look sway (lags mouse slightly)
    const targetSwayX = this.lookX * 0.015;
    const targetSwayY = this.lookY * 0.012;
    this.swayX += (targetSwayX - this.swayX) * Math.min(1, dt * 10);
    this.swayY += (targetSwayY - this.swayY) * Math.min(1, dt * 10);
    this.lookX *= 0.85;
    this.lookY *= 0.85;

    // FOV kick on sprint / fire
    const sprinting = this.me.alive && (this.held("ShiftLeft") || this.held("ShiftRight")) &&
      (this.held("KeyW") || this.held("KeyS") || this.held("KeyA") || this.held("KeyD"));
    const baseFov = 72 + (sprinting ? 6 : 0) + this.fovKick;
    if (Math.abs(this.camera.fov - baseFov) > 0.05) {
      this.camera.fov += (baseFov - this.camera.fov) * Math.min(1, dt * 8);
      this.camera.updateProjectionMatrix();
    }

    this.placeCamera();
    // Trauma² screen shake (GDC-style falloff)
    if (!this.reduced && this.trauma > 0.01) {
      const s = this.trauma * this.trauma;
      this.camera.position.x += (Math.random() - 0.5) * s * 0.22;
      this.camera.position.y += (Math.random() - 0.5) * s * 0.16;
      this.camera.rotation.z += (Math.random() - 0.5) * s * 0.03;
    }

    // Viewmodel: bob + recoil spring + sway + sprint lower + reload dip
    const sprintDip = sprinting ? 0.08 : 0;
    const reloadDip = this.reloadAnim * 0.2;
    const bobY = Math.sin(this.bob) * 0.018;
    const bobX = Math.cos(this.bob * 0.5) * 0.012;
    this.viewmodel.position.set(
      0.34 + bobX + this.swayX - sprintDip * 0.05,
      -0.26 + bobY - this.recoil * 0.14 - sprintDip - reloadDip + this.swayY,
      -0.6 + this.recoil * 0.22,
    );
    this.viewmodel.rotation.x = this.recoil * 0.42 + this.reloadAnim * 0.5 + this.swayY * 0.3;
    this.viewmodel.rotation.y = this.swayX * 0.4;
    this.viewmodel.rotation.z = Math.sin(this.bob) * 0.05 + (sprinting ? 0.08 : 0);

    for (const p of this.particles) {
      if (!p.alive) continue;
      p.life -= dt;
      p.vy -= 16 * dt;
      p.vx *= 0.98;
      p.vz *= 0.98;
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;
      const fade = Math.max(0.15, Math.min(1, p.life * 2));
      p.mesh.scale.setScalar(fade * (0.5 + p.life));
      const mat = p.mesh.material as THREE.MeshStandardMaterial;
      mat.opacity = fade;
      mat.transparent = true;
      if (p.life <= 0 || p.mesh.position.y < -0.2) {
        p.alive = false;
        p.mesh.visible = false;
      }
    }
    this.tracers = this.tracers.filter((t) => {
      t.life -= dt;
      if (t.life <= 0) {
        this.scene.remove(t.mesh);
        t.mesh.geometry.dispose();
        (t.mesh.material as THREE.Material).dispose();
        return false;
      }
      return true;
    });

    const pulse = 0.35 + Math.sin(performance.now() / 320) * 0.12;
    (this.world.siteMesh.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.25 + this.obj * 0.8 + pulse * 0.15;

    this.renderer.render(this.scene, this.camera);
  }

  private say(msg: string) {
    this.notice = msg;
    this.noticeT = 2.4;
  }

  private pushFeed(line: string) {
    this.feed = [line, ...this.feed].slice(0, 5);
  }

  private buildHud(): HudSnap {
    const cls = getClass(this.me.team, this.me.classId);
    let allies = 0;
    let enemies = 0;
    for (const e of this.ents.values()) {
      if (!e.alive) continue;
      if (e.team === this.me.team) allies++;
      else enemies++;
    }
    const capturing =
      this.phase === "action" && this.me.alive && this.me.team === "ATTACK" && onSite(this.me.pos.x, this.me.pos.z);
    const speed = Math.hypot(
      -Math.sin(this.yaw) * (this.held("KeyW") ? 1 : 0),
      -Math.cos(this.yaw) * (this.held("KeyW") ? 1 : 0),
    );
    return {
      hp: Math.max(0, this.me.hp),
      ammo: this.me.ammo,
      mag: cls.mag,
      reloading: this.me.reloadT > 0,
      gadgetReady: this.me.gadgetCd <= 0,
      gadgetName: cls.gadgetName,
      timer: Math.max(0, this.timer),
      phase: this.phase,
      round: this.round,
      maxRounds: this.opts.settings.rounds,
      scoreA: this.scoreA,
      scoreD: this.scoreD,
      obj: this.obj,
      team: this.me.team,
      className: cls.name,
      notice: this.notice,
      hit: this.hitFlash,
      hurt: this.hurtFlash,
      alive: this.me.alive,
      respawn: Math.max(0, this.me.respawnT),
      paused: this.paused,
      locked: this.locked,
      capturing,
      feed: this.feed,
      result: this.matchOver ? "match" : null,
      matchWinner: this.matchWinner,
      allies,
      enemies,
      yaw: this.yaw,
      speed: this.me.alive && (this.held("KeyW") || this.held("KeyS") || this.held("KeyA") || this.held("KeyD")) ? cls.speed : 0,
    };
  }

  private installProbe() {
    window.__controlsTest = {
      getYaw: () => this.yaw,
      getSpeed: () => {
        const h = this.buildHud();
        return h.speed;
      },
      getPos: () => ({ ...this.me.pos }),
      setKeys: (codes: string[]) => {
        this.qaKeys = codes;
      },
    };
  }
}

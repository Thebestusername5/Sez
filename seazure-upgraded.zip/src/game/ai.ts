/**
 * Seazure bot brain — role-aware FSM + pathfinding goals.
 * Engine owns the grid & path following; AI only decides *where* to go and combat intent.
 */

import { getClass } from "./classes";
import type { ClassId, Team } from "./types";
import type { PathNode } from "./pathfinding";

/** Minimal entity shape the AI needs (keeps engine decoupled). */
export interface AiEnt {
  id: string;
  bot: boolean;
  team: Team;
  classId: ClassId;
  pos: { x: number; y: number; z: number };
  yaw: number;
  pitch: number;
  hp: number;
  alive: boolean;
  fireCd: number;
  gadgetCd: number;
  frozenT: number;
  spawnI: number;
  thinkT: number;
  wishX: number;
  wishZ: number;
  /** AI-only state */
  aiState?: AiState;
  aiTargetId?: string | null;
  aiHoldT?: number;
  aiFlankSide?: number;
  /** Path following (managed by engine) */
  aiPath?: PathNode[];
  aiPathVersion?: number;
  aiGoalX?: number;
  aiGoalZ?: number;
  aiRepathT?: number;
}

export type AiState =
  | "spawn"
  | "approach"
  | "hold"
  | "push"
  | "flank"
  | "engage"
  | "retreat"
  | "plant"
  | "reinforce";

export interface AiContext {
  phase: "prep" | "action" | "end";
  site: { x: number; z: number; half: number };
  softWalls: { x: number; z: number; hp: number; reinforced: boolean; id?: string }[];
  now: number;
  bombPlanted?: boolean;
  /** Optional: ask engine for a path; returns waypoints or empty */
  requestPath?: (fromX: number, fromZ: number, toX: number, toZ: number) => PathNode[];
}

export interface AiDecision {
  wishX: number;
  wishZ: number;
  yaw: number;
  pitch: number;
  wantFire: boolean;
  wantGadget: boolean;
  state: AiState;
  /** World goal the bot wants to reach (engine may pathfind to it) */
  goalX: number;
  goalZ: number;
  /** If true, engine should force a repath */
  repath: boolean;
}

function hypot2(ax: number, az: number, bx: number, bz: number) {
  const dx = bx - ax;
  const dz = bz - az;
  return Math.hypot(dx, dz);
}

function dirTo(from: { x: number; z: number }, to: { x: number; z: number }) {
  const dx = to.x - from.x;
  const dz = to.z - from.z;
  const len = Math.hypot(dx, dz) || 1;
  return { x: dx / len, z: dz / len, dist: len };
}

/** Smarter bot brain — team-aware roles + phase-aware tactics + path goals. */
export function thinkBot(
  e: AiEnt,
  allies: AiEnt[],
  enemies: AiEnt[],
  canSee: (a: AiEnt, b: AiEnt) => boolean,
  ctx: AiContext,
  dt: number,
): AiDecision {
  const cls = getClass(e.team, e.classId);
  const site = ctx.site;
  const onSite =
    Math.abs(e.pos.x - site.x) <= site.half + 1.2 &&
    Math.abs(e.pos.z - site.z) <= site.half + 1.2;

  // --- nearest / visible enemy ---
  let nearest: AiEnt | null = null;
  let nearestDist = 1e9;
  let visible: AiEnt | null = null;
  let visibleDist = 1e9;
  for (const o of enemies) {
    if (!o.alive) continue;
    const d = hypot2(e.pos.x, e.pos.z, o.pos.x, o.pos.z);
    if (d < nearestDist) {
      nearestDist = d;
      nearest = o;
    }
    if (d < 28 && canSee(e, o) && d < visibleDist) {
      visibleDist = d;
      visible = o;
    }
  }

  // --- state machine ---
  let state: AiState = e.aiState || "spawn";
  e.aiHoldT = (e.aiHoldT ?? 0) - dt;
  e.aiRepathT = (e.aiRepathT ?? 0) - dt;

  if (ctx.phase === "prep") {
    if (e.team === "DEFENSE") {
      // Prefer unreinforced soft walls
      const soft = ctx.softWalls.find((s) => s.hp > 0 && !s.reinforced);
      if (soft && (e.aiHoldT <= 0 || state === "reinforce")) {
        state = "reinforce";
        e.aiHoldT = 3 + Math.random() * 4;
      } else {
        state = "hold";
        if (e.aiHoldT <= 0) e.aiHoldT = 2 + Math.random() * 3;
      }
    } else {
      // Attackers stage outside, some flank early
      state = Math.random() < 0.25 ? "flank" : "approach";
    }
  } else if (ctx.phase === "action") {
    if (e.team === "ATTACK") {
      if (visible && visibleDist < 14) state = "engage";
      else if (e.hp < 32 && nearest && nearestDist < 11) state = "retreat";
      else if (ctx.bombPlanted) state = "hold"; // protect planted bomb
      else if (onSite || Math.random() < 0.2) state = "plant";
      else if (state === "flank" || Math.random() < 0.06) state = "flank";
      else state = "push";
    } else {
      if (visible && visibleDist < 13) state = "engage";
      else if (e.hp < 28 && nearest && nearestDist < 9) state = "retreat";
      else if (ctx.bombPlanted) state = "plant"; // rush site to defuse (reuse plant state as defuse goal)
      else if (onSite || e.aiHoldT > 0) state = "hold";
      else state = "approach";
    }
  } else {
    state = "hold";
  }

  e.aiState = state;

  // --- choose goal position ---
  let tx = site.x;
  let tz = site.z;
  const spawnBias = (e.spawnI - 2) * 2.2;
  let repath = false;

  switch (state) {
    case "approach":
      if (e.team === "ATTACK") {
        tx = site.x + spawnBias * 0.5;
        tz = site.z + 8 + Math.random() * 3;
      } else {
        tx = site.x + spawnBias;
        tz = site.z - 2.5;
      }
      break;
    case "push":
    case "plant":
      tx = site.x + (Math.random() - 0.5) * 2.5;
      tz = site.z + (Math.random() - 0.5) * 2.5;
      break;
    case "hold":
      tx = site.x + spawnBias * 0.8;
      tz = site.z + (e.team === "DEFENSE" ? -3.2 : 2.0);
      if (Math.random() < 0.015) {
        e.aiFlankSide = Math.random() < 0.5 ? -1 : 1;
      }
      tx += (e.aiFlankSide || 0) * 2.4;
      break;
    case "flank":
      if (e.aiFlankSide == null) e.aiFlankSide = Math.random() < 0.5 ? -1 : 1;
      tx = site.x + e.aiFlankSide * (12 + Math.random() * 6);
      tz = site.z + (e.team === "ATTACK" ? 4 : -4) + (Math.random() - 0.5) * 4;
      break;
    case "engage":
      if (visible) {
        // Strafe while engaging — don't walk straight into fire
        const d = dirTo(e.pos, visible.pos);
        const side = e.aiFlankSide ?? (Math.random() < 0.5 ? -1 : 1);
        e.aiFlankSide = side;
        // Circle / keep distance ~7-10m
        const prefer = visibleDist > 11 ? 0.7 : visibleDist < 6 ? -0.85 : 0.15;
        tx = e.pos.x + d.x * prefer * 4 + (-d.z) * side * 3.5;
        tz = e.pos.z + d.z * prefer * 4 + d.x * side * 3.5;
      }
      break;
    case "retreat":
      // Fall back toward own spawn / away from threat
      if (nearest) {
        const d = dirTo(e.pos, nearest.pos);
        tx = e.pos.x - d.x * 10;
        tz = e.pos.z - d.z * 10;
      } else {
        tx = site.x;
        tz = site.z + (e.team === "DEFENSE" ? -8 : 8);
      }
      break;
    case "reinforce": {
      const soft =
        ctx.softWalls.find((s) => s.hp > 0 && !s.reinforced) ||
        ctx.softWalls.find((s) => s.hp > 0);
      if (soft) {
        tx = soft.x;
        tz = soft.z;
      } else {
        state = "hold";
        tx = site.x + spawnBias;
        tz = site.z - 2;
      }
      break;
    }
  }

  // Clamp goal roughly into map (engine pathfinder will snap)
  // Store desired goal
  const goalChanged =
    e.aiGoalX == null ||
    e.aiGoalZ == null ||
    Math.hypot((e.aiGoalX ?? 0) - tx, (e.aiGoalZ ?? 0) - tz) > 2.5;

  if (goalChanged || (e.aiRepathT ?? 0) <= 0) {
    repath = true;
    e.aiRepathT = 1.8 + Math.random() * 1.4; // repath every ~2s or on goal change
  }
  e.aiGoalX = tx;
  e.aiGoalZ = tz;

  // --- movement: if we have a path, steer along it; else direct ---
  let wishX = 0;
  let wishZ = 0;

  if (e.aiPath && e.aiPath.length > 0) {
    // Path following is primarily done in engine via pathSteer;
    // here we still provide a fallback direct vector toward current goal
    // so bots don't freeze if path is stale for a frame.
    const d = dirTo(e.pos, { x: tx, z: tz });
    // Slow when close to goal
    const speedScale = d.dist < 1.2 ? Math.max(0.15, d.dist / 1.2) : 1;
    wishX = d.x * speedScale;
    wishZ = d.z * speedScale;
  } else {
    const d = dirTo(e.pos, { x: tx, z: tz });
    if (d.dist > 0.6) {
      wishX = d.x;
      wishZ = d.z;
    }
  }

  // While engaging, prefer lateral movement over pure goal chase
  if (state === "engage" && visible) {
    const d = dirTo(e.pos, visible.pos);
    const side = e.aiFlankSide ?? 1;
    wishX = wishX * 0.35 + (-d.z) * side * 0.75;
    wishZ = wishZ * 0.35 + d.x * side * 0.75;
    const len = Math.hypot(wishX, wishZ) || 1;
    wishX /= len;
    wishZ /= len;
  }

  // --- facing / combat ---
  let yaw = e.yaw;
  let pitch = 0;
  let wantFire = false;

  if (visible) {
    const dx = visible.pos.x - e.pos.x;
    const dy = (visible.pos.y + 1.2) - (e.pos.y + 1.55);
    const dz = visible.pos.z - e.pos.z;
    const dist = Math.hypot(dx, dz) || 1;
    yaw = Math.atan2(-dx / dist, -dz / dist);
    pitch = Math.atan2(dy, dist);
    if (e.fireCd <= 0 && visibleDist < 18) {
      const aimErr = Math.abs(Math.atan2(Math.sin(yaw - e.yaw), Math.cos(yaw - e.yaw)));
      // Better accuracy when holding / closer
      const thresh = state === "hold" || state === "engage" ? 0.28 : 0.38;
      if (aimErr < thresh) wantFire = true;
    }
  } else if (nearest && nearestDist < 24) {
    const d = dirTo(e.pos, nearest.pos);
    yaw = Math.atan2(-d.x, -d.z);
  } else {
    const d = dirTo(e.pos, { x: tx, z: tz });
    if (d.dist > 1) yaw = Math.atan2(-d.x, -d.z);
  }

  // --- gadget use (role-aware) ---
  let wantGadget = false;
  if (e.gadgetCd <= 0 && e.frozenT <= 0 && ctx.phase === "action") {
    const g = cls.gadget;
    const roll = Math.random();
    if (e.team === "ATTACK") {
      if (g === "dash" && nearestDist > 5 && nearestDist < 20 && roll < 0.014) wantGadget = true;
      if (g === "burst" && visible && visibleDist < 15 && roll < 0.02) wantGadget = true;
      if (g === "charge" && visible && visibleDist < 13 && roll < 0.012) wantGadget = true;
      if (g === "puddle" && onSite && roll < 0.01) wantGadget = true;
      if (g === "reveal" && nearest && nearestDist < 22 && !visible && roll < 0.016) wantGadget = true;
      if (g === "erase" && roll < 0.007) wantGadget = true;
      if (g === "smoke" && nearestDist < 16 && roll < 0.012) wantGadget = true;
      if (g === "heal" && e.hp < 70 && roll < 0.015) wantGadget = true;
      if (g === "boost" && nearestDist > 8 && roll < 0.01) wantGadget = true;
      if (g === "drone" && nearest && !visible && roll < 0.014) wantGadget = true;
      if (g === "shield" && e.hp < 55 && roll < 0.012) wantGadget = true;
      if (g === "trap" && onSite && roll < 0.01) wantGadget = true;
    } else {
      if ((g === "wall" || g === "pad" || g === "hazard" || g === "paint") && (onSite || state === "hold") && roll < 0.016)
        wantGadget = true;
      if (g === "glue" && visible && visibleDist < 10 && roll < 0.022) wantGadget = true;
      if (g === "ping" && nearest && nearestDist < 24 && roll < 0.012) wantGadget = true;
      if (g === "hazard" && state === "hold" && roll < 0.012) wantGadget = true;
      if (g === "smoke" && visible && visibleDist < 14 && roll < 0.012) wantGadget = true;
      if (g === "heal" && e.hp < 65 && roll < 0.014) wantGadget = true;
      if (g === "shield" && (onSite || e.hp < 50) && roll < 0.012) wantGadget = true;
      if (g === "trap" && onSite && roll < 0.012) wantGadget = true;
      if (g === "drone" && nearest && nearestDist < 20 && roll < 0.012) wantGadget = true;
      if (g === "boost" && nearestDist > 10 && roll < 0.01) wantGadget = true;
    }
  }

  // Prep reinforce intent (engine will call tryReinforce when near)
  if (ctx.phase === "prep" && e.team === "DEFENSE" && state === "reinforce") {
    // no gadget needed; engine handles E-hold simulation for bots
  }

  return {
    wishX,
    wishZ,
    yaw,
    pitch,
    wantFire,
    wantGadget,
    state,
    goalX: tx,
    goalZ: tz,
    repath,
  };
}

export function pickBotClass(team: Team, index: number): ClassId {
  if (team === "ATTACK") {
    const order: ClassId[] = [0, 1, 5, 4, 6, 7, 8, 9, 2, 3, 10, 11];
    return order[index % order.length];
  }
  const order: ClassId[] = [0, 1, 5, 2, 6, 7, 8, 9, 3, 4, 10, 11];
  return order[index % order.length];
}

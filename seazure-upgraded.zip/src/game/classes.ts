import type { ClassDef, ClassId, Team } from "./types";

export const ATTACK_CLASSES: ClassDef[] = [
  { id: 0, name: "Sketcher", role: "Entry", blurb: "Hard-breach burst specialist.", team: "ATTACK", damage: 28, pellets: 1, rpm: 190, mag: 12, spread: 0.018, speed: 5.3, gadget: "burst", gadgetName: "Sketch Burst", gadgetCd: 11, color: 0x5c6cff },
  { id: 1, name: "Marker", role: "Fragger", blurb: "High-speed dash entry.", team: "ATTACK", damage: 18, pellets: 1, rpm: 340, mag: 18, spread: 0.028, speed: 6.5, gadget: "dash", gadgetName: "Ink Dash", gadgetCd: 7, color: 0x3ad0ff },
  { id: 2, name: "Eraser", role: "Support", blurb: "Wipes enemy gadgets and soft walls.", team: "ATTACK", damage: 24, pellets: 1, rpm: 170, mag: 10, spread: 0.02, speed: 5.4, gadget: "erase", gadgetName: "Wipe", gadgetCd: 10, color: 0xf2f2f2 },
  { id: 3, name: "Sprayer", role: "Crowd Control", blurb: "Shotgun + slowing paint pool.", team: "ATTACK", damage: 11, pellets: 6, rpm: 95, mag: 6, spread: 0.12, speed: 4.9, gadget: "puddle", gadgetName: "Paint Pool", gadgetCd: 12, color: 0xff4f8b },
  { id: 4, name: "Highlighter", role: "Intel", blurb: "Reveals defenders through walls.", team: "ATTACK", damage: 26, pellets: 1, rpm: 155, mag: 10, spread: 0.016, speed: 5.6, gadget: "reveal", gadgetName: "Reveal", gadgetCd: 14, color: 0xffef4a },
  { id: 5, name: "Crayonner", role: "Hard Breach", blurb: "Slow mega-crayon launcher.", team: "ATTACK", damage: 52, pellets: 1, rpm: 72, mag: 5, spread: 0.01, speed: 4.3, gadget: "charge", gadgetName: "Mega Crayon", gadgetCd: 16, color: 0xff5a3c },
  // NEW
  { id: 6, name: "Smog", role: "Cover", blurb: "Drops a thick ink smoke screen for the plant.", team: "ATTACK", damage: 22, pellets: 1, rpm: 200, mag: 14, spread: 0.022, speed: 5.5, gadget: "smoke", gadgetName: "Ink Smoke", gadgetCd: 13, color: 0x8899aa },
  { id: 7, name: "Medic", role: "Support", blurb: "Heals nearby allies with a crayon pulse.", team: "ATTACK", damage: 20, pellets: 1, rpm: 210, mag: 14, spread: 0.02, speed: 5.2, gadget: "heal", gadgetName: "Heal Pulse", gadgetCd: 14, color: 0x4dff9a },
  { id: 8, name: "Rush", role: "Entry", blurb: "Team speed boost for aggressive executes.", team: "ATTACK", damage: 19, pellets: 1, rpm: 280, mag: 16, spread: 0.026, speed: 6.2, gadget: "boost", gadgetName: "Sprint Ink", gadgetCd: 12, color: 0xffaa33 },
  { id: 9, name: "Scout", role: "Intel", blurb: "Deploys a short-range drone ping.", team: "ATTACK", damage: 24, pellets: 1, rpm: 165, mag: 11, spread: 0.017, speed: 5.7, gadget: "drone", gadgetName: "Doodle Drone", gadgetCd: 11, color: 0x66eeff },
  { id: 10, name: "Sledge", role: "Breach", blurb: "Shield charge that soaks a few hits while pushing.", team: "ATTACK", damage: 30, pellets: 1, rpm: 140, mag: 9, spread: 0.015, speed: 4.8, gadget: "shield", gadgetName: "Paper Shield", gadgetCd: 15, color: 0xc0c8d8 },
  { id: 11, name: "Trip", role: "Trap", blurb: "Places a tripwire trap that freezes attackers.", team: "ATTACK", damage: 21, pellets: 1, rpm: 175, mag: 12, spread: 0.02, speed: 5.3, gadget: "trap", gadgetName: "Trip Line", gadgetCd: 12, color: 0xcc66ff },
];

export const DEFENSE_CLASSES: ClassDef[] = [
  { id: 0, name: "Builder", role: "Anchor", blurb: "Drops a crayon barricade.", team: "DEFENSE", damage: 26, pellets: 1, rpm: 160, mag: 12, spread: 0.02, speed: 4.9, gadget: "wall", gadgetName: "Barricade", gadgetCd: 12, color: 0x7a5cff },
  { id: 1, name: "Sticker", role: "Trap", blurb: "Sticky pad slows flanks.", team: "DEFENSE", damage: 20, pellets: 1, rpm: 180, mag: 12, spread: 0.022, speed: 5.1, gadget: "pad", gadgetName: "Sticky Pad", gadgetCd: 10, color: 0xff8ad4 },
  { id: 2, name: "Sharpener", role: "Roamer", blurb: "Hazard spinner chips trespassers.", team: "DEFENSE", damage: 27, pellets: 1, rpm: 150, mag: 10, spread: 0.018, speed: 5.0, gadget: "hazard", gadgetName: "Spinner", gadgetCd: 13, color: 0x3dffb0 },
  { id: 3, name: "Painter", role: "Denial", blurb: "Floods lanes with wet paint.", team: "DEFENSE", damage: 16, pellets: 1, rpm: 230, mag: 16, spread: 0.03, speed: 5.2, gadget: "paint", gadgetName: "Flood", gadgetCd: 11, color: 0x4f8cff },
  { id: 4, name: "Glue", role: "Crowd Control", blurb: "Freezes the nearest attacker.", team: "DEFENSE", damage: 22, pellets: 1, rpm: 155, mag: 10, spread: 0.02, speed: 4.8, gadget: "glue", gadgetName: "Glue Glob", gadgetCd: 13, color: 0xffc14a },
  { id: 5, name: "Doodler", role: "Intel", blurb: "Pings every attacker on the map.", team: "DEFENSE", damage: 21, pellets: 1, rpm: 185, mag: 12, spread: 0.02, speed: 5.2, gadget: "ping", gadgetName: "Lookout", gadgetCd: 15, color: 0x62e0ff },
  // NEW
  { id: 6, name: "Fog", role: "Cover", blurb: "Smoke screen to break attacker lines of sight.", team: "DEFENSE", damage: 23, pellets: 1, rpm: 170, mag: 12, spread: 0.02, speed: 5.0, gadget: "smoke", gadgetName: "Fog Bank", gadgetCd: 13, color: 0x778899 },
  { id: 7, name: "Nurse", role: "Support", blurb: "Heals the anchor line under pressure.", team: "DEFENSE", damage: 18, pellets: 1, rpm: 200, mag: 14, spread: 0.022, speed: 5.0, gadget: "heal", gadgetName: "Patch Kit", gadgetCd: 13, color: 0x55ffaa },
  { id: 8, name: "Warden", role: "Anchor", blurb: "Personal shield while holding angles.", team: "DEFENSE", damage: 25, pellets: 1, rpm: 150, mag: 11, spread: 0.018, speed: 4.6, gadget: "shield", gadgetName: "Hold Shield", gadgetCd: 14, color: 0xaabbcc },
  { id: 9, name: "Sentry", role: "Trap", blurb: "Tripwire that freezes plant attempts.", team: "DEFENSE", damage: 22, pellets: 1, rpm: 165, mag: 11, spread: 0.019, speed: 5.0, gadget: "trap", gadgetName: "Site Wire", gadgetCd: 12, color: 0xbb55ff },
  { id: 10, name: "Beacon", role: "Intel", blurb: "Drone scan of the site approaches.", team: "DEFENSE", damage: 20, pellets: 1, rpm: 190, mag: 13, spread: 0.02, speed: 5.3, gadget: "drone", gadgetName: "Site Scan", gadgetCd: 12, color: 0x44ddff },
  { id: 11, name: "Coach", role: "Support", blurb: "Speed boost for rotates and retakes.", team: "DEFENSE", damage: 19, pellets: 1, rpm: 220, mag: 15, spread: 0.024, speed: 5.4, gadget: "boost", gadgetName: "Rotate Boost", gadgetCd: 11, color: 0xff9944 },
];

export function classesFor(team: Team): ClassDef[] {
  return team === "ATTACK" ? ATTACK_CLASSES : DEFENSE_CLASSES;
}

export function getClass(team: Team, id: ClassId): ClassDef {
  const list = classesFor(team);
  return list[id] ?? list[0];
}
